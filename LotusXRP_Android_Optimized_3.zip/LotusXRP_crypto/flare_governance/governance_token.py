"""
Tokenomics and voting mechanisms for the LotusXRP governance token.

This module defines the governance token contract, including token distribution,
staking mechanisms, and voting power calculations.
"""

import time
import json
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import logging

class TokenAction(Enum):
    MINT = "mint"
    BURN = "burn"
    TRANSFER = "transfer"
    STAKE = "stake"
    UNSTAKE = "unstake"
    DELEGATE = "delegate"
    UNDELEGATE = "undelegate"

@dataclass
class TokenHolder:
    address: str
    balance: int
    staked_balance: int
    delegated_to: Optional[str]
    delegated_from: Dict[str, int]  # address -> amount
    last_activity: int
    rewards_earned: int = 0
    voting_power: int = 0

@dataclass
class StakingPool:
    pool_id: str
    name: str
    description: str
    apy: float  # Annual Percentage Yield
    total_staked: int
    min_stake: int
    lock_period: int  # in seconds
    participants: Dict[str, int]  # address -> staked amount
    created_at: int
    is_active: bool = True

@dataclass
class TokenTransaction:
    tx_hash: str
    from_address: str
    to_address: str
    amount: int
    action: TokenAction
    timestamp: int
    block_number: int
    gas_used: int = 0
    metadata: Optional[Dict] = None

class GovernanceToken:
    def __init__(self, token_name: str = "LotusXRP", token_symbol: str = "LOTUS"):
        self.token_name = token_name
        self.token_symbol = token_symbol
        self.decimals = 18
        self.total_supply = 0
        self.max_supply = 1_000_000_000 * (10 ** self.decimals)  # 1 billion tokens
        
        # Token holders and balances
        self.token_holders: Dict[str, TokenHolder] = {}
        self.staking_pools: Dict[str, StakingPool] = {}
        self.transactions: List[TokenTransaction] = []
        
        # Tokenomics parameters
        self.tokenomics = self._default_tokenomics()
        
        # Governance integration
        self.governance_contract = None
        
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)
        
        # Initialize default staking pools
        self._initialize_staking_pools()

    def _default_tokenomics(self) -> Dict:
        """Returns default tokenomics configuration."""
        return {
            "initial_distribution": {
                "team": 0.15,           # 15% to team (vested)
                "advisors": 0.05,       # 5% to advisors
                "treasury": 0.30,       # 30% to treasury/DAO
                "liquidity": 0.20,      # 20% for liquidity provision
                "staking_rewards": 0.20, # 20% for staking rewards
                "public_sale": 0.10     # 10% public sale
            },
            "vesting_schedules": {
                "team": {"cliff": 31536000, "duration": 126144000},  # 1 year cliff, 4 year vest
                "advisors": {"cliff": 15768000, "duration": 63072000}  # 6 month cliff, 2 year vest
            },
            "staking_rewards": {
                "base_apy": 0.08,       # 8% base APY
                "max_apy": 0.15,        # 15% max APY with bonuses
                "lock_bonus": 0.02,     # 2% bonus for longer locks
                "early_unstake_penalty": 0.05  # 5% penalty for early unstaking
            },
            "governance_thresholds": {
                "proposal_threshold": 10000 * (10 ** 18),  # 10,000 tokens to create proposal
                "voting_power_multiplier": 1.5,  # Staked tokens get 1.5x voting power
                "delegation_enabled": True
            }
        }

    def _initialize_staking_pools(self):
        """Initializes default staking pools."""
        pools = [
            {
                "pool_id": "flexible",
                "name": "Flexible Staking",
                "description": "Stake and unstake anytime with base rewards",
                "apy": 0.08,
                "min_stake": 100 * (10 ** self.decimals),
                "lock_period": 0
            },
            {
                "pool_id": "locked_30d",
                "name": "30-Day Lock",
                "description": "Lock tokens for 30 days for higher rewards",
                "apy": 0.10,
                "min_stake": 500 * (10 ** self.decimals),
                "lock_period": 2592000  # 30 days
            },
            {
                "pool_id": "locked_90d",
                "name": "90-Day Lock",
                "description": "Lock tokens for 90 days for premium rewards",
                "apy": 0.12,
                "min_stake": 1000 * (10 ** self.decimals),
                "lock_period": 7776000  # 90 days
            },
            {
                "pool_id": "locked_365d",
                "name": "1-Year Lock",
                "description": "Maximum rewards for 1-year commitment",
                "apy": 0.15,
                "min_stake": 5000 * (10 ** self.decimals),
                "lock_period": 31536000  # 365 days
            }
        ]
        
        for pool_config in pools:
            pool = StakingPool(
                pool_id=pool_config["pool_id"],
                name=pool_config["name"],
                description=pool_config["description"],
                apy=pool_config["apy"],
                total_staked=0,
                min_stake=pool_config["min_stake"],
                lock_period=pool_config["lock_period"],
                participants={},
                created_at=int(time.time())
            )
            self.staking_pools[pool.pool_id] = pool

    def mint_tokens(self, to_address: str, amount: int, reason: str = "mint") -> bool:
        """Mints new tokens to an address.

        Args:
            to_address (str): Recipient address
            amount (int): Amount to mint (in wei)
            reason (str): Reason for minting

        Returns:
            bool: True if successful
        """
        if self.total_supply + amount > self.max_supply:
            raise ValueError("Minting would exceed max supply")

        # Create or update token holder
        if to_address not in self.token_holders:
            self.token_holders[to_address] = TokenHolder(
                address=to_address,
                balance=0,
                staked_balance=0,
                delegated_to=None,
                delegated_from={},
                last_activity=int(time.time())
            )

        holder = self.token_holders[to_address]
        holder.balance += amount
        holder.last_activity = int(time.time())
        
        self.total_supply += amount

        # Record transaction
        self._record_transaction(
            from_address="0x0",
            to_address=to_address,
            amount=amount,
            action=TokenAction.MINT,
            metadata={"reason": reason}
        )

        self._update_voting_power(to_address)
        self.logger.info(f"Minted {amount} tokens to {to_address}")
        return True

    def transfer(self, from_address: str, to_address: str, amount: int) -> bool:
        """Transfers tokens between addresses.

        Args:
            from_address (str): Sender address
            to_address (str): Recipient address
            amount (int): Amount to transfer

        Returns:
            bool: True if successful
        """
        if from_address not in self.token_holders:
            raise ValueError("Sender not found")

        sender = self.token_holders[from_address]
        if sender.balance < amount:
            raise ValueError("Insufficient balance")

        # Create recipient if doesn't exist
        if to_address not in self.token_holders:
            self.token_holders[to_address] = TokenHolder(
                address=to_address,
                balance=0,
                staked_balance=0,
                delegated_to=None,
                delegated_from={},
                last_activity=int(time.time())
            )

        recipient = self.token_holders[to_address]

        # Execute transfer
        sender.balance -= amount
        recipient.balance += amount
        
        current_time = int(time.time())
        sender.last_activity = current_time
        recipient.last_activity = current_time

        # Record transaction
        self._record_transaction(
            from_address=from_address,
            to_address=to_address,
            amount=amount,
            action=TokenAction.TRANSFER
        )

        # Update voting power for both addresses
        self._update_voting_power(from_address)
        self._update_voting_power(to_address)

        self.logger.info(f"Transferred {amount} tokens from {from_address} to {to_address}")
        return True

    def stake_tokens(self, staker_address: str, pool_id: str, amount: int) -> bool:
        """Stakes tokens in a staking pool.

        Args:
            staker_address (str): Address of the staker
            pool_id (str): ID of the staking pool
            amount (int): Amount to stake

        Returns:
            bool: True if successful
        """
        if staker_address not in self.token_holders:
            raise ValueError("Staker not found")
        
        if pool_id not in self.staking_pools:
            raise ValueError("Staking pool not found")

        holder = self.token_holders[staker_address]
        pool = self.staking_pools[pool_id]

        if not pool.is_active:
            raise ValueError("Staking pool is not active")

        if holder.balance < amount:
            raise ValueError("Insufficient balance to stake")

        if amount < pool.min_stake:
            raise ValueError(f"Amount below minimum stake of {pool.min_stake}")

        # Execute staking
        holder.balance -= amount
        holder.staked_balance += amount
        holder.last_activity = int(time.time())

        # Update pool
        pool.total_staked += amount
        if staker_address in pool.participants:
            pool.participants[staker_address] += amount
        else:
            pool.participants[staker_address] = amount

        # Record transaction
        self._record_transaction(
            from_address=staker_address,
            to_address=pool_id,
            amount=amount,
            action=TokenAction.STAKE,
            metadata={"pool_id": pool_id}
        )

        self._update_voting_power(staker_address)
        self.logger.info(f"Staked {amount} tokens from {staker_address} in pool {pool_id}")
        return True

    def unstake_tokens(self, staker_address: str, pool_id: str, amount: int) -> bool:
        """Unstakes tokens from a staking pool.

        Args:
            staker_address (str): Address of the staker
            pool_id (str): ID of the staking pool
            amount (int): Amount to unstake

        Returns:
            bool: True if successful
        """
        if staker_address not in self.token_holders:
            raise ValueError("Staker not found")
        
        if pool_id not in self.staking_pools:
            raise ValueError("Staking pool not found")

        holder = self.token_holders[staker_address]
        pool = self.staking_pools[pool_id]

        if staker_address not in pool.participants:
            raise ValueError("No stake found in this pool")

        staked_amount = pool.participants[staker_address]
        if amount > staked_amount:
            raise ValueError("Insufficient staked amount")

        # Check lock period (simplified - would need to track individual stake times)
        current_time = int(time.time())
        # For now, assume all stakes are subject to the same lock period

        # Calculate penalty for early unstaking if applicable
        penalty = 0
        if pool.lock_period > 0:
            # Simplified penalty calculation
            penalty = int(amount * self.tokenomics["staking_rewards"]["early_unstake_penalty"])

        # Execute unstaking
        actual_amount = amount - penalty
        holder.balance += actual_amount
        holder.staked_balance -= amount
        holder.last_activity = current_time

        # Update pool
        pool.total_staked -= amount
        pool.participants[staker_address] -= amount
        if pool.participants[staker_address] == 0:
            del pool.participants[staker_address]

        # Burn penalty tokens
        if penalty > 0:
            self.total_supply -= penalty
            self.logger.info(f"Burned {penalty} tokens as early unstaking penalty")

        # Record transaction
        self._record_transaction(
            from_address=pool_id,
            to_address=staker_address,
            amount=actual_amount,
            action=TokenAction.UNSTAKE,
            metadata={"pool_id": pool_id, "penalty": penalty}
        )

        self._update_voting_power(staker_address)
        self.logger.info(f"Unstaked {amount} tokens from pool {pool_id} (penalty: {penalty})")
        return True

    def delegate_voting_power(self, delegator: str, delegate: str) -> bool:
        """Delegates voting power to another address.

        Args:
            delegator (str): Address delegating voting power
            delegate (str): Address receiving voting power

        Returns:
            bool: True if successful
        """
        if not self.tokenomics["governance_thresholds"]["delegation_enabled"]:
            raise ValueError("Delegation is not enabled")

        if delegator not in self.token_holders:
            raise ValueError("Delegator not found")

        if delegate not in self.token_holders:
            raise ValueError("Delegate not found")

        delegator_holder = self.token_holders[delegator]
        delegate_holder = self.token_holders[delegate]

        # Remove previous delegation if exists
        if delegator_holder.delegated_to:
            old_delegate = self.token_holders[delegator_holder.delegated_to]
            if delegator in old_delegate.delegated_from:
                del old_delegate.delegated_from[delegator]
            self._update_voting_power(delegator_holder.delegated_to)

        # Set new delegation
        delegator_holder.delegated_to = delegate
        voting_power = self._calculate_voting_power(delegator)
        delegate_holder.delegated_from[delegator] = voting_power

        # Update voting power for both addresses
        self._update_voting_power(delegator)
        self._update_voting_power(delegate)

        self.logger.info(f"Delegated voting power from {delegator} to {delegate}")
        return True

    def undelegate_voting_power(self, delegator: str) -> bool:
        """Removes voting power delegation.

        Args:
            delegator (str): Address removing delegation

        Returns:
            bool: True if successful
        """
        if delegator not in self.token_holders:
            raise ValueError("Delegator not found")

        delegator_holder = self.token_holders[delegator]
        
        if not delegator_holder.delegated_to:
            raise ValueError("No active delegation found")

        delegate = delegator_holder.delegated_to
        delegate_holder = self.token_holders[delegate]

        # Remove delegation
        delegator_holder.delegated_to = None
        if delegator in delegate_holder.delegated_from:
            del delegate_holder.delegated_from[delegator]

        # Update voting power
        self._update_voting_power(delegator)
        self._update_voting_power(delegate)

        self.logger.info(f"Removed delegation from {delegator}")
        return True

    def _calculate_voting_power(self, address: str) -> int:
        """Calculates voting power for an address.

        Args:
            address (str): Address to calculate voting power for

        Returns:
            int: Voting power
        """
        if address not in self.token_holders:
            return 0

        holder = self.token_holders[address]
        
        # Base voting power from balance
        base_power = holder.balance
        
        # Bonus from staked tokens
        staked_bonus = int(holder.staked_balance * self.tokenomics["governance_thresholds"]["voting_power_multiplier"])
        
        # If delegated, voting power is 0 for own tokens
        if holder.delegated_to:
            return 0
        
        # Add delegated voting power from others
        delegated_power = sum(holder.delegated_from.values())
        
        total_power = base_power + staked_bonus + delegated_power
        return total_power

    def _update_voting_power(self, address: str):
        """Updates voting power for an address and syncs with governance contract.

        Args:
            address (str): Address to update
        """
        if address not in self.token_holders:
            return

        holder = self.token_holders[address]
        new_voting_power = self._calculate_voting_power(address)
        holder.voting_power = new_voting_power

        # Sync with governance contract if available
        if self.governance_contract:
            self.governance_contract.update_voting_power(address, new_voting_power)

    def _record_transaction(self, from_address: str, to_address: str, amount: int, 
                          action: TokenAction, metadata: Optional[Dict] = None):
        """Records a token transaction.

        Args:
            from_address (str): Sender address
            to_address (str): Recipient address
            amount (int): Transaction amount
            action (TokenAction): Type of transaction
            metadata (Optional[Dict]): Additional transaction data
        """
        tx = TokenTransaction(
            tx_hash=f"0x{len(self.transactions):064x}",  # Simple hash generation
            from_address=from_address,
            to_address=to_address,
            amount=amount,
            action=action,
            timestamp=int(time.time()),
            block_number=len(self.transactions) + 1,
            metadata=metadata
        )
        
        self.transactions.append(tx)

    def distribute_staking_rewards(self):
        """Distributes staking rewards to all stakers."""
        current_time = int(time.time())
        
        for pool_id, pool in self.staking_pools.items():
            if not pool.is_active or pool.total_staked == 0:
                continue
            
            # Calculate rewards for this pool (simplified daily distribution)
            daily_rate = pool.apy / 365
            total_rewards = int(pool.total_staked * daily_rate)
            
            # Distribute proportionally to participants
            for participant, staked_amount in pool.participants.items():
                if participant in self.token_holders:
                    holder = self.token_holders[participant]
                    reward = int((staked_amount / pool.total_staked) * total_rewards)
                    
                    # Add reward to balance
                    holder.balance += reward
                    holder.rewards_earned += reward
                    holder.last_activity = current_time
                    
                    # Update total supply
                    self.total_supply += reward
                    
                    # Record reward transaction
                    self._record_transaction(
                        from_address="0x0",
                        to_address=participant,
                        amount=reward,
                        action=TokenAction.MINT,
                        metadata={"type": "staking_reward", "pool_id": pool_id}
                    )
            
            self.logger.info(f"Distributed {total_rewards} rewards in pool {pool_id}")

    def get_token_holder(self, address: str) -> Optional[Dict]:
        """Gets token holder information.

        Args:
            address (str): Holder address

        Returns:
            Optional[Dict]: Holder information or None
        """
        if address in self.token_holders:
            return asdict(self.token_holders[address])
        return None

    def get_staking_pool(self, pool_id: str) -> Optional[Dict]:
        """Gets staking pool information.

        Args:
            pool_id (str): Pool ID

        Returns:
            Optional[Dict]: Pool information or None
        """
        if pool_id in self.staking_pools:
            return asdict(self.staking_pools[pool_id])
        return None

    def get_token_stats(self) -> Dict:
        """Returns token statistics.

        Returns:
            Dict: Token statistics
        """
        total_staked = sum(pool.total_staked for pool in self.staking_pools.values())
        total_holders = len(self.token_holders)
        circulating_supply = self.total_supply - total_staked
        
        return {
            "token_name": self.token_name,
            "token_symbol": self.token_symbol,
            "total_supply": self.total_supply,
            "max_supply": self.max_supply,
            "circulating_supply": circulating_supply,
            "total_staked": total_staked,
            "total_holders": total_holders,
            "total_transactions": len(self.transactions),
            "staking_pools": len(self.staking_pools)
        }

    def export_token_data(self, filepath: str):
        """Exports token data to a JSON file.

        Args:
            filepath (str): Path to save the data
        """
        data = {
            "token_info": {
                "name": self.token_name,
                "symbol": self.token_symbol,
                "decimals": self.decimals,
                "total_supply": self.total_supply,
                "max_supply": self.max_supply
            },
            "token_holders": {addr: asdict(holder) for addr, holder in self.token_holders.items()},
            "staking_pools": {pid: asdict(pool) for pid, pool in self.staking_pools.items()},
            "transactions": [asdict(tx) for tx in self.transactions],
            "tokenomics": self.tokenomics
        }

        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2, default=str)

        self.logger.info(f"Token data exported to {filepath}")

if __name__ == "__main__":
    # Example usage
    token = GovernanceToken("LotusXRP", "LOTUS")
    
    # Mint initial supply to treasury
    treasury_address = "0xTREASURY"
    initial_mint = 100_000_000 * (10 ** token.decimals)  # 100M tokens
    token.mint_tokens(treasury_address, initial_mint, "Initial treasury allocation")
    
    # Create some users
    user1 = "0xUSER1"
    user2 = "0xUSER2"
    
    # Transfer tokens to users
    token.transfer(treasury_address, user1, 10_000 * (10 ** token.decimals))
    token.transfer(treasury_address, user2, 5_000 * (10 ** token.decimals))
    
    # Stake tokens
    token.stake_tokens(user1, "locked_90d", 5_000 * (10 ** token.decimals))
    token.stake_tokens(user2, "flexible", 2_000 * (10 ** token.decimals))
    
    # Delegate voting power
    token.delegate_voting_power(user2, user1)
    
    # Get token stats
    stats = token.get_token_stats()
    print(f"Token Stats: {json.dumps(stats, indent=2)}")
    
    # Get holder info
    holder_info = token.get_token_holder(user1)
    print(f"User1 Info: {json.dumps(holder_info, indent=2)}")

