"""
Smart contracts for governance on the Flare Network.

This module defines the governance smart contract that handles voting,
proposals, and decentralized decision-making for the LotusXRP platform.
"""

import json
import time
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import logging

class ProposalStatus(Enum):
    PENDING = "pending"
    ACTIVE = "active"
    SUCCEEDED = "succeeded"
    DEFEATED = "defeated"
    EXECUTED = "executed"
    CANCELLED = "cancelled"

class VoteType(Enum):
    FOR = "for"
    AGAINST = "against"
    ABSTAIN = "abstain"

@dataclass
class Proposal:
    id: int
    title: str
    description: str
    proposer: str
    created_at: int
    voting_start: int
    voting_end: int
    execution_delay: int
    status: ProposalStatus
    votes_for: int = 0
    votes_against: int = 0
    votes_abstain: int = 0
    quorum_required: int = 0
    threshold_percentage: int = 51  # Majority threshold
    executed_at: Optional[int] = None
    cancelled_at: Optional[int] = None
    execution_data: Optional[Dict] = None

@dataclass
class Vote:
    proposal_id: int
    voter: str
    vote_type: VoteType
    voting_power: int
    timestamp: int
    reason: Optional[str] = None

class GovernanceContract:
    def __init__(self, contract_address: str = None):
        self.contract_address = contract_address or "0x" + "0" * 40
        self.proposals: Dict[int, Proposal] = {}
        self.votes: Dict[int, List[Vote]] = {}  # proposal_id -> votes
        self.voter_registry: Dict[str, int] = {}  # address -> voting power
        self.proposal_counter = 0
        self.governance_settings = self._default_governance_settings()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)

    def _default_governance_settings(self) -> Dict:
        """Returns default governance settings."""
        return {
            "voting_delay": 5,  # 5 seconds for testing
            "voting_period": 60,  # 60 seconds for testing
            "execution_delay": 172800,  # 2 days in seconds
            "proposal_threshold": 1000,  # Minimum tokens to create proposal
            "quorum_percentage": 10,  # Minimum participation percentage
            "majority_threshold": 51,  # Percentage needed to pass
            "max_proposals_per_user": 3,  # Max active proposals per user
            "proposal_fee": 100,  # Fee in governance tokens
        }

    def create_proposal(
        self,
        title: str,
        description: str,
        proposer: str,
        execution_data: Optional[Dict] = None
    ) -> int:
        """Creates a new governance proposal.

        Args:
            title (str): Proposal title
            description (str): Detailed proposal description
            proposer (str): Address of the proposer
            execution_data (Optional[Dict]): Data for proposal execution

        Returns:
            int: Proposal ID
        """
        # Check if proposer has enough voting power
        proposer_power = self.voter_registry.get(proposer, 0)
        if proposer_power < self.governance_settings["proposal_threshold"]:
            raise ValueError(f"Insufficient voting power. Required: {self.governance_settings['proposal_threshold']}")

        # Check proposal limit per user
        active_proposals = self._get_active_proposals_by_user(proposer)
        if len(active_proposals) >= self.governance_settings["max_proposals_per_user"]:
            raise ValueError("Maximum active proposals per user exceeded")

        # Create proposal
        self.proposal_counter += 1
        proposal_id = self.proposal_counter
        
        current_time = int(time.time())
        voting_start = current_time + self.governance_settings["voting_delay"]
        voting_end = voting_start + self.governance_settings["voting_period"]
        
        # Calculate quorum requirement
        total_voting_power = sum(self.voter_registry.values())
        quorum_required = (total_voting_power * self.governance_settings["quorum_percentage"]) // 100

        proposal = Proposal(
            id=proposal_id,
            title=title,
            description=description,
            proposer=proposer,
            created_at=current_time,
            voting_start=voting_start,
            voting_end=voting_end,
            execution_delay=self.governance_settings["execution_delay"],
            status=ProposalStatus.PENDING,
            quorum_required=quorum_required,
            threshold_percentage=self.governance_settings["majority_threshold"],
            execution_data=execution_data
        )

        self.proposals[proposal_id] = proposal
        self.votes[proposal_id] = []

        self.logger.info(f"Proposal created: ID {proposal_id}, Title: {title}")
        return proposal_id

    def cast_vote(self, proposal_id: int, voter: str, vote_type: VoteType, reason: str = None) -> bool:
        """Casts a vote on a proposal.

        Args:
            proposal_id (int): ID of the proposal
            voter (str): Address of the voter
            vote_type (VoteType): Type of vote
            reason (str): Optional reason for the vote

        Returns:
            bool: True if vote was cast successfully
        """
        if proposal_id not in self.proposals:
            raise ValueError("Proposal not found")

        proposal = self.proposals[proposal_id]
        current_time = int(time.time())

        # Check if voting is active
        if current_time < proposal.voting_start:
            raise ValueError("Voting has not started yet")
        if current_time > proposal.voting_end:
            raise ValueError("Voting has ended")
        if proposal.status != ProposalStatus.ACTIVE:
            raise ValueError("Proposal is not active")

        # Check if voter has voting power
        voting_power = self.voter_registry.get(voter, 0)
        if voting_power == 0:
            raise ValueError("Voter has no voting power")

        # Check if voter has already voted
        existing_votes = [v for v in self.votes[proposal_id] if v.voter == voter]
        if existing_votes:
            raise ValueError("Voter has already voted on this proposal")

        # Cast vote
        vote = Vote(
            proposal_id=proposal_id,
            voter=voter,
            vote_type=vote_type,
            voting_power=voting_power,
            timestamp=current_time,
            reason=reason
        )

        self.votes[proposal_id].append(vote)

        # Update proposal vote counts
        if vote_type == VoteType.FOR:
            proposal.votes_for += voting_power
        elif vote_type == VoteType.AGAINST:
            proposal.votes_against += voting_power
        elif vote_type == VoteType.ABSTAIN:
            proposal.votes_abstain += voting_power

        self.logger.info(f"Vote cast: Proposal {proposal_id}, Voter: {voter}, Type: {vote_type.value}")
        return True

    def update_proposal_status(self, proposal_id: int):
        """Updates the status of a proposal based on current time and votes.

        Args:
            proposal_id (int): ID of the proposal to update
        """
        if proposal_id not in self.proposals:
            return

        proposal = self.proposals[proposal_id]
        current_time = int(time.time())

        # Update status based on time and votes
        if proposal.status == ProposalStatus.PENDING and current_time >= proposal.voting_start:
            proposal.status = ProposalStatus.ACTIVE
            self.logger.info(f"Proposal {proposal_id} is now active")

        elif proposal.status == ProposalStatus.ACTIVE and current_time > proposal.voting_end:
            # Check if proposal passed
            total_votes = proposal.votes_for + proposal.votes_against + proposal.votes_abstain
            
            # Check quorum
            if total_votes < proposal.quorum_required:
                proposal.status = ProposalStatus.DEFEATED
                self.logger.info(f"Proposal {proposal_id} defeated: insufficient quorum")
            else:
                # Check majority
                if proposal.votes_for + proposal.votes_against == 0:
                    proposal.status = ProposalStatus.DEFEATED
                else:
                    for_percentage = (proposal.votes_for * 100) // (proposal.votes_for + proposal.votes_against)
                    if for_percentage >= proposal.threshold_percentage:
                        proposal.status = ProposalStatus.SUCCEEDED
                        self.logger.info(f"Proposal {proposal_id} succeeded")
                    else:
                        proposal.status = ProposalStatus.DEFEATED
                        self.logger.info(f"Proposal {proposal_id} defeated: insufficient majority")

    def execute_proposal(self, proposal_id: int, executor: str) -> bool:
        """Executes a successful proposal.

        Args:
            proposal_id (int): ID of the proposal to execute
            executor (str): Address of the executor

        Returns:
            bool: True if execution was successful
        """
        if proposal_id not in self.proposals:
            raise ValueError("Proposal not found")

        proposal = self.proposals[proposal_id]
        current_time = int(time.time())

        # Check if proposal can be executed
        if proposal.status != ProposalStatus.SUCCEEDED:
            raise ValueError("Proposal has not succeeded")

        # Check execution delay
        execution_ready_time = proposal.voting_end + proposal.execution_delay
        if current_time < execution_ready_time:
            raise ValueError("Execution delay has not passed")

        # Execute proposal (placeholder for actual execution logic)
        if proposal.execution_data:
            self._execute_proposal_data(proposal.execution_data)

        proposal.status = ProposalStatus.EXECUTED
        proposal.executed_at = current_time

        self.logger.info(f"Proposal {proposal_id} executed by {executor}")
        return True

    def _execute_proposal_data(self, execution_data: Dict):
        """Executes the actual proposal data.

        Args:
            execution_data (Dict): Execution data from the proposal
        """
        # This would contain the actual execution logic
        # For example: parameter changes, fund transfers, etc.
        action = execution_data.get("action")
        
        if action == "update_settings":
            self._update_governance_settings(execution_data.get("settings", {}))
        elif action == "transfer_funds":
            self._transfer_funds(execution_data)
        elif action == "update_contract":
            self._update_contract(execution_data)
        
        self.logger.info(f"Executed proposal action: {action}")

    def _update_governance_settings(self, new_settings: Dict):
        """Updates governance settings."""
        for key, value in new_settings.items():
            if key in self.governance_settings:
                self.governance_settings[key] = value
                self.logger.info(f"Governance setting updated: {key} = {value}")

    def _transfer_funds(self, execution_data: Dict):
        """Handles fund transfers (placeholder)."""
        recipient = execution_data.get("recipient")
        amount = execution_data.get("amount")
        self.logger.info(f"Fund transfer: {amount} to {recipient}")

    def _update_contract(self, execution_data: Dict):
        """Handles contract updates (placeholder)."""
        contract = execution_data.get("contract")
        self.logger.info(f"Contract update: {contract}")

    def cancel_proposal(self, proposal_id: int, canceller: str) -> bool:
        """Cancels a proposal (only by proposer or governance).

        Args:
            proposal_id (int): ID of the proposal to cancel
            canceller (str): Address of the canceller

        Returns:
            bool: True if cancellation was successful
        """
        if proposal_id not in self.proposals:
            raise ValueError("Proposal not found")

        proposal = self.proposals[proposal_id]

        # Check if canceller has permission
        if canceller != proposal.proposer and not self._is_governance_admin(canceller):
            raise ValueError("Insufficient permission to cancel proposal")

        # Check if proposal can be cancelled
        if proposal.status in [ProposalStatus.EXECUTED, ProposalStatus.CANCELLED]:
            raise ValueError("Proposal cannot be cancelled")

        proposal.status = ProposalStatus.CANCELLED
        proposal.cancelled_at = int(time.time())

        self.logger.info(f"Proposal {proposal_id} cancelled by {canceller}")
        return True

    def register_voter(self, voter_address: str, voting_power: int):
        """Registers a voter with their voting power.

        Args:
            voter_address (str): Address of the voter
            voting_power (int): Voting power (token balance)
        """
        self.voter_registry[voter_address] = voting_power
        self.logger.info(f"Voter registered: {voter_address} with power {voting_power}")

    def update_voting_power(self, voter_address: str, new_power: int):
        """Updates a voter's voting power.

        Args:
            voter_address (str): Address of the voter
            new_power (int): New voting power
        """
        old_power = self.voter_registry.get(voter_address, 0)
        self.voter_registry[voter_address] = new_power
        self.logger.info(f"Voting power updated: {voter_address} from {old_power} to {new_power}")

    def get_proposal(self, proposal_id: int) -> Optional[Dict]:
        """Gets a proposal by ID.

        Args:
            proposal_id (int): Proposal ID

        Returns:
            Optional[Dict]: Proposal data or None
        """
        if proposal_id in self.proposals:
            return asdict(self.proposals[proposal_id])
        return None

    def get_proposal_votes(self, proposal_id: int) -> List[Dict]:
        """Gets all votes for a proposal.

        Args:
            proposal_id (int): Proposal ID

        Returns:
            List[Dict]: List of votes
        """
        if proposal_id in self.votes:
            return [asdict(vote) for vote in self.votes[proposal_id]]
        return []

    def get_active_proposals(self) -> List[Dict]:
        """Gets all active proposals.

        Returns:
            List[Dict]: List of active proposals
        """
        active = []
        for proposal in self.proposals.values():
            self.update_proposal_status(proposal.id)
            if proposal.status == ProposalStatus.ACTIVE:
                active.append(asdict(proposal))
        return active

    def _get_active_proposals_by_user(self, user: str) -> List[Proposal]:
        """Gets active proposals by a specific user."""
        return [
            p for p in self.proposals.values()
            if p.proposer == user and p.status in [ProposalStatus.PENDING, ProposalStatus.ACTIVE]
        ]

    def _is_governance_admin(self, address: str) -> bool:
        """Checks if an address has governance admin privileges."""
        # Placeholder for admin check logic
        return False

    def get_governance_stats(self) -> Dict:
        """Returns governance statistics.

        Returns:
            Dict: Governance statistics
        """
        total_proposals = len(self.proposals)
        active_proposals = len([p for p in self.proposals.values() if p.status == ProposalStatus.ACTIVE])
        total_voters = len(self.voter_registry)
        total_voting_power = sum(self.voter_registry.values())

        return {
            "total_proposals": total_proposals,
            "active_proposals": active_proposals,
            "total_voters": total_voters,
            "total_voting_power": total_voting_power,
            "governance_settings": self.governance_settings
        }

    def export_governance_data(self, filepath: str):
        """Exports governance data to a JSON file.

        Args:
            filepath (str): Path to save the data
        """
        data = {
            "proposals": {pid: asdict(p) for pid, p in self.proposals.items()},
            "votes": {pid: [asdict(v) for v in votes] for pid, votes in self.votes.items()},
            "voter_registry": self.voter_registry,
            "governance_settings": self.governance_settings,
            "contract_address": self.contract_address
        }

        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2, default=str)

        self.logger.info(f"Governance data exported to {filepath}")

if __name__ == "__main__":
    # Example usage
    governance = GovernanceContract()
    
    # Register voters
    governance.register_voter("0x123", 1000)
    governance.register_voter("0x456", 2000)
    governance.register_voter("0x789", 1500)
    
    # Create a proposal
    proposal_id = governance.create_proposal(
        title="Increase Trading Bot Allocation",
        description="Proposal to increase the trading bot's allocation from 10% to 15% of the treasury",
        proposer="0x123",
        execution_data={
            "action": "update_settings",
            "settings": {"trading_allocation": 15}
        }
    )
    
    # Simulate time passage to make proposal active
    import time
    time.sleep(1)
    governance.update_proposal_status(proposal_id)
    
    # Cast votes
    governance.cast_vote(proposal_id, "0x456", VoteType.FOR, "Good idea for growth")
    governance.cast_vote(proposal_id, "0x789", VoteType.FOR, "Agree with the proposal")
    
    # Get proposal details
    proposal = governance.get_proposal(proposal_id)
    print(f"Proposal: {proposal['title']}")
    print(f"Status: {proposal['status']}")
    print(f"Votes For: {proposal['votes_for']}")
    
    # Get governance stats
    stats = governance.get_governance_stats()
    print(f"Governance Stats: {stats}")

