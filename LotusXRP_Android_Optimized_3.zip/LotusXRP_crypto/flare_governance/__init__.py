"""
Flare Governance Module for LotusXRP Crypto Platform

This module defines the smart contracts and tokenomics for the decentralized
governance of the LotusXRP platform, likely on the Flare Network.
"""

from .governance_contract import GovernanceContract
from .governance_token import GovernanceToken

__version__ = "1.0.0"
__author__ = "LotusXRP Team"

__all__ = [
    "GovernanceContract",
    "GovernanceToken"
]

