"""
VTuber Avatar Module for LotusXRP Crypto Platform

This module handles the design, animation, and streaming of the VTuber avatar,
providing a visual and interactive representation for the platform.
"""

from .avatar import Avatar
from .animation import Animator
from .streaming import Streamer

__version__ = "1.0.0"
__author__ = "LotusXRP Team"

__all__ = [
    "Avatar",
    "Animator",
    "Streamer"
]

