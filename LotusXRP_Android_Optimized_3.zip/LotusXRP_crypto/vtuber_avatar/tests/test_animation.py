import unittest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), 
                                                os.pardir, os.pardir)))

from vtuber_avatar.avatar import Avatar
from vtuber_avatar.animation import Animator

class TestAnimator(unittest.TestCase):

    def setUp(self):
        self.avatar = Avatar("TestAvatar")
        self.avatar_config = self.avatar.generate_avatar_config()
        self.animator = Animator(self.avatar_config)

    def test_initialization(self):
        self.assertEqual(self.animator.avatar_config, self.avatar_config)
        self.assertIsInstance(self.animator.animation_queue, list)
        self.assertFalse(self.animator.is_playing)

    def test_play_animation(self):
        success = self.animator.play_animation("idle")
        self.assertTrue(success)
        import time
        time.sleep(0.05) # Give thread time to start
        self.assertTrue(self.animator.is_animating)

    def test_play_invalid_animation(self):
        success = self.animator.play_animation("invalid_animation")
        self.assertFalse(success)

    def test_stop_animation(self):
        self.animator.play_animation("idle")
        import time
        time.sleep(0.05) # Give thread time to start
        self.assertTrue(self.animator.is_animating)
        self.animator.stop_animation()
        self.assertFalse(self.animator.is_animating)

    def test_queue_animation(self):
        self.animator.queue_animation("happy")
        self.animator.queue_animation("sad")
        self.assertEqual(len(self.animator.animation_queue), 2)
        self.assertEqual(self.animator.animation_queue[0], "happy")
        self.assertEqual(self.animator.animation_queue[1], "sad")

    def test_get_animation_status(self):
        status = self.animator.get_animation_status()
        self.assertIsInstance(status, dict)
        self.assertIn("is_animating", status)
        self.assertIn("current_animation", status)
        self.assertIn("queue_length", status)

    def test_create_custom_animation(self):
        custom_animation = {
            "name": "custom_wave",
            "frames": [
                {"expression": "happy", "pose": "standing", "duration": 1.0},
                {"expression": "happy", "pose": "waving", "duration": 2.0},
                {"expression": "happy", "pose": "standing", "duration": 1.0}
            ]
        }
        self.animator.create_custom_animation(custom_animation)
        self.assertIn("custom_wave", self.animator.animations)

    def test_play_custom_animation(self):
        custom_animation = {
            "name": "custom_dance",
            "frames": [
                {"expression": "happy", "pose": "standing", "duration": 0.5},
                {"expression": "excited", "pose": "jumping", "duration": 0.5}
            ]
        }
        self.animator.create_custom_animation(custom_animation)
        success = self.animator.play_animation("custom_dance")
        self.assertTrue(success)

    def test_update_animation_frame(self):
        self.animator.play_animation("happy")
        initial_frame = self.animator.current_frame
        self.animator.update_animation_frame()
        # Frame should advance or animation should complete
        self.assertTrue(self.animator.current_frame >= initial_frame)

    def test_get_current_frame_data(self):
        self.animator.play_animation("happy")
        frame_data = self.animator.get_current_frame_data()
        self.assertIsInstance(frame_data, dict)
        if frame_data:  # If animation is playing
            self.assertIn("expression", frame_data)
            self.assertIn("pose", frame_data)

if __name__ == '__main__':
    unittest.main()

