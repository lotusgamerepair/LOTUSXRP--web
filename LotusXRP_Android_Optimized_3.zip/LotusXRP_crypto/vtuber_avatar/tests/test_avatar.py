import unittest
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), 
                                                os.pardir, os.pardir)))

from vtuber_avatar.avatar import Avatar

class TestAvatar(unittest.TestCase):

    def setUp(self):
        self.avatar = Avatar("TestAvatar")

    def test_initialization(self):
        self.assertEqual(self.avatar.name, "TestAvatar")
        config = self.avatar.generate_avatar_config()
        self.assertIsInstance(config, dict)
        self.assertIn("name", config)
        self.assertEqual(config["name"], "TestAvatar")

    def test_generate_avatar_config(self):
        config = self.avatar.generate_avatar_config()
        self.assertIsInstance(config, dict)
        self.assertIn("name", config)
        self.assertEqual(config["name"], "TestAvatar")
        self.assertIn("appearance", config)
        self.assertIn("expressions", config)
        self.assertIn("poses", config)

    def test_customize_appearance(self):
        self.avatar.customize_appearance(body_type="slim", hair_color="blue")
        config = self.avatar.generate_avatar_config()
        self.assertEqual(config["appearance"]["body_type"], "slim")
        self.assertEqual(config["appearance"]["hair_color"], "blue")

    def test_set_expression(self):
        self.avatar.set_expression("happy")
        self.assertEqual(self.avatar.current_expression, "happy")
        # Test invalid expression
        with self.assertRaises(ValueError):
            self.avatar.set_expression("invalid")

    def test_set_pose(self):
        self.avatar.set_pose("sitting")
        self.assertEqual(self.avatar.current_pose, "sitting")
        # Test invalid pose
        with self.assertRaises(ValueError):
            self.avatar.set_pose("invalid")

    def test_add_custom_expression(self):
        self.avatar.add_custom_expression("confused", {"eyes": "wide", "mouth": "open"})
        config = self.avatar.generate_avatar_config()
        self.assertIn("confused", config["expressions"])
        self.assertEqual(config["expressions"]["confused"], {"eyes": "wide", "mouth": "open"})

    def test_add_custom_pose(self):
        self.avatar.add_custom_pose("waving", {"arm_left": "up", "arm_right": "down"})
        config = self.avatar.generate_avatar_config()
        self.assertIn("waving", config["poses"])
        self.assertEqual(config["poses"]["waving"], {"arm_left": "up", "arm_right": "down"})

if __name__ == '__main__':
    unittest.main()

