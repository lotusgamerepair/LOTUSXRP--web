import unittest
import asyncio
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), 
                                                os.pardir, os.pardir)))

from vtuber_avatar.avatar import Avatar
from vtuber_avatar.animation import Animator
from vtuber_avatar.streaming import Streamer

class TestStreamer(unittest.TestCase):

    def setUp(self):
        self.avatar = Avatar("TestAvatar")
        self.avatar_config = self.avatar.generate_avatar_config()
        self.animator = Animator(self.avatar_config)
        self.streamer = Streamer(self.avatar, self.animator)

    def test_initialization(self):
        self.assertEqual(self.streamer.avatar, self.avatar)
        self.assertEqual(self.streamer.animator, self.animator)
        self.assertIsInstance(self.streamer.connected_clients, list)
        self.assertIsInstance(self.streamer.chat_history, list)
        self.assertFalse(self.streamer.is_streaming)

    def test_get_stream_status(self):
        status = self.streamer.get_stream_status()
        self.assertIsInstance(status, dict)
        self.assertIn("is_streaming", status)
        self.assertIn("connected_clients", status)
        self.assertIn("chat_messages", status)
        self.assertIn("uptime", status)

    def test_add_chat_message(self):
        message = {
            "user": "TestUser",
            "message": "Hello!",
            "timestamp": 1234567890
        }
        self.streamer.add_chat_message(message)
        self.assertEqual(len(self.streamer.chat_history), 1)
        self.assertEqual(self.streamer.chat_history[0], message)

    def test_process_chat_command(self):
        # Test valid command
        result = self.streamer.process_chat_command("!happy")
        self.assertTrue(result)
        
        # Test invalid command
        result = self.streamer.process_chat_command("!invalid")
        self.assertFalse(result)

    def test_handle_donation(self):
        donation = {
            "user": "Donor",
            "amount": 10.0,
            "message": "Great stream!"
        }
        self.streamer.handle_donation(donation)
        # Should trigger special animation and add to chat
        self.assertTrue(len(self.streamer.chat_history) > 0)

    def test_update_stream_overlay(self):
        overlay_data = {
            "follower_count": 100,
            "donation_goal": 500,
            "current_donations": 250
        }
        self.streamer.update_stream_overlay(overlay_data)
        self.assertEqual(self.streamer.overlay_data, overlay_data)

    def test_get_chat_history(self):
        # Add some messages
        for i in range(5):
            message = {
                "user": f"User{i}",
                "message": f"Message {i}",
                "timestamp": 1234567890 + i
            }
            self.streamer.add_chat_message(message)
        
        # Get recent messages
        recent = self.streamer.get_chat_history(3)
        self.assertEqual(len(recent), 3)
        # Should be most recent messages
        self.assertEqual(recent[0]["user"], "User4")

    def test_broadcast_message(self):
        # Mock connected clients
        self.streamer.connected_clients = ["client1", "client2"]
        
        message = {"type": "chat", "data": "Test broadcast"}
        # This would normally send to WebSocket clients
        # In test, we just verify the method doesn't crash
        try:
            self.streamer.broadcast_message(message)
            success = True
        except Exception:
            success = False
        self.assertTrue(success)

    def test_handle_viewer_interaction(self):
        interaction = {
            "type": "like",
            "user": "Viewer1"
        }
        self.streamer.handle_viewer_interaction(interaction)
        # Should add to interaction history
        self.assertTrue(len(self.streamer.interaction_history) > 0)

    def test_get_stream_analytics(self):
        analytics = self.streamer.get_stream_analytics()
        self.assertIsInstance(analytics, dict)
        self.assertIn("total_viewers", analytics)
        self.assertIn("peak_viewers", analytics)
        self.assertIn("chat_messages", analytics)
        self.assertIn("donations_received", analytics)

    def test_stop_stream(self):
        # Set streaming to true first
        self.streamer.is_streaming = True
        self.streamer.stop_stream()
        self.assertFalse(self.streamer.is_streaming)

if __name__ == '__main__':
    unittest.main()

