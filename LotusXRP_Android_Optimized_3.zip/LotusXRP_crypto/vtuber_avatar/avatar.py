"""
Avatar design logic for the LotusXRP VTuber.

This module handles the creation and management of 2D/3D avatar models,
including appearance customization and asset management.
"""

import json
import os
from typing import Dict, List, Tuple
import logging

class Avatar:
    def __init__(self, name: str = "LotusXRP-chan"):
        self.name = name
        self.avatar_type = "2D"  # Can be "2D" or "3D"
        self.appearance = self._default_appearance()
        self.expressions = self._default_expressions()
        self.poses = self._default_poses()
        self.assets_path = "assets/avatar/"
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)

    def _default_appearance(self) -> Dict:
        """Returns default avatar appearance settings."""
        return {
            "hair_color": "#FFB6C1",  # Light pink
            "eye_color": "#4169E1",   # Royal blue
            "skin_tone": "#FDBCB4",   # Light peach
            "outfit": "crypto_trader", # Default outfit theme
            "accessories": ["lotus_hairpin", "xrp_pendant"],
            "height": 165,  # cm
            "personality": "cheerful_analytical"
        }

    def _default_expressions(self) -> Dict:
        """Returns default facial expressions."""
        return {
            "neutral": {"mouth": "closed", "eyes": "normal", "eyebrows": "relaxed"},
            "happy": {"mouth": "smile", "eyes": "sparkle", "eyebrows": "raised"},
            "excited": {"mouth": "open_smile", "eyes": "wide", "eyebrows": "raised"},
            "thinking": {"mouth": "small", "eyes": "focused", "eyebrows": "furrowed"},
            "surprised": {"mouth": "open", "eyes": "wide", "eyebrows": "raised"},
            "confident": {"mouth": "smirk", "eyes": "determined", "eyebrows": "normal"},
            "worried": {"mouth": "frown", "eyes": "concerned", "eyebrows": "furrowed"}
        }

    def _default_poses(self) -> Dict:
        """Returns default body poses."""
        return {
            "standing": {"body": "upright", "arms": "relaxed", "hands": "open"},
            "pointing": {"body": "slight_lean", "arms": "one_extended", "hands": "pointing"},
            "explaining": {"body": "forward_lean", "arms": "both_extended", "hands": "gesturing"},
            "celebrating": {"body": "upright", "arms": "raised", "hands": "victory"},
            "thinking_pose": {"body": "slight_turn", "arms": "one_to_chin", "hands": "thoughtful"},
            "presenting": {"body": "confident", "arms": "one_extended", "hands": "open_palm"}
        }

    def customize_appearance(self, **kwargs):
        """Customizes the avatar's appearance.

        Args:
            **kwargs: Appearance attributes to modify
        """
        for key, value in kwargs.items():
            if key in self.appearance:
                self.appearance[key] = value
                self.logger.info(f"Updated {key} to {value}")
            else:
                self.logger.warning(f"Unknown appearance attribute: {key}")

    def set_expression(self, expression_name: str):
        """Sets the current facial expression.

        Args:
            expression_name (str): Name of the expression to set
        """
        if expression_name in self.expressions:
            self.current_expression = expression_name
            self.logger.info(f"Expression set to: {expression_name}")
            return self.expressions[expression_name]
        else:
            raise ValueError(f"Unknown expression: {expression_name}")

    def set_pose(self, pose_name: str):
        """Sets the current body pose.

        Args:
            pose_name (str): Name of the pose to set
        """
        if pose_name in self.poses:
            self.current_pose = pose_name
            self.logger.info(f"Pose set to: {pose_name}")
            return self.poses[pose_name]
        else:
            raise ValueError(f"Unknown pose: {pose_name}")

    def generate_avatar_config(self) -> Dict:
        """Generates a complete avatar configuration.

        Returns:
            Dict: Complete avatar configuration
        """
        config = {
            "name": self.name,
            "type": self.avatar_type,
            "appearance": self.appearance,
            "current_expression": getattr(self, 'current_expression', 'neutral'),
            "current_pose": getattr(self, 'current_pose', 'standing'),
            "expressions": self.expressions,
            "poses": self.poses,
            "assets_path": self.assets_path
        }
        
        self.logger.info("Avatar configuration generated")
        return config

    def save_config(self, filepath: str):
        """Saves avatar configuration to a JSON file.

        Args:
            filepath (str): Path to save the configuration file
        """
        config = self.generate_avatar_config()
        
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        with open(filepath, 'w') as f:
            json.dump(config, f, indent=2)
        
        self.logger.info(f"Avatar configuration saved to {filepath}")

    def load_config(self, filepath: str):
        """Loads avatar configuration from a JSON file.

        Args:
            filepath (str): Path to the configuration file
        """
        try:
            with open(filepath, 'r') as f:
                config = json.load(f)
            
            self.name = config.get('name', self.name)
            self.avatar_type = config.get('type', self.avatar_type)
            self.appearance = config.get('appearance', self.appearance)
            self.expressions = config.get('expressions', self.expressions)
            self.poses = config.get('poses', self.poses)
            self.assets_path = config.get('assets_path', self.assets_path)
            
            self.logger.info(f"Avatar configuration loaded from {filepath}")
            
        except FileNotFoundError:
            self.logger.error(f"Configuration file not found: {filepath}")
        except json.JSONDecodeError:
            self.logger.error(f"Invalid JSON in configuration file: {filepath}")

    def get_trading_expressions(self) -> List[str]:
        """Returns expressions suitable for trading scenarios.

        Returns:
            List[str]: List of trading-related expressions
        """
        trading_expressions = ["confident", "thinking", "excited", "worried"]
        return trading_expressions

    def get_presentation_poses(self) -> List[str]:
        """Returns poses suitable for presentations.

        Returns:
            List[str]: List of presentation-related poses
        """
        presentation_poses = ["presenting", "explaining", "pointing", "celebrating"]
        return presentation_poses

    def react_to_market_data(self, market_change: float) -> Tuple[str, str]:
        """Selects appropriate expression and pose based on market data.

        Args:
            market_change (float): Market change percentage

        Returns:
            Tuple[str, str]: (expression, pose) combination
        """
        if market_change > 5:
            return ("excited", "celebrating")
        elif market_change > 1:
            return ("happy", "presenting")
        elif market_change > -1:
            return ("neutral", "standing")
        elif market_change > -5:
            return ("thinking", "thinking_pose")
        else:
            return ("worried", "standing")

    def create_outfit_variations(self) -> Dict[str, Dict]:
        """Creates different outfit variations for the avatar.

        Returns:
            Dict[str, Dict]: Dictionary of outfit variations
        """
        outfits = {
            "crypto_trader": {
                "top": "business_blazer",
                "bottom": "smart_skirt",
                "colors": ["navy", "white", "gold"],
                "accessories": ["xrp_pendant", "lotus_hairpin"]
            },
            "casual_streamer": {
                "top": "hoodie",
                "bottom": "jeans",
                "colors": ["pink", "white", "blue"],
                "accessories": ["gaming_headset", "lotus_charm"]
            },
            "formal_presenter": {
                "top": "suit_jacket",
                "bottom": "dress_pants",
                "colors": ["black", "white", "silver"],
                "accessories": ["professional_watch", "lotus_brooch"]
            },
            "kawaii_mode": {
                "top": "frilly_dress",
                "bottom": "thigh_highs",
                "colors": ["pink", "white", "pastel_blue"],
                "accessories": ["cat_ears", "lotus_wand"]
            }
        }
        
        return outfits

if __name__ == "__main__":
    # Example usage
    avatar = Avatar("LotusXRP-chan")
    
    # Customize appearance
    avatar.customize_appearance(hair_color="#FF69B4", eye_color="#00CED1")
    
    # Set expression and pose
    avatar.set_expression("excited")
    avatar.set_pose("celebrating")
    
    # React to market data
    expression, pose = avatar.react_to_market_data(7.5)
    print(f"Market reaction: {expression} expression with {pose} pose")
    
    # Save configuration
    avatar.save_config("config/avatar_config.json")
    
    # Generate complete config
    config = avatar.generate_avatar_config()
    print(f"Avatar config: {json.dumps(config, indent=2)}")



    def add_custom_expression(self, name: str, attributes: Dict):
        """Adds a custom facial expression.

        Args:
            name (str): Name of the custom expression
            attributes (Dict): Dictionary of expression attributes (e.g., mouth, eyes)
        """
        self.expressions[name] = attributes
        self.logger.info(f"Custom expression added: {name}")



    def add_custom_pose(self, name: str, attributes: Dict):
        """Adds a custom body pose.

        Args:
            name (str): Name of the custom pose
            attributes (Dict): Dictionary of pose attributes (e.g., arm_left, arm_right)
        """
        self.poses[name] = attributes
        self.logger.info(f"Custom pose added: {name}")

