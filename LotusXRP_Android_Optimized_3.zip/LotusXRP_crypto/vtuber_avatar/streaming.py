"""
Streaming setup for live interaction with the VTuber avatar.

This module handles live streaming integration, chat interaction,
and real-time avatar control for broadcasting platforms.
"""

import asyncio
import websockets
import json
import threading
import time
from typing import Dict, List, Callable, Optional
import logging

class Streamer:
    def __init__(self, avatar, animator):
        self.avatar = avatar
        self.animator = animator
        self.is_streaming = False
        self.chat_enabled = True
        self.viewers = {}
        self.chat_history = []
        self.stream_config = self._default_stream_config()
        self.chat_commands = self._initialize_chat_commands()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)
        
        # WebSocket server for real-time communication
        self.websocket_server = None
        self.connected_clients = set()
        self.overlay_data = {}
        self.interaction_history = []

    def get_stream_status(self) -> Dict:
        """Returns streaming status."""
        return {
            "is_streaming": self.is_streaming,
            "connected_clients": len(self.connected_clients),
            "chat_messages": len(self.chat_history),
            "uptime": time.time() if self.is_streaming else 0
        }

    def add_chat_message(self, message: Dict):
        """Adds a chat message to the history."""
        self.chat_history.append(message)

    def process_chat_command(self, command_text: str) -> bool:
        """Processes a chat command (for testing purposes)."""
        command_parts = command_text.split()
        command = command_parts[0].lower()
        args = command_parts[1:] if len(command_parts) > 1 else []
        
        if command in self.chat_commands:
            # For testing, we'll just call the handler directly if it's not async
            # In real scenario, this would be awaited
            try:
                if asyncio.iscoroutinefunction(self.chat_commands[command]):
                    asyncio.run(self.chat_commands[command]("TestUser", args))
                else:
                    self.chat_commands[command]("TestUser", args)
                return True
            except Exception as e:
                self.logger.error(f"Error processing chat command {command}: {e}")
                return False
        return False

    def handle_donation(self, data: Dict):
        """Handles donation alerts (for testing purposes)."""
    def handle_donation(self, data: Dict):
        """Handles donation alerts (for testing purposes)."""
        self.logger.info(f"Test Donation received: {data}")
        # Simulate animation and chat response
        self.animator.play_animation("market_up")        self.add_chat_message({"user": "System", "message": f"Thanks for the donation {data.get('user')}"})
    def broadcast_message(self, message: Dict):
        """Broadcasts a message to all connected clients (for testing purposes)."""
        self.logger.info(f"Test Broadcast: {message}")

    def get_stream_analytics(self) -> Dict:
        """Returns streaming analytics."""
        return {
            "total_viewers": len(self.viewers),
            "peak_viewers": 0, # Placeholder
            "chat_messages": len(self.chat_history),
            "donations_received": 0 # Placeholder
        }   def _default_stream_config(self) -> Dict:
        """Returns default streaming configuration."""
        return {
            "platform": "custom",  # Could be "twitch", "youtube", "custom"
            "resolution": "1920x1080",
            "fps": 60,
            "bitrate": 6000,
            "audio_enabled": True,
            "chat_overlay": True,
            "donation_alerts": True,
            "auto_responses": True,
            "moderation": {
                "enabled": True,
                "banned_words": ["spam", "hate"],
                "timeout_duration": 300
            }
        }

    def _initialize_chat_commands(self) -> Dict:
        """Initializes chat command handlers."""
        return {
            "!hello": self._cmd_hello,
            "!price": self._cmd_price,
            "!portfolio": self._cmd_portfolio,
            "!dance": self._cmd_dance,
            "!expression": self._cmd_expression,
            "!pose": self._cmd_pose,
            "!help": self._cmd_help,
            "!market": self._cmd_market,
            "!prediction": self._cmd_prediction
        }

    async def start_stream(self, host: str = "localhost", port: int = 8765):
        """Starts the streaming server.

        Args:
            host (str): Server host address
            port (int): Server port
        """
        self.is_streaming = True
        self.logger.info(f"Starting stream server on {host}:{port}")
        
        # Start WebSocket server
        self.websocket_server = await websockets.serve(
            self._handle_websocket_connection,
            host,
            port
        )
        
        # Start background tasks
        asyncio.create_task(self._stream_loop())
        asyncio.create_task(self._chat_processor())
        
        self.logger.info("Stream server started successfully")

    async def _handle_websocket_connection(self, websocket, path):
        """Handles new WebSocket connections.

        Args:
            websocket: WebSocket connection
            path: Connection path
        """
        self.connected_clients.add(websocket)
        client_id = id(websocket)
        self.logger.info(f"New client connected: {client_id}")
        
        try:
            # Send initial avatar state
            await self._send_avatar_state(websocket)
            
            async for message in websocket:
                await self._process_websocket_message(websocket, message)
                
        except websockets.exceptions.ConnectionClosed:
            self.logger.info(f"Client disconnected: {client_id}")
        finally:
            self.connected_clients.discard(websocket)

    async def _process_websocket_message(self, websocket, message: str):
        """Processes incoming WebSocket messages.

        Args:
            websocket: WebSocket connection
            message (str): Incoming message
        """
        try:
            data = json.loads(message)
            message_type = data.get("type")
            
            if message_type == "chat":
                await self._handle_chat_message(data)
            elif message_type == "command":
                await self._handle_command(data)
            elif message_type == "donation":
                await self._handle_donation(data)
            elif message_type == "viewer_update":
                await self._handle_viewer_update(data)
                
        except json.JSONDecodeError:
            self.logger.warning(f"Invalid JSON received: {message}")

    async def _handle_chat_message(self, data: Dict):
        """Handles incoming chat messages.

        Args:
            data (Dict): Chat message data
        """
        username = data.get("username", "Anonymous")
        message = data.get("message", "")
        timestamp = time.time()
        
        # Store chat message
        chat_entry = {
            "username": username,
            "message": message,
            "timestamp": timestamp,
            "type": "chat"
        }
        self.chat_history.append(chat_entry)
        
        # Check for commands
        if message.startswith("!"):
            await self._process_chat_command(username, message)
        else:
            # Process regular chat for auto-responses
            await self._process_regular_chat(username, message)
        
        # Broadcast to all clients
        await self._broadcast_message(chat_entry)

    async def _process_chat_command(self, username: str, message: str):
        """Processes chat commands.

        Args:
            username (str): User who sent the command
            message (str): Command message
        """
        command_parts = message.split()
        command = command_parts[0].lower()
        args = command_parts[1:] if len(command_parts) > 1 else []
        
        if command in self.chat_commands:
            response = await self.chat_commands[command](username, args)
            if response:
                await self._send_chat_response(response)
        else:
            await self._send_chat_response(f"Unknown command: {command}. Type !help for available commands.")

    async def _process_regular_chat(self, username: str, message: str):
        """Processes regular chat messages for auto-responses.

        Args:
            username (str): Username
            message (str): Chat message
        """
        message_lower = message.lower()
        
        # Auto-response triggers
        if any(word in message_lower for word in ["hello", "hi", "hey"]):
            self.animator.play_animation("greeting")
            await self._send_chat_response(f"Hello {username}! Welcome to the stream! 💖")
        
        elif any(word in message_lower for word in ["price", "xrp", "lotus"]):
            self.animator.play_animation("explaining")
            await self._send_chat_response("Let me check the latest market data for you! 📈")
        
        elif any(word in message_lower for word in ["cute", "kawaii", "adorable"]):
            self.animator.play_animation("market_up")  # Happy animation
            await self._send_chat_response("Aww, thank you! You're so sweet! (◕‿◕)♡")

    # Chat command handlers
    async def _cmd_hello(self, username: str, args: List[str]) -> str:
        """Hello command handler."""
        self.animator.play_animation("greeting")
        return f"Hello {username}! Thanks for joining the LotusXRP stream! 🌸"

    async def _cmd_price(self, username: str, args: List[str]) -> str:
        """Price command handler."""
        self.animator.play_animation("explaining")
        # This would integrate with actual price API
        return "XRP: $0.52 (+2.3%) | LOTUS: Building value through innovation! 💎"

    async def _cmd_portfolio(self, username: str, args: List[str]) -> str:
        """Portfolio command handler."""
        self.animator.play_animation("presenting")
        return "Our AI trading bot is currently managing a diversified crypto portfolio. Performance: +15.7% this month! 📊"

    async def _cmd_dance(self, username: str, args: List[str]) -> str:
        """Dance command handler."""
        self.animator.play_animation("market_up")
        return f"{username} requested a dance! Let's celebrate! 💃✨"

    async def _cmd_expression(self, username: str, args: List[str]) -> str:
        """Expression command handler."""
        if args:
            expression = args[0]
            self.avatar.set_expression(expression)
            return f"Expression changed to: {expression}"
        return "Usage: !expression <expression_name>"

    async def _cmd_pose(self, username: str, args: List[str]) -> str:
        """Pose command handler."""
        if args:
            pose = args[0]
            self.avatar.set_pose(pose)
            return f"Pose changed to: {pose}"
        return "Usage: !pose <pose_name>"

    async def _cmd_help(self, username: str, args: List[str]) -> str:
        """Help command handler."""
        commands = ", ".join(self.chat_commands.keys())
        return f"Available commands: {commands}"

    async def _cmd_market(self, username: str, args: List[str]) -> str:
        """Market command handler."""
        self.animator.play_animation("explaining")
        return "Market analysis: Crypto showing bullish patterns. Our AI suggests cautious optimism! 📈🤖"

    async def _cmd_prediction(self, username: str, args: List[str]) -> str:
        """Prediction command handler."""
        self.animator.play_animation("thinking")
        return "AI Prediction: 65% probability of upward movement in the next 24h. Remember: Not financial advice! 🔮"

    async def _send_chat_response(self, message: str):
        """Sends a chat response from the avatar.

        Args:
            message (str): Response message
        """
        response = {
            "type": "chat",
            "username": self.avatar.name,
            "message": message,
            "timestamp": time.time(),
            "is_avatar": True
        }
        
        self.chat_history.append(response)
        await self._broadcast_message(response)

    async def _handle_donation(self, data: Dict):
        """Handles donation alerts.

        Args:
            data (Dict): Donation data
        """
        username = data.get("username", "Anonymous")
        amount = data.get("amount", 0)
        message = data.get("message", "")
        
        # Play celebration animation
        self.animator.play_animation("market_up")
        
        # Send thank you message
        thank_you = f"Thank you so much {username} for the ${amount} donation! {message} 💖✨"
        await self._send_chat_response(thank_you)
        
        # Log donation
        self.logger.info(f"Donation received: ${amount} from {username}")

    async def _handle_viewer_update(self, data: Dict):
        """Handles viewer count updates.

        Args:
            data (Dict): Viewer data
        """
        viewer_count = data.get("count", 0)
        self.logger.info(f"Viewer count updated: {viewer_count}")

    async def _send_avatar_state(self, websocket):
        """Sends current avatar state to a client.

        Args:
            websocket: WebSocket connection
        """
        avatar_state = {
            "type": "avatar_state",
            "config": self.avatar.generate_avatar_config(),
            "animation_status": self.animator.get_animation_status()
        }
        
        await websocket.send(json.dumps(avatar_state))

    async def _broadcast_message(self, message: Dict):
        """Broadcasts a message to all connected clients.

        Args:
            message (Dict): Message to broadcast
        """
        if self.connected_clients:
            message_json = json.dumps(message)
            await asyncio.gather(
                *[client.send(message_json) for client in self.connected_clients],
                return_exceptions=True
            )

    async def _stream_loop(self):
        """Main streaming loop."""
        while self.is_streaming:
            # Update avatar state
            avatar_state = {
                "type": "avatar_update",
                "config": self.avatar.generate_avatar_config(),
                "animation_status": self.animator.get_animation_status(),
                "timestamp": time.time()
            }
            
            await self._broadcast_message(avatar_state)
            await asyncio.sleep(0.033)  # ~30 FPS updates

    async def _chat_processor(self):
        """Processes chat messages and triggers responses."""
        while self.is_streaming:
            # Clean old chat history (keep last 100 messages)
            if len(self.chat_history) > 100:
                self.chat_history = self.chat_history[-100:]
            
            await asyncio.sleep(1)

    def stop_stream(self):
        """Stops the streaming server."""
        self.is_streaming = False
        if self.websocket_server:
            self.websocket_server.close()
        self.logger.info("Stream stopped")

    def get_stream_stats(self) -> Dict:
        """Returns streaming statistics.

        Returns:
            Dict: Stream statistics
        """
        return {
            "is_streaming": self.is_streaming,
            "connected_clients": len(self.connected_clients),
            "chat_messages": len(self.chat_history),
            "uptime": time.time() if self.is_streaming else 0
        }

    def moderate_chat(self, message: str) -> bool:
        """Moderates chat messages.

        Args:
            message (str): Message to moderate

        Returns:
            bool: True if message is allowed, False if blocked
        """
        if not self.stream_config["moderation"]["enabled"]:
            return True
        
        message_lower = message.lower()
        banned_words = self.stream_config["moderation"]["banned_words"]
        
        for word in banned_words:
            if word in message_lower:
                self.logger.warning(f"Message blocked for banned word: {word}")
                return False
        
        return True

    def add_chat_command(self, command: str, handler: Callable):
        """Adds a custom chat command.

        Args:
            command (str): Command name (with !)
            handler (Callable): Command handler function
        """
        self.chat_commands[command] = handler
        self.logger.info(f"Chat command added: {command}")

if __name__ == "__main__":
    # Example usage
    from avatar import Avatar
    from animation import Animator
    
    # Create avatar and animator
    avatar = Avatar("LotusXRP-chan")
    animator = Animator(avatar.generate_avatar_config())
    
    # Create streamer
    streamer = Streamer(avatar, animator)
    
    # Start streaming server
    async def main():
        await streamer.start_stream()
        
        # Keep running
        try:
            await asyncio.Future()  # Run forever
        except KeyboardInterrupt:
            streamer.stop_stream()
    
    # Run the streaming server
    asyncio.run(main())

