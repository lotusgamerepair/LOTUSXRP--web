// Android-specific optimizations for LotusXRP Crypto Platform
class AndroidOptimizations {
    constructor() {
        this.isAndroid = /Android/i.test(navigator.userAgent);
        this.androidVersion = this.getAndroidVersion();
        this.isWebView = this.isAndroidWebView();
        this.init();
    }
    
    init() {
        if (!this.isAndroid) return;
        
        console.log('Initializing Android optimizations...');
        console.log('Android version:', this.androidVersion);
        console.log('Is WebView:', this.isWebView);
        
        this.optimizePerformance();
        this.setupAndroidFeatures();
        this.optimizeMemoryUsage();
        this.setupBatteryOptimizations();
        this.setupNetworkOptimizations();
        this.setupAndroidSpecificUI();
    }
    
    getAndroidVersion() {
        const match = navigator.userAgent.match(/Android (\d+(?:\.\d+)?)/);
        return match ? parseFloat(match[1]) : 0;
    }
    
    isAndroidWebView() {
        return /wv|WebView/i.test(navigator.userAgent);
    }
    
    optimizePerformance() {
        // Reduce animation complexity on older Android versions
        if (this.androidVersion < 7.0) {
            document.documentElement.style.setProperty('--animation-duration', '0.1s');
            document.body.classList.add('reduced-animations');
        }
        
        // Optimize scroll performance
        this.optimizeScrolling();
        
        // Reduce memory usage for images
        this.optimizeImages();
        
        // Implement lazy loading for heavy components
        this.implementLazyLoading();
    }
    
    optimizeScrolling() {
        // Use passive event listeners for better scroll performance
        const scrollElements = document.querySelectorAll('[data-scroll-optimized]');
        scrollElements.forEach(element => {
            element.addEventListener('scroll', this.handleScroll.bind(this), { passive: true });
        });
        
        // Add momentum scrolling for iOS-like experience
        document.body.style.webkitOverflowScrolling = 'touch';
        
        // Optimize scroll containers
        const scrollContainers = document.querySelectorAll('.scroll-container');
        scrollContainers.forEach(container => {
            container.style.transform = 'translateZ(0)'; // Force hardware acceleration
            container.style.willChange = 'scroll-position';
        });
    }
    
    handleScroll(event) {
        // Throttled scroll handler for performance
        if (this.scrollTimeout) return;
        
        this.scrollTimeout = setTimeout(() => {
            // Handle scroll events here
            this.scrollTimeout = null;
        }, 16); // ~60fps
    }
    
    optimizeImages() {
        // Implement WebP support detection and fallback
        const supportsWebP = this.supportsWebP();
        
        const images = document.querySelectorAll('img[data-src]');
        images.forEach(img => {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const src = supportsWebP ? 
                            entry.target.dataset.webpSrc || entry.target.dataset.src :
                            entry.target.dataset.src;
                        
                        entry.target.src = src;
                        entry.target.classList.add('loaded');
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                rootMargin: '50px'
            });
            
            observer.observe(img);
        });
    }
    
    supportsWebP() {
        const canvas = document.createElement('canvas');
        canvas.width = 1;
        canvas.height = 1;
        return canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0;
    }
    
    implementLazyLoading() {
        // Lazy load heavy components
        const lazyComponents = document.querySelectorAll('[data-lazy-component]');
        
        const componentObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const componentType = entry.target.dataset.lazyComponent;
                    this.loadComponent(componentType, entry.target);
                    componentObserver.unobserve(entry.target);
                }
            });
        }, {
            rootMargin: '100px'
        });
        
        lazyComponents.forEach(component => {
            componentObserver.observe(component);
        });
    }
    
    loadComponent(type, element) {
        switch (type) {
            case 'chart':
                this.loadChartComponent(element);
                break;
            case 'trading-widget':
                this.loadTradingWidget(element);
                break;
            case 'avatar-stream':
                this.loadAvatarStream(element);
                break;
            default:
                console.warn('Unknown lazy component type:', type);
        }
    }
    
    loadChartComponent(element) {
        // Load chart library and render chart
        element.innerHTML = '<div class="chart-placeholder">Loading chart...</div>';
        // Actual chart loading would happen here
    }
    
    loadTradingWidget(element) {
        // Load trading widget
        element.innerHTML = '<div class="trading-widget-placeholder">Loading trading widget...</div>';
    }
    
    loadAvatarStream(element) {
        // Load avatar stream component
        element.innerHTML = '<div class="avatar-stream-placeholder">Loading avatar stream...</div>';
    }
    
    setupAndroidFeatures() {
        // Setup Android-specific features
        this.setupAndroidBackButton();
        this.setupAndroidKeyboard();
        this.setupAndroidNotifications();
        this.setupAndroidShare();
        this.setupAndroidFullscreen();
    }
    
    setupAndroidBackButton() {
        // Handle Android back button
        let backButtonHandlers = [];
        
        window.addBackButtonHandler = (handler) => {
            backButtonHandlers.push(handler);
        };
        
        window.removeBackButtonHandler = (handler) => {
            const index = backButtonHandlers.indexOf(handler);
            if (index > -1) {
                backButtonHandlers.splice(index, 1);
            }
        };
        
        window.addEventListener('popstate', (event) => {
            // Call the most recent handler first
            for (let i = backButtonHandlers.length - 1; i >= 0; i--) {
                if (backButtonHandlers[i](event)) {
                    event.preventDefault();
                    return;
                }
            }
        });
    }
    
    setupAndroidKeyboard() {
        // Handle Android keyboard better
        let initialViewportHeight = window.innerHeight;
        let keyboardHeight = 0;
        
        const handleResize = () => {
            const currentHeight = window.innerHeight;
            const heightDiff = initialViewportHeight - currentHeight;
            
            if (heightDiff > 150) {
                // Keyboard is open
                keyboardHeight = heightDiff;
                document.body.classList.add('keyboard-open');
                document.body.style.setProperty('--keyboard-height', `${keyboardHeight}px`);
                
                // Scroll active input into view
                const activeElement = document.activeElement;
                if (activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA')) {
                    setTimeout(() => {
                        activeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }, 300);
                }
            } else {
                // Keyboard is closed
                keyboardHeight = 0;
                document.body.classList.remove('keyboard-open');
                document.body.style.removeProperty('--keyboard-height');
            }
        };
        
        window.addEventListener('resize', handleResize);
        
        // Handle input focus/blur
        document.addEventListener('focusin', (event) => {
            if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
                event.target.classList.add('input-focused');
            }
        });
        
        document.addEventListener('focusout', (event) => {
            if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
                event.target.classList.remove('input-focused');
            }
        });
    }
    
    setupAndroidNotifications() {
        // Enhanced notification support for Android
        if ('Notification' in window) {
            // Request permission if not already granted
            if (Notification.permission === 'default') {
                Notification.requestPermission().then(permission => {
                    console.log('Notification permission:', permission);
                });
            }
            
            // Setup notification channels (Android 8.0+)
            if ('serviceWorker' in navigator && this.androidVersion >= 8.0) {
                navigator.serviceWorker.ready.then(registration => {
                    // Setup notification channels
                    this.setupNotificationChannels(registration);
                });
            }
        }
    }
    
    setupNotificationChannels(registration) {
        // Define notification channels for different types
        const channels = [
            {
                id: 'trading-alerts',
                name: 'Trading Alerts',
                description: 'Notifications about trading activities',
                importance: 'high'
            },
            {
                id: 'price-alerts',
                name: 'Price Alerts',
                description: 'Cryptocurrency price notifications',
                importance: 'default'
            },
            {
                id: 'governance-updates',
                name: 'Governance Updates',
                description: 'DAO governance notifications',
                importance: 'low'
            }
        ];
        
        // Store channel configuration
        localStorage.setItem('notification-channels', JSON.stringify(channels));
    }
    
    setupAndroidShare() {
        // Enhanced sharing for Android
        if (navigator.share) {
            window.shareContent = async (data) => {
                try {
                    await navigator.share(data);
                    return true;
                } catch (error) {
                    console.error('Share failed:', error);
                    return false;
                }
            };
        } else {
            // Fallback sharing
            window.shareContent = (data) => {
                const url = encodeURIComponent(data.url || window.location.href);
                const text = encodeURIComponent(data.text || '');
                const title = encodeURIComponent(data.title || document.title);
                
                // Try different sharing methods
                const shareUrl = `https://api.whatsapp.com/send?text=${text}%20${url}`;
                window.open(shareUrl, '_blank');
                return true;
            };
        }
    }
    
    setupAndroidFullscreen() {
        // Setup fullscreen support
        const fullscreenAPI = this.getFullscreenAPI();
        
        if (fullscreenAPI) {
            window.enterFullscreen = () => {
                const element = document.documentElement;
                if (element[fullscreenAPI.requestFullscreen]) {
                    element[fullscreenAPI.requestFullscreen]();
                }
            };
            
            window.exitFullscreen = () => {
                if (document[fullscreenAPI.exitFullscreen]) {
                    document[fullscreenAPI.exitFullscreen]();
                }
            };
            
            window.isFullscreen = () => {
                return !!document[fullscreenAPI.fullscreenElement];
            };
        }
    }
    
    getFullscreenAPI() {
        const apis = [
            {
                requestFullscreen: 'requestFullscreen',
                exitFullscreen: 'exitFullscreen',
                fullscreenElement: 'fullscreenElement'
            },
            {
                requestFullscreen: 'webkitRequestFullscreen',
                exitFullscreen: 'webkitExitFullscreen',
                fullscreenElement: 'webkitFullscreenElement'
            },
            {
                requestFullscreen: 'mozRequestFullScreen',
                exitFullscreen: 'mozCancelFullScreen',
                fullscreenElement: 'mozFullScreenElement'
            }
        ];
        
        for (const api of apis) {
            if (api.requestFullscreen in document.documentElement) {
                return api;
            }
        }
        
        return null;
    }
    
    optimizeMemoryUsage() {
        // Implement memory optimization strategies
        this.setupMemoryMonitoring();
        this.implementObjectPooling();
        this.setupGarbageCollection();
    }
    
    setupMemoryMonitoring() {
        // Monitor memory usage (if available)
        if ('memory' in performance) {
            setInterval(() => {
                const memory = performance.memory;
                const memoryUsage = {
                    used: Math.round(memory.usedJSHeapSize / 1048576), // MB
                    total: Math.round(memory.totalJSHeapSize / 1048576), // MB
                    limit: Math.round(memory.jsHeapSizeLimit / 1048576) // MB
                };
                
                // Log memory usage for debugging
                console.debug('Memory usage:', memoryUsage);
                
                // Trigger cleanup if memory usage is high
                if (memoryUsage.used / memoryUsage.limit > 0.8) {
                    this.triggerMemoryCleanup();
                }
            }, 30000); // Check every 30 seconds
        }
    }
    
    implementObjectPooling() {
        // Simple object pooling for frequently created objects
        window.ObjectPool = class {
            constructor(createFn, resetFn, initialSize = 10) {
                this.createFn = createFn;
                this.resetFn = resetFn;
                this.pool = [];
                
                // Pre-populate pool
                for (let i = 0; i < initialSize; i++) {
                    this.pool.push(this.createFn());
                }
            }
            
            get() {
                return this.pool.length > 0 ? this.pool.pop() : this.createFn();
            }
            
            release(obj) {
                if (this.resetFn) {
                    this.resetFn(obj);
                }
                this.pool.push(obj);
            }
        };
    }
    
    setupGarbageCollection() {
        // Periodic cleanup of unused objects
        setInterval(() => {
            this.triggerMemoryCleanup();
        }, 60000); // Every minute
    }
    
    triggerMemoryCleanup() {
        // Clear caches
        if ('caches' in window) {
            caches.keys().then(names => {
                names.forEach(name => {
                    if (name.includes('old') || name.includes('temp')) {
                        caches.delete(name);
                    }
                });
            });
        }
        
        // Clear old localStorage items
        this.cleanupLocalStorage();
        
        // Force garbage collection (if available)
        if (window.gc) {
            window.gc();
        }
    }
    
    cleanupLocalStorage() {
        const now = Date.now();
        const maxAge = 7 * 24 * 60 * 60 * 1000; // 7 days
        
        for (let i = localStorage.length - 1; i >= 0; i--) {
            const key = localStorage.key(i);
            if (key && key.startsWith('temp_')) {
                try {
                    const item = JSON.parse(localStorage.getItem(key));
                    if (item.timestamp && (now - item.timestamp) > maxAge) {
                        localStorage.removeItem(key);
                    }
                } catch (e) {
                    // Remove invalid items
                    localStorage.removeItem(key);
                }
            }
        }
    }
    
    setupBatteryOptimizations() {
        // Battery-aware optimizations
        if ('getBattery' in navigator) {
            navigator.getBattery().then(battery => {
                this.optimizeForBattery(battery);
                
                battery.addEventListener('levelchange', () => {
                    this.optimizeForBattery(battery);
                });
                
                battery.addEventListener('chargingchange', () => {
                    this.optimizeForBattery(battery);
                });
            });
        }
    }
    
    optimizeForBattery(battery) {
        const isLowBattery = battery.level < 0.2;
        const isCharging = battery.charging;
        
        if (isLowBattery && !isCharging) {
            // Enable power saving mode
            document.body.classList.add('power-saving');
            
            // Reduce refresh rates
            if (window.lotusXRPDashboard) {
                window.lotusXRPDashboard.refreshInterval = 30000; // 30 seconds
            }
            
            // Disable animations
            document.body.classList.add('reduced-animations');
            
            console.log('Power saving mode enabled');
        } else {
            // Disable power saving mode
            document.body.classList.remove('power-saving');
            document.body.classList.remove('reduced-animations');
            
            // Restore normal refresh rates
            if (window.lotusXRPDashboard) {
                window.lotusXRPDashboard.refreshInterval = 10000; // 10 seconds
            }
        }
    }
    
    setupNetworkOptimizations() {
        // Network-aware optimizations
        if ('connection' in navigator) {
            const connection = navigator.connection;
            this.optimizeForConnection(connection);
            
            connection.addEventListener('change', () => {
                this.optimizeForConnection(connection);
            });
        }
    }
    
    optimizeForConnection(connection) {
        const isSlowConnection = connection.effectiveType === 'slow-2g' || 
                               connection.effectiveType === '2g' ||
                               connection.downlink < 1;
        
        if (isSlowConnection) {
            // Enable data saving mode
            document.body.classList.add('data-saving');
            
            // Reduce image quality
            const images = document.querySelectorAll('img');
            images.forEach(img => {
                if (img.dataset.lowQualitySrc) {
                    img.src = img.dataset.lowQualitySrc;
                }
            });
            
            // Increase refresh intervals
            if (window.lotusXRPDashboard) {
                window.lotusXRPDashboard.refreshInterval = 60000; // 1 minute
            }
            
            console.log('Data saving mode enabled');
        } else {
            // Disable data saving mode
            document.body.classList.remove('data-saving');
            
            // Restore normal refresh intervals
            if (window.lotusXRPDashboard) {
                window.lotusXRPDashboard.refreshInterval = 10000; // 10 seconds
            }
        }
    }
    
    setupAndroidSpecificUI() {
        // Add Android-specific UI enhancements
        this.setupMaterialDesignElements();
        this.setupAndroidStatusBar();
        this.setupAndroidNavigation();
    }
    
    setupMaterialDesignElements() {
        // Add Material Design ripple effects
        const buttons = document.querySelectorAll('button, .touch-button');
        buttons.forEach(button => {
            button.addEventListener('touchstart', this.createRipple.bind(this));
        });
    }
    
    createRipple(event) {
        const button = event.currentTarget;
        const ripple = document.createElement('span');
        const rect = button.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = event.touches[0].clientX - rect.left - size / 2;
        const y = event.touches[0].clientY - rect.top - size / 2;
        
        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        ripple.classList.add('ripple');
        
        button.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 600);
    }
    
    setupAndroidStatusBar() {
        // Configure Android status bar
        const metaThemeColor = document.querySelector('meta[name="theme-color"]');
        if (metaThemeColor) {
            // Dynamic theme color based on current page
            const updateThemeColor = () => {
                const primaryColor = getComputedStyle(document.documentElement)
                    .getPropertyValue('--primary-color') || '#667eea';
                metaThemeColor.content = primaryColor;
            };
            
            updateThemeColor();
            
            // Update on route changes
            window.addEventListener('popstate', updateThemeColor);
        }
    }
    
    setupAndroidNavigation() {
        // Setup Android-style navigation
        const navItems = document.querySelectorAll('.mobile-nav-item');
        navItems.forEach(item => {
            item.addEventListener('touchstart', () => {
                item.classList.add('nav-item-pressed');
            });
            
            item.addEventListener('touchend', () => {
                item.classList.remove('nav-item-pressed');
            });
            
            item.addEventListener('touchcancel', () => {
                item.classList.remove('nav-item-pressed');
            });
        });
    }
}

// Initialize Android optimizations when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.androidOptimizations = new AndroidOptimizations();
});

// Export for global access
window.AndroidOptimizations = AndroidOptimizations;

