
// Dashboard JavaScript with PWA Support and Android Optimizations
class LotusXRPDashboard {
    constructor() {
        this.refreshInterval = 5000;
        this.isOnline = navigator.onLine;
        this.offlineData = this.loadOfflineData();
        this.isAndroid = /Android/i.test(navigator.userAgent);
        this.isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        this.touchStartY = 0;
        this.touchEndY = 0;
        this.init();
        this.initPWA();
        this.initMobileFeatures();
    }
    
    init() {
        this.loadDashboardData();
        setInterval(() => this.loadDashboardData(), this.refreshInterval);
        
        // Listen for online/offline events
        window.addEventListener('online', () => this.handleOnline());
        window.addEventListener('offline', () => this.handleOffline());
        
        // Initialize connection status indicator
        this.updateConnectionStatus();
    }
    
    initPWA() {
        // Register service worker
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/static/sw.js')
                .then(registration => {
                    console.log('Service Worker registered:', registration);
                    
                    // Check for updates
                    registration.addEventListener('updatefound', () => {
                        const newWorker = registration.installing;
                        newWorker.addEventListener('statechange', () => {
                            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                                this.showUpdateNotification();
                            }
                        });
                    });
                })
                .catch(error => {
                    console.error('Service Worker registration failed:', error);
                });
        }
        
        // Handle app install prompt
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            this.deferredPrompt = e;
            this.showInstallButton();
        });
        
        // Handle app installed
        window.addEventListener('appinstalled', () => {
            console.log('PWA was installed');
            this.hideInstallButton();
            this.showNotification('App installed successfully!', 'success');
        });
    }
    
    initMobileFeatures() {
        if (!this.isMobile) return;
        
        // Add touch gesture support
        this.initTouchGestures();
        
        // Add Android-specific features
        if (this.isAndroid) {
            this.initAndroidFeatures();
        }
        
        // Add mobile-specific event listeners
        this.initMobileEventListeners();
        
        // Optimize for mobile performance
        this.optimizeForMobile();
        
        // Add haptic feedback support
        this.initHapticFeedback();
    }
    
    initTouchGestures() {
        // Pull-to-refresh functionality
        document.addEventListener('touchstart', (e) => {
            this.touchStartY = e.touches[0].clientY;
        }, { passive: true });
        
        document.addEventListener('touchmove', (e) => {
            if (window.scrollY === 0 && e.touches[0].clientY > this.touchStartY + 100) {
                this.showPullToRefreshIndicator();
            }
        }, { passive: true });
        
        document.addEventListener('touchend', (e) => {
            this.touchEndY = e.changedTouches[0].clientY;
            
            // Pull to refresh
            if (window.scrollY === 0 && this.touchEndY > this.touchStartY + 100) {
                this.handlePullToRefresh();
            }
            
            this.hidePullToRefreshIndicator();
        }, { passive: true });
        
        // Swipe gestures for navigation
        let startX = 0;
        let startY = 0;
        
        document.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
        }, { passive: true });
        
        document.addEventListener('touchend', (e) => {
            const endX = e.changedTouches[0].clientX;
            const endY = e.changedTouches[0].clientY;
            const diffX = startX - endX;
            const diffY = startY - endY;
            
            // Only trigger swipe if horizontal movement is greater than vertical
            if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
                if (diffX > 0) {
                    // Swipe left - next section
                    this.handleSwipeLeft();
                } else {
                    // Swipe right - previous section
                    this.handleSwipeRight();
                }
            }
        }, { passive: true });
    }
    
    initAndroidFeatures() {
        // Add Android-specific optimizations
        
        // Handle Android back button
        if (window.history && window.history.pushState) {
            window.addEventListener('popstate', (e) => {
                this.handleAndroidBackButton(e);
            });
        }
        
        // Add Android share functionality
        if (navigator.share) {
            this.addShareButton();
        }
        
        // Handle Android keyboard
        this.handleAndroidKeyboard();
        
        // Add Android notification support
        this.initAndroidNotifications();
    }
    
    initMobileEventListeners() {
        // Prevent zoom on double tap for specific elements
        const preventZoomElements = document.querySelectorAll('.touch-button, .card-hover');
        preventZoomElements.forEach(element => {
            element.addEventListener('touchend', (e) => {
                e.preventDefault();
                element.click();
            });
        });
        
        // Handle orientation change
        window.addEventListener('orientationchange', () => {
            setTimeout(() => {
                this.handleOrientationChange();
            }, 100);
        });
        
        // Handle visibility change (app backgrounding)
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.handleAppBackground();
            } else {
                this.handleAppForeground();
            }
        });
    }
    
    optimizeForMobile() {
        // Reduce refresh interval on mobile to save battery
        if (this.isMobile) {
            this.refreshInterval = 10000; // 10 seconds instead of 5
        }
        
        // Add mobile-specific CSS classes
        document.body.classList.add('mobile-optimized');
        if (this.isAndroid) {
            document.body.classList.add('android-optimized');
        }
        
        // Optimize images for mobile
        this.optimizeImagesForMobile();
        
        // Add mobile-specific meta tags
        this.addMobileMeta();
    }
    
    initHapticFeedback() {
        // Add haptic feedback for button interactions
        if ('vibrate' in navigator) {
            const buttons = document.querySelectorAll('button, .touch-button');
            buttons.forEach(button => {
                button.addEventListener('click', () => {
                    navigator.vibrate(50); // Short vibration
                });
            });
        }
    }
    
    showPullToRefreshIndicator() {
        let indicator = document.getElementById('pull-to-refresh-indicator');
        if (!indicator) {
            indicator = document.createElement('div');
            indicator.id = 'pull-to-refresh-indicator';
            indicator.className = 'fixed top-16 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-4 py-2 rounded-full shadow-lg z-50 transition-all duration-300';
            indicator.innerHTML = '<i class="fas fa-arrow-down mr-2"></i>Pull to refresh';
            document.body.appendChild(indicator);
        }
        indicator.style.display = 'block';
        indicator.style.opacity = '1';
    }
    
    hidePullToRefreshIndicator() {
        const indicator = document.getElementById('pull-to-refresh-indicator');
        if (indicator) {
            indicator.style.opacity = '0';
            setTimeout(() => {
                indicator.style.display = 'none';
            }, 300);
        }
    }
    
    handlePullToRefresh() {
        this.showNotification('Refreshing...', 'info');
        this.loadDashboardData();
        
        // Haptic feedback
        if ('vibrate' in navigator) {
            navigator.vibrate(100);
        }
    }
    
    handleSwipeLeft() {
        // Navigate to next section or page
        console.log('Swipe left detected');
        // Implementation depends on your navigation structure
    }
    
    handleSwipeRight() {
        // Navigate to previous section or page
        console.log('Swipe right detected');
        // Implementation depends on your navigation structure
    }
    
    handleAndroidBackButton(e) {
        // Handle Android back button behavior
        const mobileMenu = document.getElementById('mobile-menu');
        if (mobileMenu && mobileMenu.classList.contains('active')) {
            e.preventDefault();
            this.closeMobileMenu();
            return;
        }
        
        // Add custom back button behavior here
        console.log('Android back button pressed');
    }
    
    addShareButton() {
        const shareButton = document.createElement('button');
        shareButton.className = 'fixed bottom-20 right-4 bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-3 rounded-full shadow-lg z-50 touch-target';
        shareButton.innerHTML = '<i class="fas fa-share-alt"></i>';
        shareButton.onclick = () => this.shareApp();
        document.body.appendChild(shareButton);
    }
    
    async shareApp() {
        if (navigator.share) {
            try {
                await navigator.share({
                    title: 'LotusXRP Crypto Platform',
                    text: 'Check out this amazing crypto trading platform with AI and VTuber features!',
                    url: window.location.href
                });
            } catch (error) {
                console.log('Error sharing:', error);
            }
        }
    }
    
    handleAndroidKeyboard() {
        // Handle Android keyboard showing/hiding
        let initialViewportHeight = window.innerHeight;
        
        window.addEventListener('resize', () => {
            const currentViewportHeight = window.innerHeight;
            const heightDifference = initialViewportHeight - currentViewportHeight;
            
            if (heightDifference > 150) {
                // Keyboard is likely open
                document.body.classList.add('keyboard-open');
            } else {
                // Keyboard is likely closed
                document.body.classList.remove('keyboard-open');
            }
        });
    }
    
    initAndroidNotifications() {
        // Request notification permission for Android
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission().then(permission => {
                if (permission === 'granted') {
                    console.log('Notification permission granted');
                }
            });
        }
    }
    
    handleOrientationChange() {
        // Handle orientation change
        const orientation = screen.orientation || screen.mozOrientation || screen.msOrientation;
        
        if (orientation) {
            const angle = orientation.angle || window.orientation;
            console.log('Orientation changed to:', angle);
            
            // Trigger layout recalculation
            window.dispatchEvent(new Event('resize'));
        }
    }
    
    handleAppBackground() {
        // App is going to background - reduce activity
        console.log('App backgrounded');
        
        // Pause non-essential updates
        if (this.refreshIntervalId) {
            clearInterval(this.refreshIntervalId);
        }
    }
    
    handleAppForeground() {
        // App is coming to foreground - resume activity
        console.log('App foregrounded');
        
        // Resume updates
        this.loadDashboardData();
        this.refreshIntervalId = setInterval(() => this.loadDashboardData(), this.refreshInterval);
    }
    
    optimizeImagesForMobile() {
        // Add lazy loading for images
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            img.loading = 'lazy';
        });
    }
    
    addMobileMeta() {
        // Add mobile-specific meta tags if not already present
        const metaTags = [
            { name: 'mobile-web-app-capable', content: 'yes' },
            { name: 'apple-mobile-web-app-capable', content: 'yes' },
            { name: 'apple-mobile-web-app-status-bar-style', content: 'black-translucent' },
            { name: 'format-detection', content: 'telephone=no' },
            { name: 'msapplication-tap-highlight', content: 'no' }
        ];
        
        metaTags.forEach(tag => {
            if (!document.querySelector(`meta[name="${tag.name}"]`)) {
                const meta = document.createElement('meta');
                meta.name = tag.name;
                meta.content = tag.content;
                document.head.appendChild(meta);
            }
        });
    }
    
    closeMobileMenu() {
        const mobileMenu = document.getElementById('mobile-menu');
        const mobileOverlay = document.getElementById('mobile-overlay');
        
        if (mobileMenu) mobileMenu.classList.remove('active');
        if (mobileOverlay) mobileOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }
    
    async loadDashboardData() {
        try {
            const loadingIndicator = document.getElementById('loading-indicator');
            if (loadingIndicator) {
                loadingIndicator.style.display = 'block';
            }
            
            // Load system status
            const statusData = await this.fetchWithFallback('/api/status');
            if (statusData && statusData.success) {
                this.updateSystemStatus(statusData.data);
                this.saveOfflineData('systemStatus', statusData.data);
            }
            
            // Load trading status
            const tradingData = await this.fetchWithFallback('/api/trading/status');
            if (tradingData && tradingData.success) {
                this.updateTradingStatus(tradingData.data);
                this.saveOfflineData('tradingStatus', tradingData.data);
            }
            
            // Load portfolio data
            const portfolioData = await this.fetchWithFallback('/api/trading/portfolio');
            if (portfolioData && portfolioData.success) {
                this.updatePortfolioValue(portfolioData.data);
                this.saveOfflineData('portfolioData', portfolioData.data);
            }
            
            // Load streaming status
            const streamData = await this.fetchWithFallback('/api/streaming/status');
            if (streamData && streamData.success) {
                this.updateStreamStatus(streamData.data);
                this.saveOfflineData('streamStatus', streamData.data);
            }
            
            // Load governance data
            const govData = await this.fetchWithFallback('/api/governance/proposals?status=active');
            if (govData && govData.success) {
                this.updateActiveProposals(govData.data);
                this.saveOfflineData('governanceData', govData.data);
            }
            
            if (loadingIndicator) {
                loadingIndicator.style.display = 'none';
            }
            
        } catch (error) {
            console.error('Error loading dashboard data:', error);
            this.loadOfflineDataFallback();
        }
    }
    
    async fetchWithFallback(url) {
        try {
            if (!this.isOnline) {
                throw new Error('Offline');
            }
            
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.warn(`Failed to fetch ${url}, using offline data:`, error);
            return this.getOfflineDataForUrl(url);
        }
    }
    
    getOfflineDataForUrl(url) {
        const urlMap = {
            '/api/status': 'systemStatus',
            '/api/trading/status': 'tradingStatus',
            '/api/trading/portfolio': 'portfolioData',
            '/api/streaming/status': 'streamStatus',
            '/api/governance/proposals?status=active': 'governanceData'
        };
        
        const dataKey = urlMap[url];
        if (dataKey && this.offlineData[dataKey]) {
            return { success: true, data: this.offlineData[dataKey], offline: true };
        }
        
        return { success: false, error: 'No offline data available', offline: true };
    }
    
    loadOfflineDataFallback() {
        if (this.offlineData.systemStatus) {
            this.updateSystemStatus(this.offlineData.systemStatus);
        }
        if (this.offlineData.tradingStatus) {
            this.updateTradingStatus(this.offlineData.tradingStatus);
        }
        if (this.offlineData.portfolioData) {
            this.updatePortfolioValue(this.offlineData.portfolioData);
        }
        if (this.offlineData.streamStatus) {
            this.updateStreamStatus(this.offlineData.streamStatus);
        }
        if (this.offlineData.governanceData) {
            this.updateActiveProposals(this.offlineData.governanceData);
        }
        
        this.showNotification('Showing cached data - you are offline', 'warning');
    }
    
    saveOfflineData(key, data) {
        try {
            this.offlineData[key] = data;
            localStorage.setItem('lotusxrp_offline_data', JSON.stringify(this.offlineData));
        } catch (error) {
            console.warn('Failed to save offline data:', error);
        }
    }
    
    loadOfflineData() {
        try {
            const stored = localStorage.getItem('lotusxrp_offline_data');
            return stored ? JSON.parse(stored) : {};
        } catch (error) {
            console.warn('Failed to load offline data:', error);
            return {};
        }
    }
    
    handleOnline() {
        this.isOnline = true;
        this.updateConnectionStatus();
        this.showNotification('Back online! Refreshing data...', 'success');
        this.loadDashboardData();
    }
    
    handleOffline() {
        this.isOnline = false;
        this.updateConnectionStatus();
        this.showNotification('You are offline. Showing cached data.', 'warning');
    }
    
    updateConnectionStatus() {
        const statusElement = document.getElementById('connection-status');
        if (statusElement) {
            if (this.isOnline) {
                statusElement.className = 'w-3 h-3 bg-green-400 rounded-full';
                statusElement.nextElementSibling.textContent = 'Online';
            } else {
                statusElement.className = 'w-3 h-3 bg-red-400 rounded-full';
                statusElement.nextElementSibling.textContent = 'Offline';
            }
        }
    }
    
    updateSystemStatus(data) {
        const statusElement = document.getElementById('system-status');
        if (statusElement) {
            const offlineIndicator = data.offline ? ' <span class="text-yellow-400">(Cached)</span>' : '';
            statusElement.innerHTML = `
                <div class="space-y-2">
                    <div class="flex justify-between">
                        <span>Trading Bot:</span>
                        <span class="${data.trading_bot ? 'text-green-400' : 'text-red-400'}">
                            ${data.trading_bot ? 'Online' : 'Offline'}
                        </span>
                    </div>
                    <div class="flex justify-between">
                        <span>Avatar System:</span>
                        <span class="${data.avatar_system ? 'text-green-400' : 'text-red-400'}">
                            ${data.avatar_system ? 'Online' : 'Offline'}
                        </span>
                    </div>
                    <div class="flex justify-between">
                        <span>Governance:</span>
                        <span class="${data.governance ? 'text-green-400' : 'text-red-400'}">
                            ${data.governance ? 'Active' : 'Inactive'}
                        </span>
                    </div>
                    ${offlineIndicator}
                </div>
            `;
        }
    }
    
    updateTradingStatus(data) {
        const statusElement = document.getElementById('trading-status');
        if (statusElement) {
            statusElement.textContent = data.is_running ? 'Active' : 'Stopped';
            statusElement.className = data.is_running ? 
                'text-xl sm:text-2xl font-bold truncate text-green-400' : 
                'text-xl sm:text-2xl font-bold truncate text-red-400';
        }
        
        // Update quick stats
        const totalTradesElement = document.getElementById('total-trades');
        if (totalTradesElement && data.total_trades !== undefined) {
            totalTradesElement.textContent = data.total_trades || '0';
        }
        
        const profitLossElement = document.getElementById('profit-loss');
        if (profitLossElement && data.daily_pnl !== undefined) {
            const pnl = data.daily_pnl || 0;
            profitLossElement.textContent = `$${pnl.toLocaleString()}`;
            profitLossElement.className = pnl >= 0 ? 
                'text-2xl font-bold text-green-400' : 
                'text-2xl font-bold text-red-400';
        }
    }
    
    updatePortfolioValue(data) {
        const valueElement = document.getElementById('portfolio-value');
        if (valueElement) {
            valueElement.textContent = `$${data.total_value?.toLocaleString() || '0'}`;
        }
    }
    
    updateStreamStatus(data) {
        const statusElement = document.getElementById('stream-status');
        if (statusElement) {
            statusElement.textContent = data.is_streaming ? 'Live' : 'Offline';
            statusElement.className = data.is_streaming ? 
                'text-xl sm:text-2xl font-bold truncate text-purple-400' : 
                'text-xl sm:text-2xl font-bold truncate text-gray-400';
        }
        
        // Update viewers count
        const viewersElement = document.getElementById('stream-viewers');
        if (viewersElement && data.connected_clients !== undefined) {
            viewersElement.textContent = data.connected_clients || '0';
        }
    }
    
    updateActiveProposals(data) {
        const proposalsElement = document.getElementById('active-proposals');
        if (proposalsElement) {
            proposalsElement.textContent = Array.isArray(data) ? data.length : '0';
        }
        
        // Update governance votes count
        const votesElement = document.getElementById('governance-votes');
        if (votesElement && data.user_votes !== undefined) {
            votesElement.textContent = data.user_votes || '0';
        }
    }
    
    showInstallButton() {
        // Create install button if it doesn't exist
        let installButton = document.getElementById('pwa-install-btn');
        if (!installButton) {
            installButton = document.createElement('button');
            installButton.id = 'pwa-install-btn';
            installButton.className = 'fixed bottom-4 left-4 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg shadow-lg z-50 touch-target';
            installButton.innerHTML = '<i class="fas fa-download mr-2"></i>Install App';
            installButton.onclick = () => this.installApp();
            document.body.appendChild(installButton);
        }
        installButton.style.display = 'block';
    }
    
    hideInstallButton() {
        const installButton = document.getElementById('pwa-install-btn');
        if (installButton) {
            installButton.style.display = 'none';
        }
    }
    
    async installApp() {
        if (this.deferredPrompt) {
            this.deferredPrompt.prompt();
            const { outcome } = await this.deferredPrompt.userChoice;
            
            if (outcome === 'accepted') {
                console.log('User accepted the install prompt');
            } else {
                console.log('User dismissed the install prompt');
            }
            
            this.deferredPrompt = null;
            this.hideInstallButton();
        }
    }
    
    showUpdateNotification() {
        const notification = document.createElement('div');
        notification.className = 'fixed top-20 right-4 left-4 sm:left-auto sm:w-80 bg-blue-600 text-white px-4 py-3 rounded-lg shadow-lg z-50';
        notification.innerHTML = `
            <div class="flex justify-between items-center">
                <span class="text-sm">New version available!</span>
                <div>
                    <button onclick="window.location.reload()" class="ml-2 bg-white text-blue-600 px-2 py-1 rounded text-xs">
                        Update
                    </button>
                    <button onclick="this.parentElement.parentElement.parentElement.remove()" class="ml-2 text-white hover:text-gray-200">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(notification);
        
        // Auto remove after 10 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 10000);
    }
    
    showNotification(message, type = 'info') {
        // Use the existing notification system from index.html
        if (typeof showNotification === 'function') {
            showNotification(message, type);
        } else {
            console.log(`Notification (${type}): ${message}`);
        }
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.lotusXRPDashboard = new LotusXRPDashboard();
});

// Export for global access
window.LotusXRPDashboard = LotusXRPDashboard;
