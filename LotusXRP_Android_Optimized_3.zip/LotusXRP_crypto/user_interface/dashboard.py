"""
User-facing dashboard for the LotusXRP Crypto Platform.

This module provides a web-based dashboard interface for users to interact
with the trading bot, view avatar streams, and participate in governance.
"""

from flask import Flask, render_template, request, jsonify, session
from flask_cors import CORS
import json
import os
import logging
from typing import Dict, List, Optional
import time
import asyncio
from .market_visualization import MarketDataProvider, ChartGenerator, VisualizationServer

class Dashboard:
    def __init__(self, api_integration):
        self.app = Flask(__name__, 
                        template_folder='templates',
                        static_folder='static')
        self.app.secret_key = os.urandom(24)
        
        # Enable CORS for frontend-backend communication
        CORS(self.app)
        
        self.api_integration = api_integration
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)
        
        # Initialize market visualization components
        self.market_data_provider = MarketDataProvider()
        self.chart_generator = ChartGenerator()
        self.visualization_server = VisualizationServer(port=8766)
        
        # Initialize routes
        self._setup_routes()
        
        # Dashboard configuration
        self.config = {
            "title": "LotusXRP Crypto Platform",
            "version": "1.0.0",
            "theme": "dark",
            "refresh_interval": 5000,  # 5 seconds
            "features": {
                "trading": True,
                "avatar": True,
                "governance": True,
                "analytics": True,
                "market_visualization": True  # New feature
            }
        }

    def _setup_routes(self):
        """Sets up all Flask routes for the dashboard."""
        
        @self.app.route('/')
        def index():
            """Main dashboard page."""
            return render_template('index.html', config=self.config)
        
        @self.app.route('/trading')
        def trading_dashboard():
            """Trading dashboard page."""
            return render_template('trading.html', config=self.config)
        
        @self.app.route('/avatar')
        def avatar_dashboard():
            """Avatar/streaming dashboard page."""
            return render_template('avatar.html', config=self.config)
        
        @self.app.route('/governance')
        def governance_dashboard():
            """Governance dashboard page."""
            return render_template('governance.html', config=self.config)
        
        @self.app.route('/analytics')
        def analytics_dashboard():
            """Analytics dashboard page."""
            return render_template('analytics.html', config=self.config)
        
        @self.app.route('/web3_wallet')
        def web3_wallet_dashboard():
            """Web3 Wallet DApp page."""
            return render_template('web3_wallet.html', config=self.config)
        
        # API Routes
        @self.app.route('/api/status')
        def api_status():
            """Returns system status."""
            try:
                status = self.api_integration.get_system_status()
                return jsonify({"success": True, "data": status})
            except Exception as e:
                self.logger.error(f"Error getting system status: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/trading/status')
        def trading_status():
            """Returns trading bot status."""
            try:
                status = self.api_integration.get_trading_status()
                return jsonify({"success": True, "data": status})
            except Exception as e:
                self.logger.error(f"Error getting trading status: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/trading/portfolio')
        def portfolio_data():
            """Returns portfolio data."""
            try:
                portfolio = self.api_integration.get_portfolio_data()
                return jsonify({"success": True, "data": portfolio})
            except Exception as e:
                self.logger.error(f"Error getting portfolio data: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/trading/history')
        def trading_history():
            """Returns trading history."""
            try:
                limit = request.args.get('limit', 50, type=int)
                history = self.api_integration.get_trading_history(limit)
                return jsonify({"success": True, "data": history})
            except Exception as e:
                self.logger.error(f"Error getting trading history: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/trading/start', methods=['POST'])
        def start_trading():
            """Starts the trading bot."""
            try:
                result = self.api_integration.start_trading_bot()
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error starting trading bot: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/trading/stop', methods=['POST'])
        def stop_trading():
            """Stops the trading bot."""
            try:
                result = self.api_integration.stop_trading_bot()
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error stopping trading bot: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/avatar/status')
        def avatar_status():
            """Returns avatar status."""
            try:
                status = self.api_integration.get_avatar_status()
                return jsonify({"success": True, "data": status})
            except Exception as e:
                self.logger.error(f"Error getting avatar status: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/avatar/config', methods=['GET', 'POST'])
        def avatar_config():
            """Gets or updates avatar configuration."""
            try:
                if request.method == 'GET':
                    config = self.api_integration.get_avatar_config()
                    return jsonify({"success": True, "data": config})
                else:
                    new_config = request.json
                    result = self.api_integration.update_avatar_config(new_config)
                    return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error with avatar config: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/avatar/animation', methods=['POST'])
        def trigger_animation():
            """Triggers an avatar animation."""
            try:
                data = request.json
                animation_name = data.get('animation')
                result = self.api_integration.trigger_avatar_animation(animation_name)
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error triggering animation: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/streaming/status')
        def streaming_status():
            """Returns streaming status."""
            try:
                status = self.api_integration.get_streaming_status()
                return jsonify({"success": True, "data": status})
            except Exception as e:
                self.logger.error(f"Error getting streaming status: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/streaming/start', methods=['POST'])
        def start_streaming():
            """Starts the streaming server."""
            try:
                result = self.api_integration.start_streaming()
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error starting streaming: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/streaming/stop', methods=['POST'])
        def stop_streaming():
            """Stops the streaming server."""
            try:
                result = self.api_integration.stop_streaming()
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error stopping streaming: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/governance/proposals')
        def governance_proposals():
            """Returns governance proposals."""
            try:
                status = request.args.get('status', 'all')
                proposals = self.api_integration.get_governance_proposals(status)
                return jsonify({"success": True, "data": proposals})
            except Exception as e:
                self.logger.error(f"Error getting proposals: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/governance/proposal', methods=['POST'])
        def create_proposal():
            """Creates a new governance proposal."""
            try:
                data = request.json
                result = self.api_integration.create_governance_proposal(data)
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error creating proposal: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/governance/vote', methods=['POST'])
        def cast_vote():
            """Casts a vote on a proposal."""
            try:
                data = request.json
                result = self.api_integration.cast_governance_vote(data)
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error casting vote: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/governance/stats')
        def governance_stats():
            """Returns governance statistics."""
            try:
                stats = self.api_integration.get_governance_stats()
                return jsonify({"success": True, "data": stats})
            except Exception as e:
                self.logger.error(f"Error getting governance stats: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/token/stats')
        def token_stats():
            """Returns token statistics."""
            try:
                stats = self.api_integration.get_token_stats()
                return jsonify({"success": True, "data": stats})
            except Exception as e:
                self.logger.error(f"Error getting token stats: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/token/holder/<address>')
        def token_holder_info(address):
            """Returns token holder information."""
            try:
                info = self.api_integration.get_token_holder_info(address)
                return jsonify({"success": True, "data": info})
            except Exception as e:
                self.logger.error(f"Error getting holder info: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/staking/pools')
        def staking_pools():
            """Returns available staking pools."""
            try:
                pools = self.api_integration.get_staking_pools()
                return jsonify({"success": True, "data": pools})
            except Exception as e:
                self.logger.error(f"Error getting staking pools: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/staking/stake', methods=['POST'])
        def stake_tokens():
            """Stakes tokens in a pool."""
            try:
                data = request.json
                result = self.api_integration.stake_tokens(data)
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error staking tokens: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/staking/unstake', methods=['POST'])
        def unstake_tokens():
            """Unstakes tokens from a pool."""
            try:
                data = request.json
                result = self.api_integration.unstake_tokens(data)
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error unstaking tokens: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route('/api/analytics/performance')
        def performance_analytics():
            """Returns performance analytics."""
            try:
                period = request.args.get('period', '30d')
                analytics = self.api_integration.get_performance_analytics(period)
                return jsonify({"success": True, "data": analytics})
            except Exception as e:
                self.logger.error(f"Error getting analytics: {e}")
                return jsonify({"success": False, "error": str(e)}), 500
        
        @self.app.route("/api/settings", methods=["GET", "POST"])
        def dashboard_settings():
            """Gets or updates dashboard settings."""
            try:
                if request.method == "GET":
                    return jsonify({"success": True, "data": self.config})
                else:
                    new_config = request.json
                    self.config.update(new_config)
                    return jsonify({"success": True, "data": self.config})
            except Exception as e:
                self.logger.error(f"Error with settings: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        # Web3 Wallet API Endpoints
        @self.app.route("/api/web3/connect", methods=["POST"])
        def web3_connect():
            """Connects to the Web3 wallet."""
            try:
                data = request.json
                provider_type = data.get("provider", "metamask")
                result = self.api_integration.connect_web3_wallet(provider_type)
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error connecting Web3 wallet: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/web3/disconnect", methods=["POST"])
        def web3_disconnect():
            """Disconnects the Web3 wallet."""
            try:
                result = self.api_integration.disconnect_web3_wallet()
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error disconnecting Web3 wallet: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/web3/status")
        def web3_status():
            """Returns Web3 wallet status."""
            try:
                status = self.api_integration.get_web3_wallet_status()
                return jsonify({"success": True, "data": status})
            except Exception as e:
                self.logger.error(f"Error getting Web3 wallet status: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/web3/balance")
        def web3_balance():
            """Gets balance from the Web3 wallet."""
            try:
                address = request.args.get("address")
                token_address = request.args.get("token_address")
                balance = self.api_integration.get_web3_balance(address, token_address)
                return jsonify({"success": True, "data": balance})
            except Exception as e:
                self.logger.error(f"Error getting Web3 balance: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/web3/send_transaction", methods=["POST"])
        def web3_send_transaction():
            """Sends a transaction via the Web3 wallet."""
            try:
                data = request.json
                to_address = data.get("to_address")
                amount = data.get("amount")
                gas_price = data.get("gas_price")
                gas_limit = data.get("gas_limit")
                token_address = data.get("token_address")
                result = self.api_integration.send_web3_transaction(to_address, amount, gas_price, gas_limit, token_address)
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error sending Web3 transaction: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/web3/transaction_history")
        def web3_transaction_history():
            """Gets transaction history from the Web3 wallet."""
            try:
                limit = request.args.get("limit", 50, type=int)
                history = self.api_integration.get_web3_transaction_history(limit)
                return jsonify({"success": True, "data": history})
            except Exception as e:
                self.logger.error(f"Error getting Web3 transaction history: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/web3/switch_network", methods=["POST"])
        def web3_switch_network():
            """Switches the Web3 wallet network."""
            try:
                data = request.json
                network_name = data.get("network_name")
                result = self.api_integration.switch_web3_network(network_name)
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error switching Web3 network: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/web3/network_info")
        def web3_network_info():
            """Gets current Web3 network information."""
            try:
                info = self.api_integration.get_web3_network_info()
                return jsonify({"success": True, "data": info})
            except Exception as e:
                self.logger.error(f"Error getting Web3 network info: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/web3/interact_contract", methods=["POST"])
        def web3_interact_contract():
            """Interacts with a Web3 smart contract."""
            try:
                data = request.json
                contract_address = data.get("contract_address")
                function_name = data.get("function_name")
                parameters = data.get("parameters", [])
                result = self.api_integration.interact_web3_contract(contract_address, function_name, parameters)
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error interacting with Web3 contract: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        # Flare Contract API Endpoints
        @self.app.route("/api/flare/ftso_price")
        def flare_ftso_price():
            """Gets FTSO price data for a symbol."""
            try:
                symbol = request.args.get("symbol")
                price = self.api_integration.get_ftso_price(symbol)
                return jsonify({"success": True, "data": price})
            except Exception as e:
                self.logger.error(f"Error getting FTSO price: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/flare/all_ftso_prices")
        def flare_all_ftso_prices():
            """Gets all available FTSO price data."""
            try:
                prices = self.api_integration.get_all_ftso_prices()
                return jsonify({"success": True, "data": prices})
            except Exception as e:
                self.logger.error(f"Error getting all FTSO prices: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/flare/ftso_providers")
        def flare_ftso_providers():
            """Gets list of FTSO data providers."""
            try:
                providers = self.api_integration.get_ftso_providers()
                return jsonify({"success": True, "data": providers})
            except Exception as e:
                self.logger.error(f"Error getting FTSO providers: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/flare/network_stats")
        def flare_network_stats():
            """Gets Flare network statistics."""
            try:
                stats = self.api_integration.get_flare_network_stats()
                return jsonify({"success": True, "data": stats})
            except Exception as e:
                self.logger.error(f"Error getting Flare network stats: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/flare/wrap_token", methods=["POST"])
        def flare_wrap_token():
            """Wraps native FLR/SGB tokens."""
            try:
                data = request.json
                amount = data.get("amount")
                result = self.api_integration.wrap_native_token(amount)
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error wrapping native token: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/flare/unwrap_token", methods=["POST"])
        def flare_unwrap_token():
            """Unwraps WFLR/WSGB tokens back to native."""
            try:
                data = request.json
                amount = data.get("amount")
                result = self.api_integration.unwrap_tokens(amount)
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error unwrapping tokens: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/flare/delegate_votes", methods=["POST"])
        def flare_delegate_votes():
            """Delegates votes to an FTSO data provider."""
            try:
                data = request.json
                provider_address = data.get("provider_address")
                amount = data.get("amount")
                result = self.api_integration.delegate_votes(provider_address, amount)
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error delegating votes: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/flare/claim_rewards", methods=["POST"])
        def flare_claim_rewards():
            """Claims delegation rewards from FTSO providers."""
            try:
                result = self.api_integration.claim_delegation_rewards()
                return jsonify({"success": True, "data": result})
            except Exception as e:
                self.logger.error(f"Error claiming delegation rewards: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route("/api/flare/delegation_info")
        def flare_delegation_info():
            """Gets delegation information for an address."""
            try:
                address = request.args.get("address")
                info = self.api_integration.get_delegation_info(address)
                return jsonify({"success": True, "data": info})
            except Exception as e:
                self.logger.error(f"Error getting delegation info: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        # Market Visualization Routes (New)
        @self.app.route('/api/market/symbols')
        def market_symbols():
            """Returns available trading symbols."""
            try:
                symbols = self.market_data_provider.get_trading_pairs()
                return jsonify({"success": True, "data": symbols})
            except Exception as e:
                self.logger.error(f"Error getting market symbols: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route('/api/market/price/<symbol>')
        def market_price(symbol):
            """Returns latest price for a symbol."""
            try:
                price_data = self.market_data_provider.get_latest_price(symbol)
                return jsonify({"success": True, "data": price_data})
            except Exception as e:
                self.logger.error(f"Error getting price for {symbol}: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route('/api/market/historical/<symbol>')
        def market_historical(symbol):
            """Returns historical data for a symbol."""
            try:
                interval = request.args.get('interval', '1h')
                limit = int(request.args.get('limit', 100))
                
                historical_data = self.market_data_provider.get_historical_data(symbol, interval, limit)
                
                if not historical_data.empty:
                    # Convert to JSON-serializable format
                    data_dict = historical_data.to_dict('records')
                    for record in data_dict:
                        if 'timestamp' in record:
                            record['timestamp'] = record['timestamp'].isoformat()
                    
                    return jsonify({"success": True, "data": data_dict})
                else:
                    return jsonify({"success": False, "error": "No data available"})
                    
            except Exception as e:
                self.logger.error(f"Error getting historical data for {symbol}: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route('/api/market/chart/<symbol>')
        def market_chart(symbol):
            """Returns chart HTML for a symbol."""
            try:
                chart_type = request.args.get('type', 'candlestick')
                interval = request.args.get('interval', '1h')
                limit = int(request.args.get('limit', 100))
                
                # Get historical data
                historical_data = self.market_data_provider.get_historical_data(symbol, interval, limit)
                
                if historical_data.empty:
                    return jsonify({"success": False, "error": "No data available for chart"})
                
                # Generate chart
                chart_html = None
                if chart_type == 'candlestick':
                    chart_html = self.chart_generator.create_candlestick_chart(historical_data, symbol)
                elif chart_type == 'line':
                    chart_html = self.chart_generator.create_line_chart(historical_data, symbol)
                elif chart_type == 'volume':
                    chart_html = self.chart_generator.create_volume_chart(historical_data, symbol)
                elif chart_type == 'technical':
                    chart_html = self.chart_generator.create_technical_indicators_chart(historical_data, symbol)
                else:
                    return jsonify({"success": False, "error": f"Unsupported chart type: {chart_type}"})
                
                return jsonify({"success": True, "data": {"chart_html": chart_html}})
                
            except Exception as e:
                self.logger.error(f"Error generating chart for {symbol}: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route('/api/market/overview')
        def market_overview():
            """Returns market overview data."""
            try:
                summary = self.market_data_provider.get_market_summary()
                return jsonify({"success": True, "data": summary})
            except Exception as e:
                self.logger.error(f"Error getting market overview: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route('/api/market/overview_chart')
        def market_overview_chart():
            """Returns market overview chart."""
            try:
                summary = self.market_data_provider.get_market_summary()
                chart_html = self.chart_generator.create_market_overview_chart(summary.get('symbols', {}))
                return jsonify({"success": True, "data": {"chart_html": chart_html}})
            except Exception as e:
                self.logger.error(f"Error generating market overview chart: {e}")
                return jsonify({"success": False, "error": str(e)}), 500

        @self.app.route('/market_visualization')
        def market_visualization_page():
            """Market visualization dashboard page."""
            return render_template('market_visualization.html', config=self.config)

    def create_templates(self):
        """Creates HTML templates for the dashboard."""
        templates_dir = os.path.join(os.path.dirname(__file__), 'templates')
        static_dir = os.path.join(os.path.dirname(__file__), 'static')
        
        os.makedirs(templates_dir, exist_ok=True)
        os.makedirs(static_dir, exist_ok=True)
        
        # Base template
        base_template = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config.title }}</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .gradient-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .card-hover:hover { transform: translateY(-2px); transition: all 0.3s ease; }
    </style>
</head>
<body class="bg-gray-900 text-white">
    <nav class="gradient-bg shadow-lg">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold">🪷 {{ config.title }}</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/" class="hover:text-pink-300">Dashboard</a>
                    <a href="/trading" class="hover:text-pink-300">Trading</a>
                    <a href="/avatar" class="hover:text-pink-300">Avatar</a>
                    <a href="/governance" class="hover:text-pink-300">Governance</a>
                    <a href="/analytics" class="hover:text-pink-300">Analytics</a>
                </div>
            </div>
        </div>
    </nav>
    
    <main class="max-w-7xl mx-auto py-6 px-4">
        {% block content %}{% endblock %}
    </main>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="{{ url_for('static', filename='dashboard.js') }}"></script>
</body>
</html>'''
        
        # Main dashboard template
        index_template = '''{% extends "base.html" %}
{% block content %}
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <div class="bg-gray-800 rounded-lg p-6 card-hover">
        <div class="flex items-center">
            <i class="fas fa-robot text-blue-400 text-2xl mr-4"></i>
            <div>
                <p class="text-gray-400">Trading Bot</p>
                <p class="text-2xl font-bold" id="trading-status">Loading...</p>
            </div>
        </div>
    </div>
    
    <div class="bg-gray-800 rounded-lg p-6 card-hover">
        <div class="flex items-center">
            <i class="fas fa-chart-line text-green-400 text-2xl mr-4"></i>
            <div>
                <p class="text-gray-400">Portfolio Value</p>
                <p class="text-2xl font-bold" id="portfolio-value">Loading...</p>
            </div>
        </div>
    </div>
    
    <div class="bg-gray-800 rounded-lg p-6 card-hover">
        <div class="flex items-center">
            <i class="fas fa-video text-purple-400 text-2xl mr-4"></i>
            <div>
                <p class="text-gray-400">Avatar Stream</p>
                <p class="text-2xl font-bold" id="stream-status">Loading...</p>
            </div>
        </div>
    </div>
    
    <div class="bg-gray-800 rounded-lg p-6 card-hover">
        <div class="flex items-center">
            <i class="fas fa-vote-yea text-yellow-400 text-2xl mr-4"></i>
            <div>
                <p class="text-gray-400">Active Proposals</p>
                <p class="text-2xl font-bold" id="active-proposals">Loading...</p>
            </div>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <div class="bg-gray-800 rounded-lg p-6">
        <h3 class="text-xl font-bold mb-4">Recent Trading Activity</h3>
        <div id="trading-activity">Loading...</div>
    </div>
    
    <div class="bg-gray-800 rounded-lg p-6">
        <h3 class="text-xl font-bold mb-4">System Status</h3>
        <div id="system-status">Loading...</div>
    </div>
</div>
{% endblock %}'''
        
        # Write templates
        with open(os.path.join(templates_dir, 'base.html'), 'w') as f:
            f.write(base_template)
        
        with open(os.path.join(templates_dir, 'index.html'), 'w') as f:
            f.write(index_template)
        
        # Create JavaScript file
        js_content = '''
// Dashboard JavaScript
class LotusXRPDashboard {
    constructor() {
        this.refreshInterval = 5000;
        this.init();
    }
    
    init() {
        this.loadDashboardData();
        setInterval(() => this.loadDashboardData(), this.refreshInterval);
    }
    
    async loadDashboardData() {
        try {
            // Load system status
            const statusResponse = await fetch('/api/status');
            const statusData = await statusResponse.json();
            
            if (statusData.success) {
                this.updateSystemStatus(statusData.data);
            }
            
            // Load trading status
            const tradingResponse = await fetch('/api/trading/status');
            const tradingData = await tradingResponse.json();
            
            if (tradingData.success) {
                this.updateTradingStatus(tradingData.data);
            }
            
            // Load portfolio data
            const portfolioResponse = await fetch('/api/trading/portfolio');
            const portfolioData = await portfolioResponse.json();
            
            if (portfolioData.success) {
                this.updatePortfolioValue(portfolioData.data);
            }
            
            // Load streaming status
            const streamResponse = await fetch('/api/streaming/status');
            const streamData = await streamResponse.json();
            
            if (streamData.success) {
                this.updateStreamStatus(streamData.data);
            }
            
            // Load governance data
            const govResponse = await fetch('/api/governance/proposals?status=active');
            const govData = await govResponse.json();
            
            if (govData.success) {
                this.updateActiveProposals(govData.data);
            }
            
        } catch (error) {
            console.error('Error loading dashboard data:', error);
        }
    }
    
    updateSystemStatus(data) {
        const statusElement = document.getElementById('system-status');
        if (statusElement) {
            statusElement.innerHTML = `
                <div class="space-y-2">
                    <div class="flex justify-between">
                        <span>Trading Bot:</span>
                        <span class="${data.trading_bot ? 'text-green-400' : 'text-red-400'}">
                            ${data.trading_bot ? 'Online' : 'Offline'}
                        </span>
                    </div>
                    <div class="flex justify-between">
                        <span>Avatar System:</span>
                        <span class="${data.avatar_system ? 'text-green-400' : 'text-red-400'}">
                            ${data.avatar_system ? 'Online' : 'Offline'}
                        </span>
                    </div>
                    <div class="flex justify-between">
                        <span>Governance:</span>
                        <span class="${data.governance ? 'text-green-400' : 'text-red-400'}">
                            ${data.governance ? 'Active' : 'Inactive'}
                        </span>
                    </div>
                </div>
            `;
        }
    }
    
    updateTradingStatus(data) {
        const statusElement = document.getElementById('trading-status');
        if (statusElement) {
            statusElement.textContent = data.is_running ? 'Active' : 'Stopped';
            statusElement.className = data.is_running ? 'text-2xl font-bold text-green-400' : 'text-2xl font-bold text-red-400';
        }
    }
    
    updatePortfolioValue(data) {
        const valueElement = document.getElementById('portfolio-value');
        if (valueElement) {
            valueElement.textContent = `$${data.total_value?.toLocaleString() || '0'}`;
        }
    }
    
    updateStreamStatus(data) {
        const statusElement = document.getElementById('stream-status');
        if (statusElement) {
            statusElement.textContent = data.is_streaming ? 'Live' : 'Offline';
            statusElement.className = data.is_streaming ? 'text-2xl font-bold text-purple-400' : 'text-2xl font-bold text-gray-400';
        }
    }
    
    updateActiveProposals(data) {
        const proposalsElement = document.getElementById('active-proposals');
        if (proposalsElement) {
            proposalsElement.textContent = data.length || '0';
        }
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LotusXRPDashboard();
});
'''
        
        with open(os.path.join(static_dir, 'dashboard.js'), 'w') as f:
            f.write(js_content)
        
        self.logger.info("Dashboard templates created successfully")

    def run(self, host='0.0.0.0', port=5000, debug=False):
        """Runs the dashboard server.

        Args:
            host (str): Server host
            port (int): Server port
            debug (bool): Debug mode
        """
        self.create_templates()
        self.logger.info(f"Starting dashboard server on {host}:{port}")
        self.app.run(host=host, port=port, debug=debug)

if __name__ == "__main__":
    # Example usage (would normally be imported and used with APIIntegration)
    class MockAPIIntegration:
        def get_system_status(self):
            return {"trading_bot": True, "avatar_system": True, "governance": True}
        
        def get_trading_status(self):
            return {"is_running": True, "last_trade": time.time()}
        
        def get_portfolio_data(self):
            return {"total_value": 15750.50, "assets": {"XRP": 1000, "LOTUS": 5000}}
    
    mock_api = MockAPIIntegration()
    dashboard = Dashboard(mock_api)
    dashboard.run(debug=True)

