"""
User Interface Module for LotusXRP Crypto Platform

This module provides the user-facing dashboard and API integration
that connects all platform components (trading bot, avatar, governance).
"""

from .dashboard import Dashboard
from .api_integration import APIIntegration

__version__ = "1.0.0"
__author__ = "LotusXRP Team"

__all__ = [
    "Dashboard",
    "APIIntegration"
]

