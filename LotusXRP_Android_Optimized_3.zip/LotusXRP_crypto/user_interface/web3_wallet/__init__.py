"""
Web3 Wallet DApp Module for LotusXRP Crypto Platform.

This module provides functionalities for connecting to the Flare network,
managing accounts, and interacting with smart contracts.
"""

from .wallet import Web3Wallet

__version__ = "1.0.0"
__author__ = "LotusXRP Team"

__all__ = [
    "Web3Wallet"
]

