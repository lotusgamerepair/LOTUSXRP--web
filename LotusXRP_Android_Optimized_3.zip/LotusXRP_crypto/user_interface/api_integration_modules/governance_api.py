import logging
import time
from typing import Dict, List, Optional, Any

class GovernanceAPI:
    def __init__(self, governance_contract, governance_token):
        self.governance_contract = governance_contract
        self.governance_token = governance_token
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)

    def get_governance_proposals(self, status: str = "all") -> List[Dict]:
        """Returns governance proposals."""
        if not self.governance_contract:
            return []
        
        if status == "active":
            return self.governance_contract.get_active_proposals()
        else:
            # Return all proposals
            proposals = []
            for proposal_id, proposal in self.governance_contract.proposals.items():
                self.governance_contract.update_proposal_status(proposal_id)
                proposals.append(self.governance_contract.get_proposal(proposal_id))
            return proposals

    def create_governance_proposal(self, proposal_data: Dict) -> Dict:
        """Creates a new governance proposal."""
        if not self.governance_contract:
            raise ValueError("Governance contract not initialized")
        
        proposal_id = self.governance_contract.create_proposal(
            title=proposal_data["title"],
            description=proposal_data["description"],
            proposer=proposal_data["proposer"],
            execution_data=proposal_data.get("execution_data")
        )
        
        return {
            "proposal_id": proposal_id,
            "status": "created",
            "timestamp": time.time()
        }

    def cast_governance_vote(self, vote_data: Dict) -> Dict:
        """Casts a vote on a governance proposal."""
        if not self.governance_contract:
            raise ValueError("Governance contract not initialized")
        
        from flare_governance.governance_contract import VoteType
        
        vote_type = VoteType(vote_data["vote_type"])
        
        success = self.governance_contract.cast_vote(
            proposal_id=vote_data["proposal_id"],
            voter=vote_data["voter"],
            vote_type=vote_type,
            reason=vote_data.get("reason")
        )
        
        return {
            "status": "cast" if success else "failed",
            "timestamp": time.time()
        }

    def get_governance_stats(self) -> Dict:
        """Returns governance statistics."""
        if not self.governance_contract:
            return {"error": "Governance contract not initialized"}
        
        return self.governance_contract.get_governance_stats()

    def get_token_stats(self) -> Dict:
        """Returns token statistics."""
        if not self.governance_token:
            return {"error": "Governance token not initialized"}
        
        return self.governance_token.get_token_stats()

    def get_token_holder_info(self, address: str) -> Optional[Dict]:
        """Returns token holder information."""
        if not self.governance_token:
            return None
        
        return self.governance_token.get_token_holder(address)

    def get_staking_pools(self) -> List[Dict]:
        """Returns available staking pools."""
        if not self.governance_token:
            return []
        
        pools = []
        for pool_id, pool in self.governance_token.staking_pools.items():
            pools.append(self.governance_token.get_staking_pool(pool_id))
        
        return pools

    def stake_tokens(self, stake_data: Dict) -> Dict:
        """Stakes tokens in a pool."""
        if not self.governance_token:
            raise ValueError("Governance token not initialized")
        
        success = self.governance_token.stake_tokens(
            staker_address=stake_data["staker"],
            pool_id=stake_data["pool_id"],
            amount=stake_data["amount"]
        )
        
        return {
            "status": "staked" if success else "failed",
            "timestamp": time.time()
        }

    def unstake_tokens(self, unstake_data: Dict) -> Dict:
        """Unstakes tokens from a pool."""
        if not self.governance_token:
            raise ValueError("Governance token not initialized")
        
        success = self.governance_token.unstake_tokens(
            staker_address=unstake_data["staker"],
            pool_id=unstake_data["pool_id"],
            amount=unstake_data["amount"]
        )
        
        return {
            "status": "unstaked" if success else "failed",
            "timestamp": time.time()
        }

