import logging
import time
import asyncio
import threading
from typing import Dict, List, Optional, Any

class AvatarAPI:
    def __init__(self, avatar, animator, streamer):
        self.avatar = avatar
        self.animator = animator
        self.streamer = streamer
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)
        self.is_streaming = False

    def get_avatar_status(self) -> Dict:
        """Returns avatar status."""
        if not self.avatar:
            return {"error": "Avatar not initialized"}
        
        return {
            "name": self.avatar.name,
            "current_expression": getattr(self.avatar, 'current_expression', 'neutral'),
            "current_pose": getattr(self.avatar, 'current_pose', 'standing'),
            "animation_status": self.animator.get_animation_status() if self.animator else {},
            "last_updated": time.time()
        }

    def get_avatar_config(self) -> Dict:
        """Returns avatar configuration."""
        if not self.avatar:
            return {"error": "Avatar not initialized"}
        
        return self.avatar.generate_avatar_config()

    def update_avatar_config(self, new_config: Dict) -> Dict:
        """Updates avatar configuration."""
        if not self.avatar:
            raise ValueError("Avatar not initialized")
        
        # Update avatar appearance
        if "appearance" in new_config:
            self.avatar.customize_appearance(**new_config["appearance"])
        
        # Update expressions and poses
        if "expression" in new_config:
            self.avatar.set_expression(new_config["expression"])
        
        if "pose" in new_config:
            self.avatar.set_pose(new_config["pose"])
        
        return {"status": "updated", "timestamp": time.time()}

    def trigger_avatar_animation(self, animation_name: str) -> Dict:
        """Triggers an avatar animation."""
        if not self.animator:
            raise ValueError("Animator not initialized")
        
        success = self.animator.play_animation(animation_name)
        
        return {
            "status": "triggered" if success else "failed",
            "animation": animation_name,
            "timestamp": time.time()
        }

    def get_streaming_status(self) -> Dict:
        """Returns streaming status."""
        if not self.streamer:
            return {"error": "Streamer not initialized"}
        
        return {
            "is_streaming": self.is_streaming,
            "connected_clients": len(getattr(self.streamer, 'connected_clients', [])),
            "chat_messages": len(getattr(self.streamer, 'chat_history', [])),
            "uptime": time.time() if self.is_streaming else 0
        }

    def start_streaming(self) -> Dict:
        """Starts the streaming server."""
        if not self.streamer:
            raise ValueError("Streamer not initialized")
        
        try:
            # Start streaming in background
            def run_streaming():
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(self.streamer.start_stream())
            
            streaming_thread = threading.Thread(target=run_streaming)
            streaming_thread.daemon = True
            streaming_thread.start()
            
            self.is_streaming = True
            self.logger.info("Streaming server started")
            
            return {"status": "started", "timestamp": time.time()}
            
        except Exception as e:
            self.logger.error(f"Error starting streaming: {e}")
            raise

    def stop_streaming(self) -> Dict:
        """Stops the streaming server."""
        if self.streamer:
            self.streamer.stop_stream()
        
        self.is_streaming = False
        self.logger.info("Streaming server stopped")
        
        return {"status": "stopped", "timestamp": time.time()}

