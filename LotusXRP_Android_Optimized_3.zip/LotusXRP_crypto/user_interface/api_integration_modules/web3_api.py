import logging
import time
from typing import Dict, List, Optional, Any

class Web3API:
    def __init__(self, web3_wallet, flare_contract_manager):
        self.web3_wallet = web3_wallet
        self.flare_contract_manager = flare_contract_manager
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)

    def get_wallet_status(self) -> Dict:
        """Returns Web3 wallet status."""
        if not self.web3_wallet:
            return {"error": "Web3 wallet not initialized"}
        
        return {
            "is_connected": self.web3_wallet.is_connected(),
            "current_account": self.web3_wallet.get_current_account(),
            "network": self.web3_wallet.current_network,
            "last_updated": time.time()
        }

    def connect_wallet(self, provider_type: str = "metamask") -> Dict:
        """Connects to a Web3 wallet."""
        if not self.web3_wallet:
            raise ValueError("Web3 wallet not initialized")
        
        try:
            success = self.web3_wallet.connect_wallet(provider_type)
            return {
                "status": "connected" if success else "failed",
                "provider": provider_type,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error connecting wallet: {e}")
            return {"status": "failed", "error": str(e), "timestamp": time.time()}

    def disconnect_wallet(self) -> Dict:
        """Disconnects from the Web3 wallet."""
        if not self.web3_wallet:
            raise ValueError("Web3 wallet not initialized")
        
        self.web3_wallet.disconnect_wallet()
        return {"status": "disconnected", "timestamp": time.time()}

    def get_account_balance(self, token_address: Optional[str] = None) -> Dict:
        """Gets account balance for native token or specific token."""
        if not self.web3_wallet:
            raise ValueError("Web3 wallet not initialized")
        
        try:
            if token_address:
                balance = self.web3_wallet.get_token_balance(token_address)
            else:
                balance = self.web3_wallet.get_native_balance()
            
            return {
                "balance": balance,
                "token_address": token_address,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error getting balance: {e}")
            return {"error": str(e), "timestamp": time.time()}

    def send_transaction(self, transaction_data: Dict) -> Dict:
        """Sends a transaction."""
        if not self.web3_wallet:
            raise ValueError("Web3 wallet not initialized")
        
        try:
            tx_hash = self.web3_wallet.send_transaction(
                to_address=transaction_data["to"],
                amount=transaction_data["amount"],
                token_address=transaction_data.get("token_address")
            )
            
            return {
                "status": "sent",
                "transaction_hash": tx_hash,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error sending transaction: {e}")
            return {"status": "failed", "error": str(e), "timestamp": time.time()}

    def wrap_flr(self, amount: float) -> Dict:
        """Wraps FLR to WFLR."""
        if not self.flare_contract_manager:
            raise ValueError("Flare contract manager not initialized")
        
        try:
            tx_hash = self.flare_contract_manager.wrap_flr(amount)
            return {
                "status": "wrapped",
                "amount": amount,
                "transaction_hash": tx_hash,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error wrapping FLR: {e}")
            return {"status": "failed", "error": str(e), "timestamp": time.time()}

    def unwrap_flr(self, amount: float) -> Dict:
        """Unwraps WFLR to FLR."""
        if not self.flare_contract_manager:
            raise ValueError("Flare contract manager not initialized")
        
        try:
            tx_hash = self.flare_contract_manager.unwrap_flr(amount)
            return {
                "status": "unwrapped",
                "amount": amount,
                "transaction_hash": tx_hash,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error unwrapping FLR: {e}")
            return {"status": "failed", "error": str(e), "timestamp": time.time()}

    def delegate_votes(self, provider_address: str, amount: float) -> Dict:
        """Delegates votes to an FTSO data provider."""
        if not self.flare_contract_manager:
            raise ValueError("Flare contract manager not initialized")
        
        try:
            tx_hash = self.flare_contract_manager.delegate_votes(provider_address, amount)
            return {
                "status": "delegated",
                "provider": provider_address,
                "amount": amount,
                "transaction_hash": tx_hash,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error delegating votes: {e}")
            return {"status": "failed", "error": str(e), "timestamp": time.time()}

    def claim_rewards(self) -> Dict:
        """Claims delegation rewards."""
        if not self.flare_contract_manager:
            raise ValueError("Flare contract manager not initialized")
        
        try:
            tx_hash = self.flare_contract_manager.claim_rewards()
            return {
                "status": "claimed",
                "transaction_hash": tx_hash,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error claiming rewards: {e}")
            return {"status": "failed", "error": str(e), "timestamp": time.time()}

    def get_ftso_prices(self) -> Dict:
        """Gets current FTSO price data."""
        if not self.flare_contract_manager:
            raise ValueError("Flare contract manager not initialized")
        
        try:
            prices = self.flare_contract_manager.get_ftso_prices()
            return {
                "prices": prices,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error getting FTSO prices: {e}")
            return {"error": str(e), "timestamp": time.time()}

    def get_delegation_info(self, address: str) -> Dict:
        """Gets delegation information for an address."""
        if not self.flare_contract_manager:
            raise ValueError("Flare contract manager not initialized")
        
        try:
            delegation_info = self.flare_contract_manager.get_delegation_info(address)
            return {
                "delegation_info": delegation_info,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error getting delegation info: {e}")
            return {"error": str(e), "timestamp": time.time()}

