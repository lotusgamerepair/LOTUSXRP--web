import logging
import time
from typing import Dict, List, Optional, Any

class MarketAPI:
    def __init__(self, market_data_provider, visualization_server):
        self.market_data_provider = market_data_provider
        self.visualization_server = visualization_server
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)

    def get_market_data(self, symbol: str, timeframe: str = "1h", limit: int = 100) -> Dict:
        """Gets market data for a specific symbol."""
        if not self.market_data_provider:
            raise ValueError("Market data provider not initialized")
        
        try:
            data = self.market_data_provider.get_market_data(symbol, timeframe, limit)
            return {
                "symbol": symbol,
                "timeframe": timeframe,
                "data": data,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error getting market data: {e}")
            return {"error": str(e), "timestamp": time.time()}

    def get_real_time_price(self, symbol: str) -> Dict:
        """Gets real-time price for a specific symbol."""
        if not self.market_data_provider:
            raise ValueError("Market data provider not initialized")
        
        try:
            price_data = self.market_data_provider.get_real_time_price(symbol)
            return {
                "symbol": symbol,
                "price": price_data["price"],
                "change_24h": price_data.get("change_24h", 0),
                "volume_24h": price_data.get("volume_24h", 0),
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error getting real-time price: {e}")
            return {"error": str(e), "timestamp": time.time()}

    def get_market_overview(self) -> Dict:
        """Gets market overview with multiple symbols."""
        if not self.market_data_provider:
            raise ValueError("Market data provider not initialized")
        
        try:
            overview = self.market_data_provider.get_market_overview()
            return {
                "overview": overview,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error getting market overview: {e}")
            return {"error": str(e), "timestamp": time.time()}

    def generate_chart(self, symbol: str, chart_type: str = "candlestick", timeframe: str = "1h") -> Dict:
        """Generates a chart for visualization."""
        if not self.visualization_server:
            raise ValueError("Visualization server not initialized")
        
        try:
            chart_data = self.visualization_server.generate_chart(symbol, chart_type, timeframe)
            return {
                "symbol": symbol,
                "chart_type": chart_type,
                "timeframe": timeframe,
                "chart_data": chart_data,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error generating chart: {e}")
            return {"error": str(e), "timestamp": time.time()}

    def get_technical_indicators(self, symbol: str, indicators: List[str]) -> Dict:
        """Gets technical indicators for a symbol."""
        if not self.market_data_provider:
            raise ValueError("Market data provider not initialized")
        
        try:
            indicator_data = self.market_data_provider.get_technical_indicators(symbol, indicators)
            return {
                "symbol": symbol,
                "indicators": indicator_data,
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error getting technical indicators: {e}")
            return {"error": str(e), "timestamp": time.time()}

    def subscribe_to_real_time_updates(self, symbols: List[str]) -> Dict:
        """Subscribes to real-time market data updates."""
        if not self.market_data_provider:
            raise ValueError("Market data provider not initialized")
        
        try:
            subscription_id = self.market_data_provider.subscribe_to_updates(symbols)
            return {
                "subscription_id": subscription_id,
                "symbols": symbols,
                "status": "subscribed",
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error subscribing to updates: {e}")
            return {"error": str(e), "timestamp": time.time()}

    def unsubscribe_from_updates(self, subscription_id: str) -> Dict:
        """Unsubscribes from real-time market data updates."""
        if not self.market_data_provider:
            raise ValueError("Market data provider not initialized")
        
        try:
            success = self.market_data_provider.unsubscribe_from_updates(subscription_id)
            return {
                "subscription_id": subscription_id,
                "status": "unsubscribed" if success else "failed",
                "timestamp": time.time()
            }
        except Exception as e:
            self.logger.error(f"Error unsubscribing from updates: {e}")
            return {"error": str(e), "timestamp": time.time()}

