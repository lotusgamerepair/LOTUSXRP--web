"""
Chart Generator for creating interactive market data visualizations.

This module generates various types of charts and visualizations for market data
including candlestick charts, line charts, volume charts, and technical indicators.
"""

import json
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from typing import Dict, List, Optional, Tuple
import numpy as np
from datetime import datetime, timedelta
import logging


class ChartGenerator:
    """Generates interactive charts for market data visualization."""
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Chart styling configuration
        self.chart_config = {
            'theme': 'plotly_dark',
            'colors': {
                'primary': '#00D4AA',
                'secondary': '#FF6B6B',
                'background': '#1E1E1E',
                'grid': '#2D2D2D',
                'text': '#FFFFFF',
                'up': '#00FF88',
                'down': '#FF4444'
            },
            'font': {
                'family': 'Arial, sans-serif',
                'size': 12
            }
        }

    def create_candlestick_chart(self, data: pd.DataFrame, symbol: str, 
                                title: Optional[str] = None) -> str:
        """Create an interactive candlestick chart."""
        try:
            if data.empty:
                return self._create_empty_chart("No data available")
            
            if title is None:
                title = f"{symbol} Price Chart"
            
            # Create subplots with secondary y-axis for volume
            fig = make_subplots(
                rows=2, cols=1,
                shared_xaxes=True,
                vertical_spacing=0.1,
                subplot_titles=(title, 'Volume'),
                row_width=[0.7, 0.3]
            )
            
            # Add candlestick chart
            fig.add_trace(
                go.Candlestick(
                    x=data['timestamp'],
                    open=data['open'],
                    high=data['high'],
                    low=data['low'],
                    close=data['close'],
                    name=symbol,
                    increasing_line_color=self.chart_config['colors']['up'],
                    decreasing_line_color=self.chart_config['colors']['down']
                ),
                row=1, col=1
            )
            
            # Add volume bars
            colors = ['red' if close < open else 'green' 
                     for close, open in zip(data['close'], data['open'])]
            
            fig.add_trace(
                go.Bar(
                    x=data['timestamp'],
                    y=data['volume'],
                    name='Volume',
                    marker_color=colors,
                    opacity=0.7
                ),
                row=2, col=1
            )
            
            # Add moving averages
            if len(data) >= 20:
                data['ma20'] = data['close'].rolling(window=20).mean()
                fig.add_trace(
                    go.Scatter(
                        x=data['timestamp'],
                        y=data['ma20'],
                        mode='lines',
                        name='MA20',
                        line=dict(color=self.chart_config['colors']['primary'], width=1)
                    ),
                    row=1, col=1
                )
            
            if len(data) >= 50:
                data['ma50'] = data['close'].rolling(window=50).mean()
                fig.add_trace(
                    go.Scatter(
                        x=data['timestamp'],
                        y=data['ma50'],
                        mode='lines',
                        name='MA50',
                        line=dict(color=self.chart_config['colors']['secondary'], width=1)
                    ),
                    row=1, col=1
                )
            
            # Update layout
            fig.update_layout(
                template=self.chart_config['theme'],
                font=self.chart_config['font'],
                showlegend=True,
                xaxis_rangeslider_visible=False,
                height=600,
                margin=dict(l=50, r=50, t=50, b=50)
            )
            
            # Update x-axis
            fig.update_xaxes(
                title_text="Time",
                showgrid=True,
                gridcolor=self.chart_config['colors']['grid']
            )
            
            # Update y-axis
            fig.update_yaxes(
                title_text="Price (USD)",
                showgrid=True,
                gridcolor=self.chart_config['colors']['grid'],
                row=1, col=1
            )
            
            fig.update_yaxes(
                title_text="Volume",
                showgrid=True,
                gridcolor=self.chart_config['colors']['grid'],
                row=2, col=1
            )
            
            return fig.to_html(include_plotlyjs='cdn', div_id=f"chart_{symbol}")
            
        except Exception as e:
            self.logger.error(f"Error creating candlestick chart: {e}")
            return self._create_empty_chart("Error creating chart")

    def create_line_chart(self, data: pd.DataFrame, symbol: str, 
                         column: str = 'close', title: Optional[str] = None) -> str:
        """Create a simple line chart."""
        try:
            if data.empty:
                return self._create_empty_chart("No data available")
            
            if title is None:
                title = f"{symbol} {column.title()} Price"
            
            fig = go.Figure()
            
            fig.add_trace(
                go.Scatter(
                    x=data['timestamp'],
                    y=data[column],
                    mode='lines',
                    name=symbol,
                    line=dict(
                        color=self.chart_config['colors']['primary'],
                        width=2
                    ),
                    fill='tonexty' if len(fig.data) > 0 else None
                )
            )
            
            # Update layout
            fig.update_layout(
                title=title,
                template=self.chart_config['theme'],
                font=self.chart_config['font'],
                showlegend=True,
                height=400,
                margin=dict(l=50, r=50, t=50, b=50)
            )
            
            fig.update_xaxes(
                title_text="Time",
                showgrid=True,
                gridcolor=self.chart_config['colors']['grid']
            )
            
            fig.update_yaxes(
                title_text="Price (USD)",
                showgrid=True,
                gridcolor=self.chart_config['colors']['grid']
            )
            
            return fig.to_html(include_plotlyjs='cdn', div_id=f"line_chart_{symbol}")
            
        except Exception as e:
            self.logger.error(f"Error creating line chart: {e}")
            return self._create_empty_chart("Error creating chart")

    def create_volume_chart(self, data: pd.DataFrame, symbol: str, 
                           title: Optional[str] = None) -> str:
        """Create a volume chart."""
        try:
            if data.empty:
                return self._create_empty_chart("No data available")
            
            if title is None:
                title = f"{symbol} Trading Volume"
            
            # Color bars based on price movement
            colors = []
            for i in range(len(data)):
                if data.iloc[i]['close'] >= data.iloc[i]['open']:
                    colors.append(self.chart_config['colors']['up'])
                else:
                    colors.append(self.chart_config['colors']['down'])
            
            fig = go.Figure()
            
            fig.add_trace(
                go.Bar(
                    x=data['timestamp'],
                    y=data['volume'],
                    name='Volume',
                    marker_color=colors,
                    opacity=0.8
                )
            )
            
            # Update layout
            fig.update_layout(
                title=title,
                template=self.chart_config['theme'],
                font=self.chart_config['font'],
                showlegend=False,
                height=300,
                margin=dict(l=50, r=50, t=50, b=50)
            )
            
            fig.update_xaxes(
                title_text="Time",
                showgrid=True,
                gridcolor=self.chart_config['colors']['grid']
            )
            
            fig.update_yaxes(
                title_text="Volume",
                showgrid=True,
                gridcolor=self.chart_config['colors']['grid']
            )
            
            return fig.to_html(include_plotlyjs='cdn', div_id=f"volume_chart_{symbol}")
            
        except Exception as e:
            self.logger.error(f"Error creating volume chart: {e}")
            return self._create_empty_chart("Error creating chart")

    def create_technical_indicators_chart(self, data: pd.DataFrame, symbol: str) -> str:
        """Create a chart with technical indicators."""
        try:
            if data.empty or len(data) < 20:
                return self._create_empty_chart("Insufficient data for technical indicators")
            
            # Calculate technical indicators
            data = self._calculate_technical_indicators(data)
            
            # Create subplots
            fig = make_subplots(
                rows=3, cols=1,
                shared_xaxes=True,
                vertical_spacing=0.1,
                subplot_titles=(
                    f"{symbol} Price with Bollinger Bands",
                    "RSI",
                    "MACD"
                ),
                row_heights=[0.5, 0.25, 0.25]
            )
            
            # Price and Bollinger Bands
            fig.add_trace(
                go.Scatter(
                    x=data['timestamp'],
                    y=data['close'],
                    mode='lines',
                    name='Close Price',
                    line=dict(color=self.chart_config['colors']['primary'])
                ),
                row=1, col=1
            )
            
            if 'bb_upper' in data.columns:
                fig.add_trace(
                    go.Scatter(
                        x=data['timestamp'],
                        y=data['bb_upper'],
                        mode='lines',
                        name='BB Upper',
                        line=dict(color='rgba(255,255,255,0.3)'),
                        showlegend=False
                    ),
                    row=1, col=1
                )
                
                fig.add_trace(
                    go.Scatter(
                        x=data['timestamp'],
                        y=data['bb_lower'],
                        mode='lines',
                        name='BB Lower',
                        line=dict(color='rgba(255,255,255,0.3)'),
                        fill='tonexty',
                        fillcolor='rgba(255,255,255,0.1)',
                        showlegend=False
                    ),
                    row=1, col=1
                )
            
            # RSI
            if 'rsi' in data.columns:
                fig.add_trace(
                    go.Scatter(
                        x=data['timestamp'],
                        y=data['rsi'],
                        mode='lines',
                        name='RSI',
                        line=dict(color=self.chart_config['colors']['secondary'])
                    ),
                    row=2, col=1
                )
                
                # Add RSI levels
                fig.add_hline(y=70, line_dash="dash", line_color="red", row=2, col=1)
                fig.add_hline(y=30, line_dash="dash", line_color="green", row=2, col=1)
            
            # MACD
            if 'macd' in data.columns:
                fig.add_trace(
                    go.Scatter(
                        x=data['timestamp'],
                        y=data['macd'],
                        mode='lines',
                        name='MACD',
                        line=dict(color=self.chart_config['colors']['primary'])
                    ),
                    row=3, col=1
                )
                
                if 'macd_signal' in data.columns:
                    fig.add_trace(
                        go.Scatter(
                            x=data['timestamp'],
                            y=data['macd_signal'],
                            mode='lines',
                            name='MACD Signal',
                            line=dict(color=self.chart_config['colors']['secondary'])
                        ),
                        row=3, col=1
                    )
            
            # Update layout
            fig.update_layout(
                template=self.chart_config['theme'],
                font=self.chart_config['font'],
                showlegend=True,
                height=800,
                margin=dict(l=50, r=50, t=50, b=50)
            )
            
            return fig.to_html(include_plotlyjs='cdn', div_id=f"technical_chart_{symbol}")
            
        except Exception as e:
            self.logger.error(f"Error creating technical indicators chart: {e}")
            return self._create_empty_chart("Error creating technical chart")

    def create_market_overview_chart(self, market_data: Dict) -> str:
        """Create a market overview chart with multiple symbols."""
        try:
            if not market_data:
                return self._create_empty_chart("No market data available")
            
            symbols = []
            prices = []
            changes = []
            
            for symbol, data in market_data.items():
                if isinstance(data, dict) and 'price' in data and 'change' in data:
                    symbols.append(symbol)
                    prices.append(data['price'])
                    changes.append(data['change'])
            
            if not symbols:
                return self._create_empty_chart("No valid market data")
            
            # Create color map based on price change
            colors = [self.chart_config['colors']['up'] if change >= 0 
                     else self.chart_config['colors']['down'] for change in changes]
            
            fig = go.Figure()
            
            fig.add_trace(
                go.Bar(
                    x=symbols,
                    y=changes,
                    name='Price Change (%)',
                    marker_color=colors,
                    text=[f"{change:+.2f}%" for change in changes],
                    textposition='outside'
                )
            )
            
            # Update layout
            fig.update_layout(
                title="Market Overview - 24h Price Changes",
                template=self.chart_config['theme'],
                font=self.chart_config['font'],
                showlegend=False,
                height=400,
                margin=dict(l=50, r=50, t=50, b=50)
            )
            
            fig.update_xaxes(
                title_text="Symbol",
                showgrid=True,
                gridcolor=self.chart_config['colors']['grid']
            )
            
            fig.update_yaxes(
                title_text="Change (%)",
                showgrid=True,
                gridcolor=self.chart_config['colors']['grid']
            )
            
            # Add zero line
            fig.add_hline(y=0, line_dash="dash", line_color="white", opacity=0.5)
            
            return fig.to_html(include_plotlyjs='cdn', div_id="market_overview_chart")
            
        except Exception as e:
            self.logger.error(f"Error creating market overview chart: {e}")
            return self._create_empty_chart("Error creating market overview")

    def _calculate_technical_indicators(self, data: pd.DataFrame) -> pd.DataFrame:
        """Calculate technical indicators for the data."""
        try:
            df = data.copy()
            
            # Bollinger Bands
            if len(df) >= 20:
                df['bb_middle'] = df['close'].rolling(window=20).mean()
                bb_std = df['close'].rolling(window=20).std()
                df['bb_upper'] = df['bb_middle'] + (bb_std * 2)
                df['bb_lower'] = df['bb_middle'] - (bb_std * 2)
            
            # RSI
            if len(df) >= 14:
                delta = df['close'].diff()
                gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
                loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
                rs = gain / loss
                df['rsi'] = 100 - (100 / (1 + rs))
            
            # MACD
            if len(df) >= 26:
                exp1 = df['close'].ewm(span=12).mean()
                exp2 = df['close'].ewm(span=26).mean()
                df['macd'] = exp1 - exp2
                df['macd_signal'] = df['macd'].ewm(span=9).mean()
                df['macd_histogram'] = df['macd'] - df['macd_signal']
            
            return df
            
        except Exception as e:
            self.logger.error(f"Error calculating technical indicators: {e}")
            return data

    def _create_empty_chart(self, message: str) -> str:
        """Create an empty chart with a message."""
        fig = go.Figure()
        
        fig.add_annotation(
            text=message,
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            xanchor='center', yanchor='middle',
            font=dict(size=16, color=self.chart_config['colors']['text'])
        )
        
        fig.update_layout(
            template=self.chart_config['theme'],
            font=self.chart_config['font'],
            height=400,
            margin=dict(l=50, r=50, t=50, b=50),
            showlegend=False
        )
        
        return fig.to_html(include_plotlyjs='cdn', div_id="empty_chart")

    def get_chart_config(self) -> Dict:
        """Get the current chart configuration."""
        return self.chart_config.copy()

    def update_chart_config(self, new_config: Dict):
        """Update the chart configuration."""
        self.chart_config.update(new_config)
        self.logger.info("Chart configuration updated")


# Example usage
if __name__ == "__main__":
    # Create sample data
    dates = pd.date_range(start='2024-01-01', end='2024-01-31', freq='H')
    sample_data = pd.DataFrame({
        'timestamp': dates,
        'open': np.random.uniform(0.4, 0.6, len(dates)),
        'high': np.random.uniform(0.5, 0.7, len(dates)),
        'low': np.random.uniform(0.3, 0.5, len(dates)),
        'close': np.random.uniform(0.4, 0.6, len(dates)),
        'volume': np.random.uniform(1000000, 5000000, len(dates))
    })
    
    # Create chart generator
    chart_gen = ChartGenerator()
    
    # Generate charts
    candlestick_chart = chart_gen.create_candlestick_chart(sample_data, "XRPUSDT")
    line_chart = chart_gen.create_line_chart(sample_data, "XRPUSDT")
    
    print("Charts generated successfully!")

