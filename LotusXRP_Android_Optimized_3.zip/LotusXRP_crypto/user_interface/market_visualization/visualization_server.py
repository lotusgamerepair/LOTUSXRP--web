"""
Visualization Server for serving real-time market data charts.

This module provides a WebSocket-based server for streaming real-time chart updates
to connected clients, enabling live market data visualization.
"""

import asyncio
import json
import logging
import time
from typing import Dict, List, Set
import websockets
from websockets.server import WebSocketServerProtocol
from .market_data_provider import MarketDataProvider
from .chart_generator import ChartGenerator
import pandas as pd
from datetime import datetime


class VisualizationServer:
    """WebSocket server for real-time market data visualization."""
    
    def __init__(self, host: str = 'localhost', port: int = 8766):
        self.host = host
        self.port = port
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Core components
        self.market_data_provider = MarketDataProvider()
        self.chart_generator = ChartGenerator()
        
        # Client management
        self.connected_clients: Set[WebSocketServerProtocol] = set()
        self.client_subscriptions: Dict[WebSocketServerProtocol, Set[str]] = {}
        
        # Data cache for charts
        self.chart_cache: Dict[str, str] = {}
        self.last_update_time: Dict[str, float] = {}
        
        # Server state
        self.is_running = False
        self.server = None

    async def start(self):
        """Start the visualization server."""
        if self.is_running:
            return
        
        self.logger.info(f"Starting visualization server on {self.host}:{self.port}")
        
        # Start market data provider
        asyncio.create_task(self.market_data_provider.start())
        
        # Subscribe to market data updates
        for symbol in self.market_data_provider.get_trading_pairs():
            self.market_data_provider.subscribe(symbol, self._on_market_data_update)
        
        # Start WebSocket server
        self.server = await websockets.serve(
            self._handle_client,
            self.host,
            self.port
        )
        
        self.is_running = True
        self.logger.info("Visualization server started successfully")
        
        # Start background tasks
        asyncio.create_task(self._periodic_chart_updates())
        asyncio.create_task(self._cleanup_disconnected_clients())

    async def stop(self):
        """Stop the visualization server."""
        if not self.is_running:
            return
        
        self.logger.info("Stopping visualization server...")
        self.is_running = False
        
        # Close all client connections
        if self.connected_clients:
            await asyncio.gather(
                *[client.close() for client in self.connected_clients],
                return_exceptions=True
            )
        
        # Stop WebSocket server
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        
        # Stop market data provider
        await self.market_data_provider.stop()
        
        self.logger.info("Visualization server stopped")

    async def _handle_client(self, websocket: WebSocketServerProtocol, path: str):
        """Handle new client connections."""
        self.connected_clients.add(websocket)
        self.client_subscriptions[websocket] = set()
        
        client_info = f"{websocket.remote_address[0]}:{websocket.remote_address[1]}"
        self.logger.info(f"New client connected: {client_info}")
        
        try:
            # Send welcome message
            await self._send_to_client(websocket, {
                'type': 'welcome',
                'message': 'Connected to LotusXRP Visualization Server',
                'available_symbols': self.market_data_provider.get_trading_pairs(),
                'timestamp': datetime.now().isoformat()
            })
            
            # Handle client messages
            async for message in websocket:
                await self._process_client_message(websocket, message)
                
        except websockets.exceptions.ConnectionClosed:
            self.logger.info(f"Client disconnected: {client_info}")
        except Exception as e:
            self.logger.error(f"Error handling client {client_info}: {e}")
        finally:
            # Cleanup
            self.connected_clients.discard(websocket)
            self.client_subscriptions.pop(websocket, None)

    async def _process_client_message(self, websocket: WebSocketServerProtocol, message: str):
        """Process messages from clients."""
        try:
            data = json.loads(message)
            message_type = data.get('type')
            
            if message_type == 'subscribe':
                await self._handle_subscribe(websocket, data)
            elif message_type == 'unsubscribe':
                await self._handle_unsubscribe(websocket, data)
            elif message_type == 'get_chart':
                await self._handle_get_chart(websocket, data)
            elif message_type == 'get_historical':
                await self._handle_get_historical(websocket, data)
            elif message_type == 'ping':
                await self._send_to_client(websocket, {'type': 'pong', 'timestamp': time.time()})
            else:
                await self._send_to_client(websocket, {
                    'type': 'error',
                    'message': f'Unknown message type: {message_type}'
                })
                
        except json.JSONDecodeError:
            await self._send_to_client(websocket, {
                'type': 'error',
                'message': 'Invalid JSON message'
            })
        except Exception as e:
            self.logger.error(f"Error processing client message: {e}")
            await self._send_to_client(websocket, {
                'type': 'error',
                'message': 'Internal server error'
            })

    async def _handle_subscribe(self, websocket: WebSocketServerProtocol, data: Dict):
        """Handle client subscription requests."""
        symbol = data.get('symbol')
        if not symbol:
            await self._send_to_client(websocket, {
                'type': 'error',
                'message': 'Symbol is required for subscription'
            })
            return
        
        # Add to client subscriptions
        self.client_subscriptions[websocket].add(symbol)
        
        # Send current data if available
        current_data = self.market_data_provider.get_latest_price(symbol)
        if current_data:
            await self._send_to_client(websocket, {
                'type': 'price_update',
                'symbol': symbol,
                'data': current_data
            })
        
        # Send cached chart if available
        chart_key = f"{symbol}_candlestick"
        if chart_key in self.chart_cache:
            await self._send_to_client(websocket, {
                'type': 'chart_update',
                'symbol': symbol,
                'chart_type': 'candlestick',
                'chart_html': self.chart_cache[chart_key]
            })
        
        await self._send_to_client(websocket, {
            'type': 'subscribed',
            'symbol': symbol,
            'message': f'Subscribed to {symbol} updates'
        })

    async def _handle_unsubscribe(self, websocket: WebSocketServerProtocol, data: Dict):
        """Handle client unsubscription requests."""
        symbol = data.get('symbol')
        if symbol and websocket in self.client_subscriptions:
            self.client_subscriptions[websocket].discard(symbol)
            
            await self._send_to_client(websocket, {
                'type': 'unsubscribed',
                'symbol': symbol,
                'message': f'Unsubscribed from {symbol} updates'
            })

    async def _handle_get_chart(self, websocket: WebSocketServerProtocol, data: Dict):
        """Handle chart generation requests."""
        symbol = data.get('symbol')
        chart_type = data.get('chart_type', 'candlestick')
        interval = data.get('interval', '1h')
        limit = data.get('limit', 100)
        
        if not symbol:
            await self._send_to_client(websocket, {
                'type': 'error',
                'message': 'Symbol is required for chart generation'
            })
            return
        
        try:
            # Get historical data
            historical_data = self.market_data_provider.get_historical_data(symbol, interval, limit)
            
            if historical_data.empty:
                await self._send_to_client(websocket, {
                    'type': 'error',
                    'message': f'No historical data available for {symbol}'
                })
                return
            
            # Generate chart
            chart_html = None
            if chart_type == 'candlestick':
                chart_html = self.chart_generator.create_candlestick_chart(historical_data, symbol)
            elif chart_type == 'line':
                chart_html = self.chart_generator.create_line_chart(historical_data, symbol)
            elif chart_type == 'volume':
                chart_html = self.chart_generator.create_volume_chart(historical_data, symbol)
            elif chart_type == 'technical':
                chart_html = self.chart_generator.create_technical_indicators_chart(historical_data, symbol)
            
            if chart_html:
                # Cache the chart
                chart_key = f"{symbol}_{chart_type}"
                self.chart_cache[chart_key] = chart_html
                self.last_update_time[chart_key] = time.time()
                
                await self._send_to_client(websocket, {
                    'type': 'chart_update',
                    'symbol': symbol,
                    'chart_type': chart_type,
                    'chart_html': chart_html
                })
            else:
                await self._send_to_client(websocket, {
                    'type': 'error',
                    'message': f'Unsupported chart type: {chart_type}'
                })
                
        except Exception as e:
            self.logger.error(f"Error generating chart for {symbol}: {e}")
            await self._send_to_client(websocket, {
                'type': 'error',
                'message': 'Error generating chart'
            })

    async def _handle_get_historical(self, websocket: WebSocketServerProtocol, data: Dict):
        """Handle historical data requests."""
        symbol = data.get('symbol')
        interval = data.get('interval', '1h')
        limit = data.get('limit', 100)
        
        if not symbol:
            await self._send_to_client(websocket, {
                'type': 'error',
                'message': 'Symbol is required for historical data'
            })
            return
        
        try:
            historical_data = self.market_data_provider.get_historical_data(symbol, interval, limit)
            
            if not historical_data.empty:
                # Convert to JSON-serializable format
                data_dict = historical_data.to_dict('records')
                for record in data_dict:
                    if 'timestamp' in record:
                        record['timestamp'] = record['timestamp'].isoformat()
                
                await self._send_to_client(websocket, {
                    'type': 'historical_data',
                    'symbol': symbol,
                    'interval': interval,
                    'data': data_dict
                })
            else:
                await self._send_to_client(websocket, {
                    'type': 'error',
                    'message': f'No historical data available for {symbol}'
                })
                
        except Exception as e:
            self.logger.error(f"Error fetching historical data for {symbol}: {e}")
            await self._send_to_client(websocket, {
                'type': 'error',
                'message': 'Error fetching historical data'
            })

    async def _on_market_data_update(self, symbol: str, data: Dict):
        """Handle market data updates from the provider."""
        # Broadcast to subscribed clients
        message = {
            'type': 'price_update',
            'symbol': symbol,
            'data': data
        }
        
        await self._broadcast_to_subscribers(symbol, message)

    async def _send_to_client(self, websocket: WebSocketServerProtocol, message: Dict):
        """Send a message to a specific client."""
        try:
            await websocket.send(json.dumps(message))
        except websockets.exceptions.ConnectionClosed:
            pass  # Client disconnected
        except Exception as e:
            self.logger.error(f"Error sending message to client: {e}")

    async def _broadcast_to_subscribers(self, symbol: str, message: Dict):
        """Broadcast a message to all clients subscribed to a symbol."""
        if not self.connected_clients:
            return
        
        subscribers = [
            client for client, subscriptions in self.client_subscriptions.items()
            if symbol in subscriptions and client in self.connected_clients
        ]
        
        if subscribers:
            await asyncio.gather(
                *[self._send_to_client(client, message) for client in subscribers],
                return_exceptions=True
            )

    async def _periodic_chart_updates(self):
        """Periodically update charts for active symbols."""
        while self.is_running:
            try:
                # Get all subscribed symbols
                active_symbols = set()
                for subscriptions in self.client_subscriptions.values():
                    active_symbols.update(subscriptions)
                
                # Update charts for active symbols
                for symbol in active_symbols:
                    chart_key = f"{symbol}_candlestick"
                    last_update = self.last_update_time.get(chart_key, 0)
                    
                    # Update chart every 5 minutes
                    if time.time() - last_update > 300:
                        try:
                            historical_data = self.market_data_provider.get_historical_data(symbol, '1h', 100)
                            if not historical_data.empty:
                                chart_html = self.chart_generator.create_candlestick_chart(historical_data, symbol)
                                self.chart_cache[chart_key] = chart_html
                                self.last_update_time[chart_key] = time.time()
                                
                                # Broadcast updated chart
                                message = {
                                    'type': 'chart_update',
                                    'symbol': symbol,
                                    'chart_type': 'candlestick',
                                    'chart_html': chart_html
                                }
                                await self._broadcast_to_subscribers(symbol, message)
                        except Exception as e:
                            self.logger.error(f"Error updating chart for {symbol}: {e}")
                
                await asyncio.sleep(60)  # Check every minute
                
            except Exception as e:
                self.logger.error(f"Error in periodic chart updates: {e}")
                await asyncio.sleep(60)

    async def _cleanup_disconnected_clients(self):
        """Clean up disconnected clients."""
        while self.is_running:
            try:
                disconnected = []
                for client in list(self.connected_clients):
                    if client.closed:
                        disconnected.append(client)
                
                for client in disconnected:
                    self.connected_clients.discard(client)
                    self.client_subscriptions.pop(client, None)
                
                if disconnected:
                    self.logger.info(f"Cleaned up {len(disconnected)} disconnected clients")
                
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                self.logger.error(f"Error in client cleanup: {e}")
                await asyncio.sleep(30)

    def get_server_stats(self) -> Dict:
        """Get server statistics."""
        active_symbols = set()
        for subscriptions in self.client_subscriptions.values():
            active_symbols.update(subscriptions)
        
        return {
            'connected_clients': len(self.connected_clients),
            'active_symbols': list(active_symbols),
            'cached_charts': len(self.chart_cache),
            'is_running': self.is_running,
            'uptime': time.time() if self.is_running else 0
        }


# Example usage
if __name__ == "__main__":
    async def main():
        server = VisualizationServer()
        await server.start()
        
        # Keep server running
        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            await server.stop()

    # Run the server
    # asyncio.run(main())

