"""
Market Data Provider for real-time cryptocurrency market data.

This module handles fetching and processing real-time market data from various
sources including exchanges, FTSO price feeds, and other data providers.
"""

import asyncio
import json
import time
import logging
from typing import Dict, List, Optional, Callable
import websockets
import requests
from datetime import datetime, timedelta
import pandas as pd


class MarketDataProvider:
    """Provides real-time market data from multiple sources."""
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        self.subscribers = {}  # symbol -> list of callbacks
        self.data_cache = {}  # symbol -> latest data
        self.websocket_connections = {}
        self.is_running = False
        
        # Data sources configuration
        self.data_sources = {
            'binance': {
                'ws_url': 'wss://stream.binance.com:9443/ws/',
                'rest_url': 'https://api.binance.com/api/v3/',
                'enabled': True
            },
            'coinbase': {
                'ws_url': 'wss://ws-feed.pro.coinbase.com',
                'rest_url': 'https://api.pro.coinbase.com/',
                'enabled': True
            },
            'ftso': {
                'enabled': True,
                'symbols': ['XRP', 'BTC', 'ETH', 'ADA', 'DOGE', 'LTC']
            }
        }
        
        # Supported trading pairs
        self.supported_pairs = [
            'XRPUSDT', 'BTCUSDT', 'ETHUSDT', 'ADAUSDT', 
            'DOGEUSDT', 'LTCUSDT', 'FLRUSDT'
        ]

    async def start(self):
        """Start the market data provider."""
        if self.is_running:
            return
        
        self.is_running = True
        self.logger.info("Starting market data provider...")
        
        # Start data collection tasks
        tasks = []
        
        # Start WebSocket connections for real-time data
        for pair in self.supported_pairs:
            if pair != 'FLRUSDT':  # FLR might not be on all exchanges
                tasks.append(asyncio.create_task(self._start_binance_stream(pair)))
        
        # Start FTSO data collection
        tasks.append(asyncio.create_task(self._start_ftso_data_collection()))
        
        # Start historical data updates
        tasks.append(asyncio.create_task(self._update_historical_data()))
        
        await asyncio.gather(*tasks, return_exceptions=True)

    async def stop(self):
        """Stop the market data provider."""
        self.is_running = False
        self.logger.info("Stopping market data provider...")
        
        # Close WebSocket connections
        for ws in self.websocket_connections.values():
            if ws and not ws.closed:
                await ws.close()
        
        self.websocket_connections.clear()

    def subscribe(self, symbol: str, callback: Callable):
        """Subscribe to real-time updates for a symbol."""
        if symbol not in self.subscribers:
            self.subscribers[symbol] = []
        
        self.subscribers[symbol].append(callback)
        self.logger.info(f"Subscribed to {symbol} updates")
        
        # Send latest data if available
        if symbol in self.data_cache:
            callback(symbol, self.data_cache[symbol])

    def unsubscribe(self, symbol: str, callback: Callable):
        """Unsubscribe from updates for a symbol."""
        if symbol in self.subscribers and callback in self.subscribers[symbol]:
            self.subscribers[symbol].remove(callback)
            self.logger.info(f"Unsubscribed from {symbol} updates")

    def get_latest_price(self, symbol: str) -> Optional[Dict]:
        """Get the latest price data for a symbol."""
        return self.data_cache.get(symbol)

    def get_historical_data(self, symbol: str, interval: str = '1h', limit: int = 100) -> pd.DataFrame:
        """Get historical price data for a symbol."""
        try:
            # Use Binance API for historical data
            url = f"{self.data_sources['binance']['rest_url']}klines"
            params = {
                'symbol': symbol,
                'interval': interval,
                'limit': limit
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            # Convert to DataFrame
            df = pd.DataFrame(data, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_volume', 'trades', 'taker_buy_base',
                'taker_buy_quote', 'ignore'
            ])
            
            # Convert timestamp and prices
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            for col in ['open', 'high', 'low', 'close', 'volume']:
                df[col] = pd.to_numeric(df[col])
            
            return df[['timestamp', 'open', 'high', 'low', 'close', 'volume']]
            
        except Exception as e:
            self.logger.error(f"Error fetching historical data for {symbol}: {e}")
            return pd.DataFrame()

    async def _start_binance_stream(self, symbol: str):
        """Start Binance WebSocket stream for a symbol."""
        stream_name = f"{symbol.lower()}@ticker"
        uri = f"{self.data_sources['binance']['ws_url']}{stream_name}"
        
        while self.is_running:
            try:
                async with websockets.connect(uri) as websocket:
                    self.websocket_connections[symbol] = websocket
                    self.logger.info(f"Connected to Binance stream for {symbol}")
                    
                    async for message in websocket:
                        if not self.is_running:
                            break
                        
                        data = json.loads(message)
                        
                        # Process ticker data
                        processed_data = {
                            'symbol': data['s'],
                            'price': float(data['c']),
                            'change': float(data['P']),
                            'volume': float(data['v']),
                            'high': float(data['h']),
                            'low': float(data['l']),
                            'timestamp': datetime.now().isoformat(),
                            'source': 'binance'
                        }
                        
                        # Update cache
                        self.data_cache[symbol] = processed_data
                        
                        # Notify subscribers
                        await self._notify_subscribers(symbol, processed_data)
                        
            except Exception as e:
                self.logger.error(f"Error in Binance stream for {symbol}: {e}")
                if self.is_running:
                    await asyncio.sleep(5)  # Retry after 5 seconds

    async def _start_ftso_data_collection(self):
        """Start FTSO data collection for Flare network prices."""
        while self.is_running:
            try:
                # Simulate FTSO price data (in real implementation, this would connect to Flare network)
                for symbol in self.data_sources['ftso']['symbols']:
                    # Generate realistic price data based on current market
                    base_prices = {
                        'XRP': 0.52, 'BTC': 43000, 'ETH': 2600, 
                        'ADA': 0.38, 'DOGE': 0.08, 'LTC': 72
                    }
                    
                    if symbol in base_prices:
                        # Add some random variation
                        import random
                        base_price = base_prices[symbol]
                        variation = random.uniform(-0.02, 0.02)  # ±2% variation
                        current_price = base_price * (1 + variation)
                        
                        ftso_data = {
                            'symbol': f'{symbol}USD',
                            'price': round(current_price, 6),
                            'change': round(variation * 100, 2),
                            'volume': random.uniform(1000000, 10000000),
                            'timestamp': datetime.now().isoformat(),
                            'source': 'ftso',
                            'confidence': random.uniform(0.95, 0.99)
                        }
                        
                        # Update cache
                        ftso_symbol = f'{symbol}USD'
                        self.data_cache[ftso_symbol] = ftso_data
                        
                        # Notify subscribers
                        await self._notify_subscribers(ftso_symbol, ftso_data)
                
                await asyncio.sleep(30)  # Update every 30 seconds
                
            except Exception as e:
                self.logger.error(f"Error in FTSO data collection: {e}")
                await asyncio.sleep(60)

    async def _update_historical_data(self):
        """Periodically update historical data cache."""
        while self.is_running:
            try:
                for symbol in self.supported_pairs:
                    # Update historical data every hour
                    historical_data = self.get_historical_data(symbol, '1h', 24)
                    if not historical_data.empty:
                        cache_key = f"{symbol}_historical"
                        self.data_cache[cache_key] = historical_data.to_dict('records')
                
                await asyncio.sleep(3600)  # Update every hour
                
            except Exception as e:
                self.logger.error(f"Error updating historical data: {e}")
                await asyncio.sleep(3600)

    async def _notify_subscribers(self, symbol: str, data: Dict):
        """Notify all subscribers of new data."""
        if symbol in self.subscribers:
            for callback in self.subscribers[symbol]:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(symbol, data)
                    else:
                        callback(symbol, data)
                except Exception as e:
                    self.logger.error(f"Error notifying subscriber for {symbol}: {e}")

    def get_market_summary(self) -> Dict:
        """Get a summary of all market data."""
        summary = {
            'total_symbols': len(self.data_cache),
            'active_connections': len(self.websocket_connections),
            'last_update': datetime.now().isoformat(),
            'symbols': {}
        }
        
        for symbol, data in self.data_cache.items():
            if not symbol.endswith('_historical'):
                summary['symbols'][symbol] = {
                    'price': data.get('price'),
                    'change': data.get('change'),
                    'source': data.get('source'),
                    'timestamp': data.get('timestamp')
                }
        
        return summary

    def get_trading_pairs(self) -> List[str]:
        """Get list of supported trading pairs."""
        return self.supported_pairs.copy()


# Example usage
if __name__ == "__main__":
    async def price_callback(symbol, data):
        print(f"{symbol}: ${data['price']:.6f} ({data['change']:+.2f}%)")

    async def main():
        provider = MarketDataProvider()
        
        # Subscribe to XRP updates
        provider.subscribe('XRPUSDT', price_callback)
        
        # Start the provider
        await provider.start()

    # Run the example
    # asyncio.run(main())

