"""
API Integration module that connects all platform components.

This module serves as the central integration layer that connects the trading bot,
avatar system, governance contracts, and provides unified API access.
"""

import asyncio
import threading
import time
import logging
from typing import Dict, List, Optional, Any
import json
from user_interface.api_integration_modules.trading_api import TradingAPI
from user_interface.api_integration_modules.avatar_api import AvatarAPI
from user_interface.api_integration_modules.governance_api import GovernanceAPI
from user_interface.api_integration_modules.web3_api import Web3API
from user_interface.api_integration_modules.market_api import MarketAPI

class APIIntegration:
    def __init__(self):
        self.trading_api = None
        self.avatar_api = None
        self.governance_api = None
        self.web3_api = None
        self.market_api = None
        
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)
        
        # System state
        self.system_state = {
            "initialized": False,
            "trading_active": False,
            "streaming_active": False,
            "governance_active": False,
            "web3_active": False  # New
        }
        
        # Background tasks
        self.background_tasks = {}
        self.task_loop = None

    def initialize_components(self, config: Dict = None):
        """Initializes all platform components.

        Args:
            config (Dict): Configuration for components
        """
        if config is None:
            config = self._default_config()
        
        try:
            # Initialize AI Trading Agent components
            from ai_trading_agent import TradingBot, MLPredictor, BacktestEngine
            trading_bot_instance = TradingBot(
                api_key=config.get("trading", {}).get("api_key", ""),
                api_secret=config.get("trading", {}).get("api_secret", "")
            )
            ml_predictor_instance = MLPredictor()
            backtest_engine_instance = BacktestEngine()
            self.trading_api = TradingAPI(trading_bot_instance, ml_predictor_instance, backtest_engine_instance)
            
            # Initialize VTuber Avatar components
            from vtuber_avatar import Avatar, Animator, Streamer
            avatar_instance = Avatar(config.get("avatar", {}).get("name", "LotusXRP-chan"))
            animator_instance = Animator(avatar_instance.generate_avatar_config())
            streamer_instance = Streamer(avatar_instance, animator_instance)
            self.avatar_api = AvatarAPI(avatar_instance, animator_instance, streamer_instance)
            
            # Initialize Governance components
            from flare_governance import GovernanceContract, GovernanceToken
            governance_contract_instance = GovernanceContract()
            governance_token_instance = GovernanceToken()
            # Link governance token with contract
            governance_token_instance.governance_contract = governance_contract_instance
            self.governance_api = GovernanceAPI(governance_contract_instance, governance_token_instance)

            # Initialize Web3 Wallet and Flare Contracts components
            from user_interface.web3_wallet.wallet import Web3Wallet
            from user_interface.web3_wallet.flare_contracts import FlareContractManager
            web3_wallet_instance = Web3Wallet()
            flare_contract_manager_instance = FlareContractManager(web3_wallet_instance.current_network)
            self.web3_api = Web3API(web3_wallet_instance, flare_contract_manager_instance)

            # Initialize Market Visualization components
            from user_interface.market_visualization.market_data_provider import MarketDataProvider
            from user_interface.market_visualization.visualization_server import VisualizationServer
            market_data_provider_instance = MarketDataProvider()
            visualization_server_instance = VisualizationServer()
            self.market_api = MarketAPI(market_data_provider_instance, visualization_server_instance)
            
            self.system_state["initialized"] = True
            self.logger.info("All components initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Error initializing components: {e}")
            raise

    def _default_config(self) -> Dict:
        """Returns default configuration for all components."""
        return {
            "trading": {
                "api_key": "",
                "api_secret": "",
                "initial_balance": 10000,
                "risk_level": "medium"
            },
            "avatar": {
                "name": "LotusXRP-chan",
                "type": "2D",
                "theme": "crypto_trader"
            },
            "streaming": {
                "host": "localhost",
                "port": 8765,
                "auto_start": False
            },
            "governance": {
                "voting_delay": 86400,
                "voting_period": 604800,
                "quorum_percentage": 10
            },
            "token": {
                "name": "LotusXRP",
                "symbol": "LOTUS",
                "initial_supply": 100000000
            }
        }

    # System Status Methods
    def get_system_status(self) -> Dict:
        """Returns overall system status.

        Returns:
            Dict: System status information
        """
        return {
            "initialized": self.system_state["initialized"],
            "trading_active": self.trading_api is not None and self.trading_api.is_running,
            "streaming_active": self.avatar_api is not None and self.avatar_api.is_streaming,
            "governance_active": self.governance_api is not None,
            "web3_active": self.web3_api is not None and self.web3_api.web3_wallet.is_connected(),
            "uptime": time.time(),
            "components": {
                "trading_api": self.trading_api is not None,
                "avatar_api": self.avatar_api is not None,
                "governance_api": self.governance_api is not None,
                "web3_api": self.web3_api is not None,
                "market_api": self.market_api is not None
            }
        }

    # Trading Bot Integration
    def get_trading_status(self) -> Dict:
        """Returns trading bot status."""
        if not self.trading_api:
            return {"error": "Trading API not initialized"}
        
        return self.trading_api.get_trading_status()

    def start_trading_bot(self) -> Dict:
        """Starts the trading bot."""
        if not self.trading_api:
            raise ValueError("Trading API not initialized")
        
        result = self.trading_api.start_trading_bot()
        self.system_state["trading_active"] = result.get("status") == "started"
        return result

    def stop_trading_bot(self) -> Dict:
        """Stops the trading bot."""
        if not self.trading_api:
            raise ValueError("Trading API not initialized")
        
        result = self.trading_api.stop_trading_bot()
        self.system_state["trading_active"] = False
        return result

    def get_portfolio_data(self) -> Dict:
        """Returns portfolio data."""
        if not self.trading_api:
            return {"error": "Trading API not initialized"}
        
        return self.trading_api.get_portfolio_data()

    def get_trading_history(self, limit: int = 50) -> List[Dict]:
        """Returns trading history."""
        if not self.trading_api:
            return []
        
        return self.trading_api.get_trading_history(limit)

    # Avatar Integration
    def get_avatar_status(self) -> Dict:
        """Returns avatar status."""
        if not self.avatar_api:
            return {"error": "Avatar API not initialized"}
        
        return self.avatar_api.get_avatar_status()

    def get_avatar_config(self) -> Dict:
        """Returns avatar configuration."""
        if not self.avatar_api:
            return {"error": "Avatar API not initialized"}
        
        return self.avatar_api.get_avatar_config()

    def update_avatar_config(self, new_config: Dict) -> Dict:
        """Updates avatar configuration."""
        if not self.avatar_api:
            raise ValueError("Avatar API not initialized")
        
        return self.avatar_api.update_avatar_config(new_config)

    def trigger_avatar_animation(self, animation_name: str) -> Dict:
        """Triggers an avatar animation."""
        if not self.avatar_api:
            raise ValueError("Avatar API not initialized")
        
        return self.avatar_api.trigger_avatar_animation(animation_name)

    # Streaming Integration
    def get_streaming_status(self) -> Dict:
        """Returns streaming status."""
        if not self.avatar_api:
            return {"error": "Avatar API not initialized"}
        
        return self.avatar_api.get_streaming_status()

    def start_streaming(self) -> Dict:
        """Starts the streaming server."""
        if not self.avatar_api:
            raise ValueError("Avatar API not initialized")
        
        result = self.avatar_api.start_streaming()
        self.system_state["streaming_active"] = result.get("status") == "started"
        return result

    def stop_streaming(self) -> Dict:
        """Stops the streaming server."""
        if not self.avatar_api:
            raise ValueError("Avatar API not initialized")
        
        result = self.avatar_api.stop_streaming()
        self.system_state["streaming_active"] = False
        return result

    # Governance Integration
    def get_governance_proposals(self, status: str = "all") -> List[Dict]:
        """Returns governance proposals."""
        if not self.governance_api:
            return []
        
        return self.governance_api.get_governance_proposals(status)

    def create_governance_proposal(self, proposal_data: Dict) -> Dict:
        """Creates a new governance proposal."""
        if not self.governance_api:
            raise ValueError("Governance API not initialized")
        
        return self.governance_api.create_governance_proposal(proposal_data)

    def cast_governance_vote(self, vote_data: Dict) -> Dict:
        """Casts a vote on a governance proposal."""
        if not self.governance_api:
            raise ValueError("Governance API not initialized")
        
        return self.governance_api.cast_governance_vote(vote_data)

    def get_governance_stats(self) -> Dict:
        """Returns governance statistics."""
        if not self.governance_api:
            return {"error": "Governance API not initialized"}
        
        return self.governance_api.get_governance_stats()





    # Web3 Wallet Integration
    def connect_web3_wallet(self, provider_type: str = "metamask") -> Dict[str, Any]:
        """Connects to the Web3 wallet."""
        if not self.web3_api:
            raise ValueError("Web3 API not initialized")
        
        result = self.web3_api.connect_wallet(provider_type)
        self.system_state["web3_active"] = result.get("status") == "connected"
        return result

    def disconnect_web3_wallet(self) -> Dict[str, Any]:
        """Disconnects the Web3 wallet."""
        if not self.web3_api:
            raise ValueError("Web3 API not initialized")
        
        result = self.web3_api.disconnect_wallet()
        self.system_state["web3_active"] = False
        return result

    def get_web3_wallet_status(self) -> Dict[str, Any]:
        """Returns Web3 wallet status."""
        if not self.web3_api:
            return {"error": "Web3 API not initialized"}
        return self.web3_api.get_wallet_status()

    def get_web3_balance(self, address: Optional[str] = None, token_address: Optional[str] = None) -> Dict[str, Any]:
        """Gets balance from the Web3 wallet."""
        if not self.web3_api:
            return {"error": "Web3 API not initialized"}
        return self.web3_api.get_account_balance(token_address)

    def send_web3_transaction(self, to_address: str, amount: float, gas_price: Optional[int] = None, 
                              gas_limit: Optional[int] = None, token_address: Optional[str] = None) -> Dict[str, Any]:
        """Sends a transaction via the Web3 wallet."""
        if not self.web3_api:
            raise ValueError("Web3 API not initialized")
        return self.web3_api.send_transaction({"to": to_address, "amount": amount, "token_address": token_address})

    def get_web3_transaction_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Gets transaction history from the Web3 wallet."""
        if not self.web3_api:
            return []
        return self.web3_api.get_web3_transaction_history(limit)

    def switch_web3_network(self, network_name: str) -> Dict[str, Any]:
        """Switches the Web3 wallet network."""
        if not self.web3_api:
            raise ValueError("Web3 API not initialized")
        result = self.web3_api.switch_web3_network(network_name)
        return result

    def get_web3_network_info(self) -> Dict[str, Any]:
        """Gets current Web3 network information."""
        if not self.web3_api:
            return {"error": "Web3 API not initialized"}
        return self.web3_api.get_web3_network_info()

    def interact_web3_contract(self, contract_address: str, function_name: str, 
                               parameters: List[Any] = None) -> Dict[str, Any]:
        """Interacts with a Web3 smart contract."""
        if not self.web3_api:
            raise ValueError("Web3 API not initialized")
        return self.web3_api.interact_contract(contract_address, function_name, parameters)

    # Flare Contract Integration
    def get_ftso_price(self, symbol: str) -> Dict[str, Any]:
        """Gets FTSO price data for a symbol."""
        if not self.web3_api:
            return {"error": "Web3 API not initialized"}
        return self.web3_api.get_ftso_prices().get(symbol, {"error": "Symbol not found"})

    def get_all_ftso_prices(self) -> Dict[str, Any]:
        """Gets all available FTSO price data."""
        if not self.web3_api:
            return {"error": "Web3 API not initialized"}
        return self.web3_api.get_ftso_prices()

    def get_ftso_providers(self) -> Dict[str, Any]:
        """Gets list of FTSO data providers."""
        if not self.web3_api:
            return {"error": "Web3 API not initialized"}
        return self.web3_api.get_ftso_providers()

    def get_flare_network_stats(self) -> Dict[str, Any]:
        """Gets Flare network statistics."""
        if not self.web3_api:
            return {"error": "Web3 API not initialized"}
        return self.web3_api.get_flare_network_stats()

    def wrap_native_token(self, amount: float) -> Dict[str, Any]:
        """Wraps native FLR/SGB tokens."""
        if not self.web3_api:
            raise ValueError("Web3 API not initialized")
        return self.web3_api.wrap_flr(amount)

    def unwrap_tokens(self, amount: float) -> Dict[str, Any]:
        """Unwraps WFLR/WSGB tokens back to native."""
        if not self.web3_api:
            raise ValueError("Web3 API not initialized")
        return self.web3_api.unwrap_flr(amount)

    def delegate_votes(self, provider_address: str, amount: float) -> Dict[str, Any]:
        """Delegates votes to an FTSO data provider."""
        if not self.web3_api:
            raise ValueError("Web3 API not initialized")
        return self.web3_api.delegate_votes(provider_address, amount)

    def claim_delegation_rewards(self) -> Dict[str, Any]:
        """Claims delegation rewards from FTSO providers."""
        if not self.web3_api:
            raise ValueError("Web3 API not initialized")
        return self.web3_api.claim_rewards()

    def get_delegation_info(self, address: str) -> Dict[str, Any]:
        """Gets delegation information for an address."""
        if not self.flare_contract_manager:
            return {"error": "Flare contract manager not initialized"}
        return self.flare_contract_manager.get_delegation_info(address)

    def export_system_data(self, file_path: str):
        """Exports current system data to a JSON file."""
        data = {
            "system_state": self.system_state,
            "trading_bot_status": self.get_trading_status(),
            "avatar_status": self.get_avatar_status(),
            "streaming_status": self.get_streaming_status(),
            "governance_stats": self.get_governance_stats(),
            "token_stats": self.get_token_stats(),
            "web3_wallet_status": self.get_web3_wallet_status(),
            "flare_network_stats": self.get_flare_network_stats()
        }
        with open(file_path, "w") as f:
            json.dump(data, f, indent=4)
        self.logger.info(f"System data exported to {file_path}")


