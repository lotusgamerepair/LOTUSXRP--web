#!/usr/bin/env python3
"""
System test script for the LotusXRP Crypto Platform.

This script tests the integration and functionality of all platform components
to ensure they work together correctly.
"""

import sys
import os
import time
import json
import logging
from typing import Dict, List

# Add project root to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def setup_test_logging():
    """Sets up logging for tests."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - TEST - %(levelname)s - %(message)s'
    )
    return logging.getLogger('SystemTest')

def test_imports():
    """Tests that all modules can be imported successfully."""
    logger = logging.getLogger('SystemTest')
    logger.info("Testing module imports...")
    
    try:
        # Test AI Trading Agent imports
        from ai_trading_agent import TradingBot, MLPredictor, BacktestEngine
        logger.info("✅ AI Trading Agent modules imported successfully")
        
        # Test VTuber Avatar imports
        from vtuber_avatar import Avatar, Animator, Streamer
        logger.info("✅ VTuber Avatar modules imported successfully")
        
        # Test Governance imports
        from flare_governance import GovernanceContract, GovernanceToken
        logger.info("✅ Governance modules imported successfully")
        
        # Test User Interface imports
        from user_interface import Dashboard, APIIntegration
        logger.info("✅ User Interface modules imported successfully")
        
        return True
        
    except ImportError as e:
        logger.error(f"❌ Import error: {e}")
        return False

def test_ai_trading_agent():
    """Tests the AI trading agent functionality."""
    logger = logging.getLogger('SystemTest')
    logger.info("Testing AI Trading Agent...")
    
    try:
        from ai_trading_agent import TradingBot, MLPredictor, BacktestEngine
        import pandas as pd
        import numpy as np
        
        # Test TradingBot
        bot = TradingBot("test_key", "test_secret")
        logger.info("✅ TradingBot created successfully")
        
        # Test MLPredictor
        predictor = MLPredictor()
        
        # Generate sample data for testing
        dates = pd.date_range(start='2023-01-01', end='2023-12-31', freq='D')
        sample_data = pd.DataFrame({
            'timestamp': dates,
            'open': np.random.uniform(0.4, 0.6, len(dates)),
            'high': np.random.uniform(0.5, 0.7, len(dates)),
            'low': np.random.uniform(0.3, 0.5, len(dates)),
            'close': np.random.uniform(0.4, 0.6, len(dates)),
            'volume': np.random.uniform(1000000, 5000000, len(dates))
        })
        
        predictor.train_model(sample_data)
        signal = predictor.generate_trading_signal(sample_data)
        logger.info(f"✅ ML Predictor generated signal: {signal}")
        
        # Test BacktestEngine
        engine = BacktestEngine()
        
        def simple_strategy(data, **kwargs):
            if len(data) < 20:
                return 'hold'
            return 'buy' if data['close'].iloc[-1] > data['close'].rolling(20).mean().iloc[-1] else 'sell'
        
        engine.run_backtest(sample_data, simple_strategy)
        performance = engine.get_performance_report()
        logger.info("✅ Backtest engine completed successfully")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ AI Trading Agent test failed: {e}")
        return False

def test_vtuber_avatar():
    """Tests the VTuber avatar system."""
    logger = logging.getLogger('SystemTest')
    logger.info("Testing VTuber Avatar System...")
    
    try:
        from vtuber_avatar import Avatar, Animator, Streamer
        
        # Test Avatar
        avatar = Avatar("TestAvatar")
        avatar.set_expression("happy")
        avatar.set_pose("celebrating")
        config = avatar.generate_avatar_config()
        logger.info("✅ Avatar created and configured successfully")
        
        # Test Animator
        animator = Animator(config)
        animator.play_animation("greeting")
        time.sleep(1)  # Let animation run briefly
        status = animator.get_animation_status()
        logger.info(f"✅ Animator working, status: {status}")
        
        # Test Streamer (basic initialization)
        streamer = Streamer(avatar, animator)
        stream_stats = streamer.get_stream_stats()
        logger.info(f"✅ Streamer initialized, stats: {stream_stats}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ VTuber Avatar test failed: {e}")
        return False

def test_governance_system():
    """Tests the governance system."""
    logger = logging.getLogger('SystemTest')
    logger.info("Testing Governance System...")
    
    try:
        from flare_governance import GovernanceContract, GovernanceToken
        from flare_governance.governance_contract import VoteType
        
        # Test GovernanceToken
        token = GovernanceToken("TestToken", "TEST")
        
        # Mint tokens to test addresses
        token.mint_tokens("0xTEST1", 10000 * (10 ** token.decimals), "Test mint")
        token.mint_tokens("0xTEST2", 5000 * (10 ** token.decimals), "Test mint")
        
        # Test staking
        token.stake_tokens("0xTEST1", "flexible", 1000 * (10 ** token.decimals))
        
        stats = token.get_token_stats()
        logger.info(f"✅ Token system working, stats: {stats}")
        
        # Test GovernanceContract
        governance = GovernanceContract()
        
        # Register voters
        governance.register_voter("0xTEST1", 10000)
        governance.register_voter("0xTEST2", 5000)
        
        # Create proposal
        proposal_id = governance.create_proposal(
            title="Test Proposal",
            description="A test proposal for system testing",
            proposer="0xTEST1"
        )
        
        # Simulate time passage for voting to start
        time.sleep(governance.governance_settings["voting_delay"] + 5) # Add 5 seconds to ensure it's active
        governance.update_proposal_status(proposal_id)

        # Cast vote
        governance.cast_vote(proposal_id, "0xTEST2", VoteType.FOR, "Test vote")
        
        proposal = governance.get_proposal(proposal_id)
        logger.info(f"✅ Governance system working, proposal: {proposal['title']}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Governance system test failed: {e}")
        return False

def test_api_integration():
    """Tests the API integration layer."""
    logger = logging.getLogger('SystemTest')
    logger.info("Testing API Integration...")
    
    try:
        from user_interface import APIIntegration
        
        # Test API Integration
        api = APIIntegration()
        api.initialize_components()
        
        # Test system status
        status = api.get_system_status()
        logger.info(f"✅ System status: {status['initialized']}")
        
        # Test trading integration
        trading_status = api.get_trading_status()
        logger.info(f"✅ Trading status retrieved")
        
        # Test avatar integration
        avatar_status = api.get_avatar_status()
        logger.info(f"✅ Avatar status retrieved")
        
        # Test governance integration
        proposals = api.get_governance_proposals()
        logger.info(f"✅ Governance proposals retrieved: {len(proposals)}")
        
        # Test token integration
        token_stats = api.get_token_stats()
        logger.info(f"✅ Token stats retrieved")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ API Integration test failed: {e}")
        return False

def test_dashboard():
    """Tests the dashboard functionality."""
    logger = logging.getLogger('SystemTest')
    logger.info("Testing Dashboard...")
    
    try:
        from user_interface import Dashboard, APIIntegration
        
        # Create API integration
        api = APIIntegration()
        api.initialize_components()
        
        # Create dashboard
        dashboard = Dashboard(api)
        
        # Test template creation
        dashboard.create_templates()
        logger.info("✅ Dashboard templates created")
        
        # Test Flask app creation
        app = dashboard.app
        logger.info(f"✅ Flask app created: {app.name}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Dashboard test failed: {e}")
        return False

def test_main_platform():
    """Tests the main platform entry point."""
    logger = logging.getLogger('SystemTest')
    logger.info("Testing Main Platform...")
    
    try:
        # Import main platform
        from main import LotusXRPPlatform
        
        # Create platform instance
        platform = LotusXRPPlatform()
        
        # Test initialization
        platform.initialize()
        logger.info("✅ Platform initialized successfully")
        
        # Test status
        status = platform.get_status()
        logger.info(f"✅ Platform status: {status['platform']['running']}")
        
        # Test shutdown
        platform.shutdown()
        logger.info("✅ Platform shutdown completed")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Main platform test failed: {e}")
        return False

def run_all_tests():
    """Runs all system tests."""
    logger = setup_test_logging()
    logger.info("Starting LotusXRP Crypto Platform System Tests")
    logger.info("=" * 60)
    
    tests = [
        ("Module Imports", test_imports),
        ("AI Trading Agent", test_ai_trading_agent),
        ("VTuber Avatar System", test_vtuber_avatar),
        ("Governance System", test_governance_system),
        ("API Integration", test_api_integration),
        ("Dashboard", test_dashboard),
        ("Main Platform", test_main_platform)
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        logger.info(f"Running test: {test_name}")
        try:
            result = test_func()
            results[test_name] = result
            if result:
                logger.info(f"✅ {test_name} PASSED")
            else:
                logger.error(f"❌ {test_name} FAILED")
        except Exception as e:
            logger.error(f"❌ {test_name} FAILED with exception: {e}")
            results[test_name] = False
        
        logger.info("-" * 40)
    
    # Summary
    logger.info("=" * 60)
    logger.info("TEST SUMMARY")
    logger.info("=" * 60)
    
    passed = sum(1 for result in results.values() if result)
    total = len(results)
    
    for test_name, result in results.items():
        status = "PASSED" if result else "FAILED"
        logger.info(f"{test_name}: {status}")
    
    logger.info("-" * 40)
    logger.info(f"Total: {passed}/{total} tests passed")
    
    if passed == total:
        logger.info("🎉 ALL TESTS PASSED! System is ready for use.")
        return True
    else:
        logger.error(f"⚠️  {total - passed} tests failed. Please check the logs above.")
        return False

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)

