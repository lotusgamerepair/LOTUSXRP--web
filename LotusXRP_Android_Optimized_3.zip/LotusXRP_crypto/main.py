"""
Main entry point for the LotusXRP Crypto Platform.

This module serves as the central entry point that initializes and coordinates
all platform components including the AI trading agent, VTuber avatar system,
Flare governance contracts, and user interface.
"""

import os
import sys
import argparse
import logging
import signal
import time
import json
from typing import Dict, Optional

# Add project root to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from user_interface.api_integration import APIIntegration
from user_interface.dashboard import Dashboard

class LotusXRPPlatform:
    def __init__(self, config_file: Optional[str] = None):
        self.config = self._load_config(config_file)
        self.api_integration = APIIntegration()
        self.dashboard = Dashboard(self.api_integration)
        self.running = False
        
        # Setup logging
        self._setup_logging()
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

    def _load_config(self, config_file: Optional[str]) -> Dict:
        """Loads configuration from file or returns default config.

        Args:
            config_file (Optional[str]): Path to configuration file

        Returns:
            Dict: Configuration dictionary
        """
        default_config = {
            "platform": {
                "name": "LotusXRP Crypto Platform",
                "version": "1.0.0",
                "debug": False,
                "log_level": "INFO"
            },
            "dashboard": {
                "host": "0.0.0.0",
                "port": 5000,
                "auto_start": True
            },
            "trading": {
                "api_key": "",
                "api_secret": "",
                "initial_balance": 10000,
                "risk_level": "medium",
                "auto_start": False
            },
            "avatar": {
                "name": "LotusXRP-chan",
                "type": "2D",
                "theme": "crypto_trader",
                "auto_animate": True
            },
            "streaming": {
                "host": "localhost",
                "port": 8765,
                "auto_start": False,
                "chat_enabled": True
            },
            "governance": {
                "voting_delay": 86400,
                "voting_period": 604800,
                "quorum_percentage": 10,
                "auto_initialize": True
            },
            "token": {
                "name": "LotusXRP",
                "symbol": "LOTUS",
                "initial_supply": 100000000,
                "auto_distribute": True
            },
            "web3": {
                "default_provider": "http://localhost:8545",
                "network_id": 1,
                "auto_connect": False
            }
        }
        
        if config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    file_config = json.load(f)
                # Merge file config with default config
                self._deep_merge(default_config, file_config)
            except Exception as e:
                print(f"Warning: Could not load config file {config_file}: {e}")
        
        return default_config

    def _deep_merge(self, base_dict: Dict, update_dict: Dict):
        """Recursively merges update_dict into base_dict."""
        for key, value in update_dict.items():
            if key in base_dict and isinstance(base_dict[key], dict) and isinstance(value, dict):
                self._deep_merge(base_dict[key], value)
            else:
                base_dict[key] = value

    def _setup_logging(self):
        """Sets up logging configuration."""
        log_level = getattr(logging, self.config["platform"]["log_level"].upper(), logging.INFO)
        
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(sys.stdout),
                logging.FileHandler('lotus_xrp.log')
            ]
        )

    def _signal_handler(self, signum, frame):
        """Handles shutdown signals gracefully."""
        self.logger.info(f"Received signal {signum}, shutting down gracefully...")
        self.shutdown()

    def initialize(self):
        """Initializes all platform components."""
        self.logger.info("Initializing LotusXRP Crypto Platform...")
        
        try:
            # Initialize API integration with all components
            self.api_integration.initialize_components(self.config)
            
            # Auto-start components based on configuration
            if self.config["trading"]["auto_start"]:
                self.logger.info("Auto-starting trading bot...")
                try:
                    self.api_integration.start_trading_bot()
                except Exception as e:
                    self.logger.warning(f"Could not auto-start trading bot: {e}")
            
            if self.config["streaming"]["auto_start"]:
                self.logger.info("Auto-starting streaming server...")
                try:
                    self.api_integration.start_streaming()
                except Exception as e:
                    self.logger.warning(f"Could not auto-start streaming: {e}")
            
            # Initialize governance if configured
            if self.config["governance"]["auto_initialize"]:
                self.logger.info("Initializing governance system...")
                self._initialize_governance()
            
            # Distribute initial tokens if configured
            if self.config["token"]["auto_distribute"]:
                self.logger.info("Distributing initial tokens...")
                self._distribute_initial_tokens()
            
            self.logger.info("Platform initialization completed successfully")
            
        except Exception as e:
            self.logger.error(f"Error during initialization: {e}")
            raise

    def _initialize_governance(self):
        """Initializes the governance system with default settings."""
        try:
            # Create some initial voters for demonstration
            demo_voters = [
                ("0xTREASURY", 50000000),  # Treasury with 50M tokens
                ("0xTEAM", 15000000),      # Team with 15M tokens
                ("0xADVISOR", 5000000),    # Advisors with 5M tokens
            ]
            
            for address, voting_power in demo_voters:
                self.api_integration.governance_contract.register_voter(address, voting_power)
            
            # Create a sample proposal
            proposal_id = self.api_integration.create_governance_proposal({
                "title": "Platform Launch Proposal",
                "description": "Initial proposal to officially launch the LotusXRP platform with community governance",
                "proposer": "0xTREASURY",
                "execution_data": {
                    "action": "update_settings",
                    "settings": {"platform_status": "launched"}
                }
            })
            
            self.logger.info(f"Created initial governance proposal: {proposal_id}")
            
        except Exception as e:
            self.logger.error(f"Error initializing governance: {e}")

    def _distribute_initial_tokens(self):
        """Distributes initial token supply according to tokenomics."""
        try:
            token = self.api_integration.governance_token
            total_supply = self.config["token"]["initial_supply"] * (10 ** token.decimals)
            
            # Distribution according to tokenomics
            distributions = [
                ("0xTREASURY", int(total_supply * 0.30), "Treasury allocation"),
                ("0xTEAM", int(total_supply * 0.15), "Team allocation"),
                ("0xADVISOR", int(total_supply * 0.05), "Advisor allocation"),
                ("0xLIQUIDITY", int(total_supply * 0.20), "Liquidity provision"),
                ("0xSTAKING", int(total_supply * 0.20), "Staking rewards"),
                ("0xPUBLIC", int(total_supply * 0.10), "Public sale")
            ]
            
            for address, amount, reason in distributions:
                token.mint_tokens(address, amount, reason)
                self.logger.info(f"Minted {amount} tokens to {address} for {reason}")
            
            # Set up some initial staking
            token.stake_tokens("0xTREASURY", "locked_365d", int(total_supply * 0.05))
            token.stake_tokens("0xTEAM", "locked_90d", int(total_supply * 0.03))
            
            self.logger.info("Initial token distribution completed")
            
        except Exception as e:
            self.logger.error(f"Error distributing tokens: {e}")

    def run(self):
        """Runs the main platform."""
        self.logger.info("Starting LotusXRP Crypto Platform...")
        
        try:
            self.initialize()
            self.running = True
            
            # Start the dashboard server
            if self.config["dashboard"]["auto_start"]:
                self.logger.info("Starting dashboard server...")
                self.dashboard.run(
                    host=self.config["dashboard"]["host"],
                    port=self.config["dashboard"]["port"],
                    debug=self.config["platform"]["debug"]
                )
            else:
                # Keep the platform running without dashboard
                self.logger.info("Platform running without dashboard. Press Ctrl+C to stop.")
                while self.running:
                    time.sleep(1)
                    
        except KeyboardInterrupt:
            self.logger.info("Received keyboard interrupt, shutting down...")
            self.shutdown()
        except Exception as e:
            self.logger.error(f"Error running platform: {e}")
            self.shutdown()

    def shutdown(self):
        """Shuts down the platform gracefully."""
        self.logger.info("Shutting down LotusXRP Crypto Platform...")
        self.running = False
        
        try:
            # Stop trading bot
            if self.api_integration.system_state["trading_active"]:
                self.api_integration.stop_trading_bot()
            
            # Stop streaming
            if self.api_integration.system_state["streaming_active"]:
                self.api_integration.stop_streaming()
            
            # Export system data before shutdown
            export_path = f"lotus_xrp_export_{int(time.time())}.json"
            self.api_integration.export_system_data(export_path)
            self.logger.info(f"System data exported to {export_path}")
            
            self.logger.info("Platform shutdown completed")
            
        except Exception as e:
            self.logger.error(f"Error during shutdown: {e}")

    def get_status(self) -> Dict:
        """Returns current platform status."""
        return {
            "platform": {
                "name": self.config["platform"]["name"],
                "version": self.config["platform"]["version"],
                "running": self.running,
                "uptime": time.time()
            },
            "system": self.api_integration.get_system_status(),
            "config": self.config
        }

def create_sample_config():
    """Creates a sample configuration file."""
    sample_config = {
        "platform": {
            "name": "LotusXRP Crypto Platform",
            "version": "1.0.0",
            "debug": True,
            "log_level": "DEBUG"
        },
        "dashboard": {
            "host": "0.0.0.0",
            "port": 5000,
            "auto_start": True
        },
        "trading": {
            "api_key": "YOUR_EXCHANGE_API_KEY",
            "api_secret": "YOUR_EXCHANGE_API_SECRET",
            "initial_balance": 10000,
            "risk_level": "medium",
            "auto_start": False
        },
        "avatar": {
            "name": "LotusXRP-chan",
            "type": "2D",
            "theme": "crypto_trader",
            "auto_animate": True
        },
        "streaming": {
            "host": "localhost",
            "port": 8765,
            "auto_start": False,
            "chat_enabled": True
        },
        "governance": {
            "voting_delay": 86400,
            "voting_period": 604800,
            "quorum_percentage": 10,
            "auto_initialize": True
        },
        "token": {
            "name": "LotusXRP",
            "symbol": "LOTUS",
            "initial_supply": 100000000,
            "auto_distribute": True
        }
    }
    
    with open("config.json", "w") as f:
        json.dump(sample_config, f, indent=2)
    
    print("Sample configuration file created: config.json")
    print("Please edit the configuration file with your API keys and preferences.")

def main():
    """Main function with command line argument parsing."""
    parser = argparse.ArgumentParser(description="LotusXRP Crypto Platform")
    parser.add_argument("--config", "-c", help="Configuration file path")
    parser.add_argument("--create-config", action="store_true", help="Create sample configuration file")
    parser.add_argument("--status", action="store_true", help="Show platform status and exit")
    parser.add_argument("--version", action="version", version="LotusXRP Platform 1.0.0")
    
    args = parser.parse_args()
    
    if args.create_config:
        create_sample_config()
        return
    
    # Create platform instance
    platform = LotusXRPPlatform(args.config)
    
    if args.status:
        try:
            platform.initialize()
            status = platform.get_status()
            print(json.dumps(status, indent=2, default=str))
        except Exception as e:
            print(f"Error getting status: {e}")
        return
    
    # Run the platform
    platform.run()

if __name__ == "__main__":
    main()

