"""
Backtesting framework for evaluating trading strategies on historical data.

This module provides tools to test trading strategies against historical
market data to evaluate their performance before live deployment.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, List, Tuple
import logging

class BacktestEngine:
    def __init__(self, initial_balance: float = 10000.0):
        self.initial_balance = initial_balance
        self.current_balance = initial_balance
        self.positions = {}  # {symbol: quantity}
        self.trade_history = []
        self.performance_metrics = {}
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)

    def reset(self):
        """Resets the backtest engine to initial state."""
        self.current_balance = self.initial_balance
        self.positions = {}
        self.trade_history = []
        self.performance_metrics = {}
        self.logger.info("Backtest engine reset")

    def execute_trade(self, timestamp: str, symbol: str, action: str, quantity: float, price: float):
        """Executes a trade during backtesting.

        Args:
            timestamp (str): Trade timestamp
            symbol (str): Trading symbol
            action (str): 'buy' or 'sell'
            quantity (float): Quantity to trade
            price (float): Price per unit
        """
        trade_value = quantity * price
        
        if action == 'buy':
            if self.current_balance >= trade_value:
                self.current_balance -= trade_value
                self.positions[symbol] = self.positions.get(symbol, 0) + quantity
                self.logger.info(f"BUY: {quantity} {symbol} at {price}")
            else:
                self.logger.warning(f"Insufficient balance for BUY order: {quantity} {symbol}")
                return False
                
        elif action == 'sell':
            if self.positions.get(symbol, 0) >= quantity:
                self.current_balance += trade_value
                self.positions[symbol] -= quantity
                if self.positions[symbol] == 0:
                    del self.positions[symbol]
                self.logger.info(f"SELL: {quantity} {symbol} at {price}")
            else:
                self.logger.warning(f"Insufficient position for SELL order: {quantity} {symbol}")
                return False

        # Record trade
        self.trade_history.append({
            'timestamp': timestamp,
            'symbol': symbol,
            'action': action,
            'quantity': quantity,
            'price': price,
            'value': trade_value,
            'balance_after': self.current_balance
        })
        
        return True

    def calculate_portfolio_value(self, current_prices: Dict[str, float]):
        """Calculates current portfolio value.

        Args:
            current_prices (Dict[str, float]): Current prices for all held assets

        Returns:
            float: Total portfolio value
        """
        portfolio_value = self.current_balance
        
        for symbol, quantity in self.positions.items():
            if symbol in current_prices:
                portfolio_value += quantity * current_prices[symbol]
        
        return portfolio_value

    def run_backtest(self, price_data: pd.DataFrame, strategy_func, strategy_params: Dict = None):
        """Runs a backtest using the provided strategy function.

        Args:
            price_data (pd.DataFrame): Historical price data
            strategy_func: Function that generates trading signals
            strategy_params (Dict): Parameters for the strategy function
        """
        self.reset()
        self.logger.info("Starting backtest")
        
        if strategy_params is None:
            strategy_params = {}
        
        portfolio_values = []
        
        for i, row in price_data.iterrows():
            # Generate trading signal
            signal = strategy_func(price_data.iloc[:i+1], **strategy_params)
            
            # Execute trades based on signal
            if signal == 'buy':
                # Buy with 10% of current balance
                trade_amount = self.current_balance * 0.1
                quantity = trade_amount / row['close']
                self.execute_trade(
                    timestamp=str(row['timestamp']),
                    symbol='XRP',
                    action='buy',
                    quantity=quantity,
                    price=row['close']
                )
            elif signal == 'sell':
                # Sell all positions
                if 'XRP' in self.positions:
                    self.execute_trade(
                        timestamp=str(row['timestamp']),
                        symbol='XRP',
                        action='sell',
                        quantity=self.positions['XRP'],
                        price=row['close']
                    )
            
            # Calculate portfolio value
            current_prices = {'XRP': row['close']}
            portfolio_value = self.calculate_portfolio_value(current_prices)
            portfolio_values.append(portfolio_value)
        
        self.portfolio_values = portfolio_values
        self.calculate_performance_metrics(price_data)
        self.logger.info("Backtest completed")

    def calculate_performance_metrics(self, price_data: pd.DataFrame):
        """Calculates performance metrics for the backtest."""
        if not self.portfolio_values:
            return
        
        # Total return
        total_return = (self.portfolio_values[-1] - self.initial_balance) / self.initial_balance
        
        # Maximum drawdown
        peak = self.initial_balance
        max_drawdown = 0
        for value in self.portfolio_values:
            if value > peak:
                peak = value
            drawdown = (peak - value) / peak
            if drawdown > max_drawdown:
                max_drawdown = drawdown
        
        # Sharpe ratio (simplified)
        returns = np.diff(self.portfolio_values) / self.portfolio_values[:-1]
        sharpe_ratio = np.mean(returns) / np.std(returns) if np.std(returns) > 0 else 0
        
        # Win rate
        profitable_trades = sum(1 for trade in self.trade_history if trade['action'] == 'sell')
        total_trades = len([t for t in self.trade_history if t['action'] == 'sell'])
        win_rate = profitable_trades / total_trades if total_trades > 0 else 0
        
        self.performance_metrics = {
            'total_return': total_return,
            'max_drawdown': max_drawdown,
            'sharpe_ratio': sharpe_ratio,
            'win_rate': win_rate,
            'total_trades': total_trades,
            'final_balance': self.portfolio_values[-1]
        }
        
        self.logger.info(f"Performance metrics calculated: {self.performance_metrics}")

    def plot_results(self):
        """Plots backtest results."""
        if not self.portfolio_values:
            self.logger.warning("No backtest results to plot")
            return
        
        plt.figure(figsize=(12, 6))
        plt.plot(self.portfolio_values, label='Portfolio Value')
        plt.axhline(y=self.initial_balance, color='r', linestyle='--', label='Initial Balance')
        plt.title('Backtest Results')
        plt.xlabel('Time Period')
        plt.ylabel('Portfolio Value ($)')
        plt.legend()
        plt.grid(True)
        plt.show()

    def get_performance_report(self):
        """Returns a formatted performance report."""
        if not self.performance_metrics:
            return "No backtest results available"
        
        report = f"""
        Backtest Performance Report
        ===========================
        Initial Balance: ${self.initial_balance:,.2f}
        Final Balance: ${self.performance_metrics['final_balance']:,.2f}
        Total Return: {self.performance_metrics['total_return']:.2%}
        Maximum Drawdown: {self.performance_metrics['max_drawdown']:.2%}
        Sharpe Ratio: {self.performance_metrics['sharpe_ratio']:.4f}
        Win Rate: {self.performance_metrics['win_rate']:.2%}
        Total Trades: {self.performance_metrics['total_trades']}
        """
        
        return report

def simple_moving_average_strategy(data: pd.DataFrame, short_window: int = 20, long_window: int = 50):
    """Simple moving average crossover strategy.

    Args:
        data (pd.DataFrame): Price data
        short_window (int): Short MA window
        long_window (int): Long MA window

    Returns:
        str: Trading signal
    """
    if len(data) < long_window:
        return 'hold'
    
    short_ma = data['close'].rolling(window=short_window).mean().iloc[-1]
    long_ma = data['close'].rolling(window=long_window).mean().iloc[-1]
    prev_short_ma = data['close'].rolling(window=short_window).mean().iloc[-2]
    prev_long_ma = data['close'].rolling(window=long_window).mean().iloc[-2]
    
    # Golden cross (buy signal)
    if short_ma > long_ma and prev_short_ma <= prev_long_ma:
        return 'buy'
    # Death cross (sell signal)
    elif short_ma < long_ma and prev_short_ma >= prev_long_ma:
        return 'sell'
    else:
        return 'hold'

if __name__ == "__main__":
    # Example usage
    engine = BacktestEngine(initial_balance=10000)
    
    # Generate sample data
    dates = pd.date_range(start='2023-01-01', end='2023-12-31', freq='D')
    sample_data = pd.DataFrame({
        'timestamp': dates,
        'open': np.random.uniform(0.4, 0.6, len(dates)),
        'high': np.random.uniform(0.5, 0.7, len(dates)),
        'low': np.random.uniform(0.3, 0.5, len(dates)),
        'close': np.random.uniform(0.4, 0.6, len(dates)),
        'volume': np.random.uniform(1000000, 5000000, len(dates))
    })
    
    # Run backtest
    engine.run_backtest(sample_data, simple_moving_average_strategy)
    print(engine.get_performance_report())

