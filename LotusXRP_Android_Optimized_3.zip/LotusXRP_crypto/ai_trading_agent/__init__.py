"""
AI Trading Agent Module for LotusXRP Crypto Platform

This module contains the core AI trading algorithms, machine learning models,
and backtesting framework for automated cryptocurrency trading.
"""

from .trading_bot import TradingBot
from .machine_learning import MLPredictor
from .backtesting import BacktestEngine

__version__ = "1.0.0"
__author__ = "LotusXRP Team"

__all__ = [
    "TradingBot",
    "MLPredictor", 
    "BacktestEngine"
]

