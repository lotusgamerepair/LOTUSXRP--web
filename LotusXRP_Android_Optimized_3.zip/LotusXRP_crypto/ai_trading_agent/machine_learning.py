"""
Machine Learning models for cryptocurrency price prediction and trading signals.

This module integrates various ML models to predict market movements and
generate trading signals for the LotusXRP platform, incorporating sentiment
analysis and dynamic thresholding.
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import logging
from typing import Optional

class MLPredictor:
    def __init__(self):
        self.model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.scaler = StandardScaler()
        self.is_trained = False
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)

    def prepare_features(self, price_data: pd.DataFrame, sentiment_data: Optional[pd.DataFrame] = None):
        """Prepares features from raw price data and optional sentiment data for ML model training.

        Args:
            price_data (pd.DataFrame): DataFrame with columns [‘timestamp’, ‘open’, ‘high’, ‘low’, ‘close’, ‘volume’]
            sentiment_data (Optional[pd.DataFrame]): DataFrame with columns [‘timestamp’, ‘sentiment_score’]

        Returns:
            pd.DataFrame: Prepared feature matrix
        """
        self.logger.info("Preparing features from price data and sentiment data")
        
        # Calculate technical indicators
        df = price_data.copy()
        df["sma_20"] = df["close"].rolling(window=20).mean()
        df["sma_50"] = df["close"].rolling(window=50).mean()
        df["rsi"] = self._calculate_rsi(df["close"])
        df["volatility"] = df["close"].rolling(window=20).std()
        
        # Merge with sentiment data if provided
        if sentiment_data is not None and not sentiment_data.empty:
            # Ensure timestamp columns are datetime objects for merging
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            sentiment_data["timestamp"] = pd.to_datetime(sentiment_data["timestamp"])
            
            # Merge on nearest timestamp (or resample if needed for exact alignment)
            df = df.set_index("timestamp")
            sentiment_data = sentiment_data.set_index("timestamp")
            
            # Use asof merge to carry forward the last valid sentiment observation
            df = pd.merge_asof(df, sentiment_data[["sentiment_score"]], left_index=True, right_index=True, direction="nearest")
            df = df.reset_index() # Reset index after merge
