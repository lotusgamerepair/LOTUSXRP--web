#!/usr/bin/env python3
"""
Simple test server for Android optimization testing
"""

from flask import Flask, render_template, jsonify, send_from_directory
import os
import json
from datetime import datetime

app = Flask(__name__, 
           template_folder='LotusXRP_crypto/user_interface/templates',
           static_folder='LotusXRP_crypto/user_interface/static')

# Mock configuration
class Config:
    def __init__(self):
        self.title = "LotusXRP Crypto Platform"

config = Config()

@app.route('/')
def index():
    return render_template('index.html', config=config)

@app.route('/web3_wallet')
def web3_wallet():
    return render_template('web3_wallet.html', config=config)

@app.route('/market_visualization')
def market_visualization():
    return render_template('market_visualization.html', config=config)

@app.route('/offline.html')
def offline():
    return render_template('offline.html', config=config)

# API endpoints for testing
@app.route('/api/status')
def api_status():
    return jsonify({
        'success': True,
        'data': {
            'trading_bot': True,
            'avatar_system': True,
            'governance': True,
            'timestamp': datetime.now().isoformat()
        }
    })

@app.route('/api/trading/status')
def api_trading_status():
    return jsonify({
        'success': True,
        'data': {
            'is_running': True,
            'total_trades': 42,
            'daily_pnl': 1250.75,
            'timestamp': datetime.now().isoformat()
        }
    })

@app.route('/api/trading/portfolio')
def api_portfolio():
    return jsonify({
        'success': True,
        'data': {
            'total_value': 15750.25,
            'timestamp': datetime.now().isoformat()
        }
    })

@app.route('/api/streaming/status')
def api_streaming_status():
    return jsonify({
        'success': True,
        'data': {
            'is_streaming': True,
            'connected_clients': 127,
            'timestamp': datetime.now().isoformat()
        }
    })

@app.route('/api/governance/proposals')
def api_governance_proposals():
    return jsonify({
        'success': True,
        'data': [
            {'id': 1, 'title': 'Increase trading frequency', 'status': 'active'},
            {'id': 2, 'title': 'Add new trading pairs', 'status': 'active'},
            {'id': 3, 'title': 'Update avatar animations', 'status': 'active'}
        ],
        'user_votes': 5
    })

# Static file serving
@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('LotusXRP_crypto/user_interface/static', filename)

@app.route('/static/icons/<path:filename>')
def icon_files(filename):
    return send_from_directory('LotusXRP_crypto/user_interface/static/icons', filename)

# Service worker
@app.route('/static/sw.js')
def service_worker():
    return send_from_directory('LotusXRP_crypto/user_interface/static', 'sw.js')

# Manifest
@app.route('/static/manifest.json')
def manifest():
    return send_from_directory('LotusXRP_crypto/user_interface/static', 'manifest.json')

if __name__ == '__main__':
    print("Starting Android-optimized LotusXRP test server...")
    print("Server will be available at http://localhost:5000")
    print("Testing mobile-responsive design and Android optimizations...")
    
    app.run(host='0.0.0.0', port=5000, debug=True)

